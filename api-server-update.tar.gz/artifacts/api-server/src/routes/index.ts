import { Router, type IRouter } from "express";
import fs from "fs";
import path from "path";
import healthRouter from "./health.js";
import authRouter from "./auth.js";
import packagesRouter from "./packages.js";
import bookingsRouter from "./bookings.js";
import paymentsRouter from "./payments.js";
import documentsRouter from "./documents.js";
import notificationsRouter from "./notifications.js";
import broadcastsRouter from "./broadcasts.js";
import adminRouter from "./admin.js";
import inquiryRouter from "./inquiry.js";
import galleryRouter from "./gallery.js";
import groupsRouter from "./groups.js";
import packageMediaRouter from "./package-media.js";
import kycRouter from "./kyc.js";
import storageRouter from "./storage.js";
import requestsRouter from "./requests.js";
import adminPaymentsRouter from "./admin-payments.js";
import feedbackRouter from "./feedback.js";
import staffRouter from "./staff.js";
import verifyRouter from "./verify.js";
import scanRouter from "./scan.js";
import deleteAuthRouter from "./delete-auth.js";

const router: IRouter = Router();

// Temporary: serve pre-built frontend dist for VPS deployment
router.get("/download-dist", (_req, res) => {
  const candidates = [
    "/home/runner/workspace/frontend-dist.tar.gz",
    path.resolve(process.cwd(), "../../frontend-dist.tar.gz"),
    path.resolve(process.cwd(), "frontend-dist.tar.gz"),
  ];
  const found = candidates.find(p => fs.existsSync(p));
  if (found) {
    res.setHeader("Content-Type", "application/gzip");
    res.setHeader("Content-Disposition", 'attachment; filename="frontend-dist.tar.gz"');
    res.sendFile(found);
  } else {
    res.status(404).json({ error: "Dist archive not found", tried: candidates });
  }
});

router.use(healthRouter);
router.use("/auth", authRouter);
router.use("/packages", packagesRouter);
router.use("/packages", packageMediaRouter);
router.use("/bookings", bookingsRouter);
router.use("/payments", paymentsRouter);
router.use("/documents", documentsRouter);
router.use("/notifications", notificationsRouter);
router.use("/broadcasts", broadcastsRouter);
router.use("/admin", adminRouter);
router.use("/inquiry", inquiryRouter);
router.use("/gallery", galleryRouter);
router.use("/groups", groupsRouter);
router.use("/kyc", kycRouter);
router.use("/requests", requestsRouter);
router.use("/admin/bookings", adminPaymentsRouter);
router.use("/feedback", feedbackRouter);
router.use("/staff", staffRouter);
router.use("/verify", verifyRouter);
router.use("/scan", scanRouter);
router.use("/delete-auth", deleteAuthRouter);
router.use(storageRouter);

export default router;
