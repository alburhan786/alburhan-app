--
-- PostgreSQL database dump
--

\restrict H1AkvwTg9QkDeFVqNEZwmXk0yy0nOrHvPgLqn77ibCucUrFlN2I3dg9Gc5cuhqN

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: blood_group; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.blood_group AS ENUM (
    'A+',
    'A-',
    'B+',
    'B-',
    'AB+',
    'AB-',
    'O+',
    'O-',
    'unknown'
);


--
-- Name: booking_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.booking_status AS ENUM (
    'pending',
    'approved',
    'rejected',
    'confirmed',
    'cancelled',
    'partially_paid'
);


--
-- Name: document_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.document_type AS ENUM (
    'passport',
    'pan_card',
    'aadhaar',
    'passport_photo',
    'flight_ticket',
    'visa',
    'room_allotment',
    'bus_allotment',
    'model_contract',
    'tour_itinerary',
    'other',
    'hotel_voucher',
    'payment_receipt',
    'ziyarat_schedule',
    'insurance',
    'hajj_id',
    'luggage_tag',
    'emergency_contact_card',
    'medical_certificate',
    'vaccination_certificate',
    'passport_copy'
);


--
-- Name: document_uploaded_by; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.document_uploaded_by AS ENUM (
    'customer',
    'admin'
);


--
-- Name: feedback_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.feedback_status AS ENUM (
    'open',
    'in_progress',
    'resolved'
);


--
-- Name: gender_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.gender_type AS ENUM (
    'male',
    'female',
    'other'
);


--
-- Name: kyc_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.kyc_status AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: media_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.media_type AS ENUM (
    'image',
    'video'
);


--
-- Name: package_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.package_type AS ENUM (
    'umrah',
    'ramadan_umrah',
    'hajj',
    'special_hajj',
    'iraq_ziyarat',
    'baitul_muqaddas',
    'syria_ziyarat',
    'jordan_heritage'
);


--
-- Name: payment_mode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_mode AS ENUM (
    'cash',
    'neft',
    'upi',
    'cheque',
    'online'
);


--
-- Name: reminder_channel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reminder_channel AS ENUM (
    'whatsapp',
    'sms'
);


--
-- Name: reminder_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.reminder_status AS ENUM (
    'sent',
    'failed',
    'skipped'
);


--
-- Name: request_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.request_status AS ENUM (
    'pending',
    'approved',
    'rejected'
);


--
-- Name: user_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.user_role AS ENUM (
    'customer',
    'admin'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_opening_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_opening_balances (
    id text NOT NULL,
    account_id text NOT NULL,
    financial_year_id text NOT NULL,
    opening_balance numeric(14,2) DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    sub_type text,
    parent_id text,
    opening_balance numeric(14,2) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    is_system boolean DEFAULT false NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: admin_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_events (
    id integer NOT NULL,
    event_type text NOT NULL,
    title text NOT NULL,
    description text,
    booking_id text,
    customer_name text,
    severity text DEFAULT 'info'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: admin_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.admin_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.admin_events_id_seq OWNED BY public.admin_events.id;


--
-- Name: admin_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.admin_notifications (
    id text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body jsonb DEFAULT '{}'::jsonb NOT NULL,
    booking_id text,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    mobile text,
    email text,
    city text,
    branch_id uuid,
    commission_rate numeric(5,2) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: agreement_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agreement_audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agreement_id text NOT NULL,
    action text NOT NULL,
    details jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: agreements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agreements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agreement_number text NOT NULL,
    booking_id text NOT NULL,
    customer_id text,
    status text DEFAULT 'draft'::text NOT NULL,
    terms_accepted jsonb,
    signature_data text,
    signed_at timestamp with time zone,
    signed_ip text,
    signed_user_agent text,
    otp_verified boolean DEFAULT false,
    otp_verified_at timestamp with time zone,
    signing_otp text,
    signing_otp_expires_at timestamp with time zone,
    pdf_generated boolean DEFAULT false,
    verification_token text DEFAULT gen_random_uuid(),
    cancelled_at timestamp with time zone,
    cancelled_reason text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    hotel_info jsonb,
    flight_info jsonb,
    signing_metadata jsonb,
    digital_hash text,
    revision_number integer DEFAULT 1,
    void_at timestamp with time zone,
    void_reason text
);


--
-- Name: api_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    api_url text,
    api_key_encrypted text,
    extra_fields_encrypted text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by text,
    status text DEFAULT 'unknown'::text,
    last_tested timestamp with time zone,
    last_sms_status text,
    last_sms_at timestamp with time zone
);


--
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id text NOT NULL,
    name text NOT NULL,
    category text DEFAULT 'other'::text NOT NULL,
    purchase_date text NOT NULL,
    purchase_price numeric(14,2) DEFAULT 0 NOT NULL,
    vendor text,
    serial_number text,
    warranty_date text,
    depreciation_rate numeric(6,4) DEFAULT 0.15 NOT NULL,
    location text,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: attendance_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_events (
    id text NOT NULL,
    group_id text NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'other'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    scan_token text,
    scan_token_expires_at timestamp without time zone
);


--
-- Name: attendance_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attendance_logs (
    id text NOT NULL,
    event_id text NOT NULL,
    pilgrim_id text NOT NULL,
    group_id text NOT NULL,
    status text DEFAULT 'present'::text NOT NULL,
    scanned_at timestamp without time zone DEFAULT now() NOT NULL,
    scanned_by text
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    actor_id text,
    actor_name text,
    action text NOT NULL,
    entity_table text NOT NULL,
    entity_id text NOT NULL,
    old_value jsonb,
    new_value jsonb,
    ip text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: bank_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_settings (
    id text DEFAULT 'default'::text NOT NULL,
    bank_name text DEFAULT 'State Bank of India'::text,
    branch text DEFAULT ''::text,
    account_name text DEFAULT 'Al Burhan Tours & Travels'::text,
    account_number text DEFAULT ''::text,
    ifsc_code text DEFAULT ''::text,
    swift_code text DEFAULT ''::text,
    upi_id text DEFAULT ''::text,
    qr_code_url text DEFAULT ''::text,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: booking_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_audit_logs (
    id text NOT NULL,
    booking_id text NOT NULL,
    changed_by text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    action text NOT NULL,
    field_name text,
    old_value text,
    new_value text
);


--
-- Name: booking_confirmation_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_confirmation_notifications (
    id text NOT NULL,
    booking_id text NOT NULL,
    channel text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    error_message text,
    sent_at timestamp with time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: booking_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.booking_settings (
    id text DEFAULT 'default'::text NOT NULL,
    gst_enabled boolean DEFAULT true NOT NULL,
    gst_rate numeric(5,2) DEFAULT 5 NOT NULL,
    gst_included boolean DEFAULT false NOT NULL,
    tcs_enabled boolean DEFAULT false NOT NULL,
    tcs_rate numeric(5,2) DEFAULT 2 NOT NULL,
    tcs_included boolean DEFAULT false NOT NULL,
    discount_enabled boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: bookings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bookings (
    id text NOT NULL,
    booking_number text NOT NULL,
    package_id text,
    package_name text,
    customer_id text,
    customer_name text NOT NULL,
    customer_mobile text NOT NULL,
    customer_email text,
    number_of_pilgrims integer NOT NULL,
    pilgrims jsonb DEFAULT '[]'::jsonb,
    preferred_departure_date text,
    status public.booking_status DEFAULT 'pending'::public.booking_status NOT NULL,
    total_amount numeric(12,2),
    gst_amount numeric(12,2),
    final_amount numeric(12,2),
    payment_id text,
    razorpay_order_id text,
    razorpay_payment_id text,
    invoice_number text,
    rejection_reason text,
    notes text,
    is_offline boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    room_type text,
    advance_amount numeric(12,2),
    group_id text,
    paid_amount numeric(12,2),
    online_paid_amount numeric(12,2) DEFAULT '0'::numeric,
    traveller_details_status text DEFAULT 'not_submitted'::text NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by text,
    is_deleted boolean DEFAULT false NOT NULL,
    gst_rate numeric(5,2),
    taxable_amount numeric(14,2),
    discount_type text,
    discount_amount numeric(12,2) DEFAULT 0,
    discount_percentage numeric(5,2) DEFAULT 0,
    discount_reason text,
    net_amount numeric(12,2),
    gst_included boolean DEFAULT false NOT NULL,
    tcs_enabled boolean DEFAULT false NOT NULL,
    tcs_rate numeric(5,2) DEFAULT 2,
    tcs_amount numeric(12,2),
    journey_status text DEFAULT 'booking_requested'::text,
    due_date timestamp with time zone,
    branch_id uuid,
    agent_id uuid,
    ticket_status text,
    max_pilgrims integer
);


--
-- Name: branches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.branches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    city text,
    address text,
    manager_name text,
    manager_mobile text,
    manager_email text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: broadcasts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.broadcasts (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text DEFAULT 'general'::text NOT NULL,
    audience text NOT NULL,
    channels text[] DEFAULT '{}'::text[] NOT NULL,
    recipient_count integer DEFAULT 0 NOT NULL,
    sent_at timestamp without time zone DEFAULT now() NOT NULL,
    sent_by text
);


--
-- Name: buses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.buses (
    id text NOT NULL,
    bus_number text NOT NULL,
    group_id text NOT NULL,
    capacity integer DEFAULT 45 NOT NULL,
    vehicle_type text DEFAULT 'Coach'::text,
    driver_name text,
    driver_mobile text,
    route_description text,
    notes text,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    guide_name text
);


--
-- Name: companies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.companies (
    id text NOT NULL,
    name text NOT NULL,
    arabic_name text,
    address text,
    phone text,
    mobile text,
    email text,
    website text,
    logo_url text,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_notification_preferences (
    customer_id text NOT NULL,
    whatsapp boolean DEFAULT true NOT NULL,
    sms boolean DEFAULT true NOT NULL,
    email boolean DEFAULT false NOT NULL,
    rcs boolean DEFAULT false NOT NULL,
    push boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_notifications (
    id text NOT NULL,
    customer_id text NOT NULL,
    broadcast_id text,
    title text NOT NULL,
    message text NOT NULL,
    type text DEFAULT 'general'::text NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_profiles (
    id text NOT NULL,
    user_id text NOT NULL,
    name text,
    phone text,
    whatsapp_number text,
    date_of_birth text,
    gender public.gender_type,
    address text,
    passport_number text,
    passport_issue_date text,
    passport_expiry_date text,
    passport_place_of_issue text,
    passport_image_url text,
    photo_url text,
    blood_group public.blood_group,
    aadhar_number text,
    aadhar_image_url text,
    pan_number text,
    pan_image_url text,
    health_certificate_url text,
    kyc_status public.kyc_status DEFAULT 'pending'::public.kyc_status NOT NULL,
    admin_notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    father_name text,
    nationality text,
    city text,
    state text,
    country text DEFAULT 'India'::text,
    passport_expiry date,
    nominee text,
    nominee_relation text
);


--
-- Name: customer_push_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_push_tokens (
    id text NOT NULL,
    customer_id text NOT NULL,
    token text NOT NULL,
    platform text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_timeline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_timeline (
    id integer NOT NULL,
    customer_id text,
    booking_id text,
    event_type text NOT NULL,
    title text NOT NULL,
    description text,
    icon text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: customer_timeline_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customer_timeline_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customer_timeline_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customer_timeline_id_seq OWNED BY public.customer_timeline.id;


--
-- Name: delete_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.delete_audit_log (
    id integer NOT NULL,
    action text NOT NULL,
    item_type text NOT NULL,
    item_id text NOT NULL,
    deleted_by text NOT NULL,
    ip_address text NOT NULL,
    success boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: delete_audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.delete_audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: delete_audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.delete_audit_log_id_seq OWNED BY public.delete_audit_log.id;


--
-- Name: document_download_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_download_logs (
    id text NOT NULL,
    document_id text NOT NULL,
    booking_id text NOT NULL,
    customer_id text,
    downloaded_at timestamp with time zone DEFAULT now() NOT NULL,
    ip_address text
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id text NOT NULL,
    booking_id text NOT NULL,
    document_type public.document_type NOT NULL,
    file_name text NOT NULL,
    file_key text NOT NULL,
    file_url text,
    uploaded_by public.document_uploaded_by DEFAULT 'customer'::public.document_uploaded_by NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    download_count integer DEFAULT 0 NOT NULL,
    last_downloaded_at timestamp with time zone,
    is_revoked boolean DEFAULT false NOT NULL,
    customer_id text,
    is_visible_to_customer boolean DEFAULT true NOT NULL,
    notification_sent boolean DEFAULT false NOT NULL,
    viewed_at timestamp with time zone,
    file_size integer,
    mime_type text,
    original_filename text
);


--
-- Name: employee_advances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employee_advances (
    id text NOT NULL,
    employee_id text NOT NULL,
    amount numeric(12,2) NOT NULL,
    date text NOT NULL,
    reason text,
    status text DEFAULT 'pending'::text NOT NULL,
    payroll_run_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: employees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.employees (
    id text NOT NULL,
    name text NOT NULL,
    designation text,
    department text,
    mobile text,
    email text,
    bank_account text,
    ifsc text,
    pan text,
    pf_number text,
    esi_number text,
    joining_date text,
    basic_salary numeric(12,2) DEFAULT 0 NOT NULL,
    hra numeric(12,2) DEFAULT 0 NOT NULL,
    allowances jsonb DEFAULT '{}'::jsonb NOT NULL,
    total_salary numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id text NOT NULL,
    group_id text,
    category text NOT NULL,
    vendor text,
    description text NOT NULL,
    amount numeric(12,2) NOT NULL,
    date text NOT NULL,
    paid_by text,
    payment_method text DEFAULT 'cash'::text,
    invoice_number text,
    attachment_url text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    status text DEFAULT 'approved'::text NOT NULL,
    approved_by text,
    rejected_reason text,
    package_id text,
    vendor_id text,
    gst_percent numeric(5,2),
    cgst_amount numeric(12,2),
    sgst_amount numeric(12,2),
    igst_amount numeric(12,2),
    hsn_sac text
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    pilgrim_mobile text NOT NULL,
    pilgrim_name text,
    booking_id text,
    company_id text,
    group_id text,
    group_name text,
    rating_overall integer,
    rating_accommodation_makkah1 integer,
    rating_accommodation_makkah2 integer,
    rating_accommodation_madinah integer,
    rating_transportation integer,
    rating_food integer,
    rating_guide integer,
    rating_visa_documentation integer,
    comment text,
    what_did_you_like text,
    suggestions text,
    would_recommend text,
    is_complaint boolean DEFAULT false NOT NULL,
    status public.feedback_status DEFAULT 'open'::public.feedback_status NOT NULL,
    assigned_to text,
    internal_notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: financial_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_years (
    id text NOT NULL,
    name text NOT NULL,
    start_date text NOT NULL,
    end_date text NOT NULL,
    is_active boolean DEFAULT false NOT NULL,
    is_closed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: gallery_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gallery_images (
    id text NOT NULL,
    title text,
    file_name text NOT NULL,
    file_url text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    uploaded_by text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: group_flights; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_flights (
    id text NOT NULL,
    group_id text NOT NULL,
    flight_type text DEFAULT 'outbound'::text NOT NULL,
    airline text,
    flight_number text,
    pnr text,
    departure_airport text,
    arrival_airport text,
    departure_date text,
    departure_time text,
    arrival_date text,
    arrival_time text,
    baggage_allowance text,
    meal_type text,
    status text DEFAULT 'scheduled'::text,
    notes text,
    pilgrims_assigned jsonb DEFAULT '[]'::jsonb,
    ticket_numbers jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    terminal text
);


--
-- Name: group_tracking; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_tracking (
    group_id text NOT NULL,
    current_city text,
    current_activity text,
    next_activity text,
    notes text,
    meeting_point text,
    updated_by text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: hajj_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hajj_groups (
    id text NOT NULL,
    group_name text NOT NULL,
    year integer NOT NULL,
    departure_date text,
    return_date text,
    flight_number text,
    maktab_number text,
    hotels jsonb DEFAULT '{}'::jsonb,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    company_id text,
    starting_serial_number integer DEFAULT 1 NOT NULL
);


--
-- Name: hajj_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hajj_rooms (
    id text NOT NULL,
    group_id text NOT NULL,
    room_number text NOT NULL,
    hotel text DEFAULT 'makkah'::text NOT NULL,
    total_beds integer DEFAULT 4 NOT NULL,
    room_type text DEFAULT 'gents'::text NOT NULL,
    floor text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: holy_site_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.holy_site_allocations (
    id text NOT NULL,
    site text NOT NULL,
    pilgrim_id text,
    family_id text,
    group_id text,
    tent_number text,
    camp_number text,
    area text,
    capacity integer,
    guide_name text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: hotel_rooms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hotel_rooms (
    id text NOT NULL,
    hotel_id text NOT NULL,
    room_number text NOT NULL,
    floor text,
    capacity integer DEFAULT 2 NOT NULL,
    bed_type text DEFAULT 'Double'::text,
    notes text,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    room_type text,
    status text DEFAULT 'vacant'::text
);


--
-- Name: hotels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hotels (
    id text NOT NULL,
    name text NOT NULL,
    city text NOT NULL,
    address text,
    stars integer,
    group_id text,
    check_in_date text,
    check_out_date text,
    total_rooms integer,
    contact_phone text,
    notes text,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    deleted_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    distance_from_haram text,
    contact_person text,
    email text
);


--
-- Name: inquiries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inquiries (
    id text NOT NULL,
    name text NOT NULL,
    mobile text NOT NULL,
    email text,
    message text NOT NULL,
    package_interest text,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    invoice_number text NOT NULL,
    booking_id text NOT NULL,
    customer_id text,
    invoice_date timestamp with time zone DEFAULT now() NOT NULL,
    subtotal numeric(12,2) DEFAULT 0 NOT NULL,
    discount numeric(12,2) DEFAULT 0 NOT NULL,
    gst_amount numeric(12,2) DEFAULT 0 NOT NULL,
    tcs_amount numeric(12,2) DEFAULT 0 NOT NULL,
    total numeric(12,2) DEFAULT 0 NOT NULL,
    paid numeric(12,2) DEFAULT 0 NOT NULL,
    balance numeric(12,2) DEFAULT 0 NOT NULL,
    invoice_status text DEFAULT 'pending'::text NOT NULL,
    pdf_path text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    due_date timestamp with time zone,
    notes text,
    line_items jsonb DEFAULT '[]'::jsonb
);


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id text NOT NULL,
    entry_number text NOT NULL,
    date text NOT NULL,
    narration text NOT NULL,
    reference text,
    source text DEFAULT 'manual'::text NOT NULL,
    source_id text,
    financial_year_id text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: journal_entry_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entry_lines (
    id text NOT NULL,
    journal_entry_id text NOT NULL,
    account_id text NOT NULL,
    debit numeric(14,2) DEFAULT 0 NOT NULL,
    credit numeric(14,2) DEFAULT 0 NOT NULL,
    narration text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: leads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.leads (
    id text NOT NULL,
    name text NOT NULL,
    mobile text,
    email text,
    source text DEFAULT 'website'::text,
    status text DEFAULT 'new'::text,
    message text,
    package_interest text,
    budget text,
    assigned_to text,
    assigned_name text,
    follow_up_date date,
    notes text,
    conversion_booking_id text,
    converted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: loyalty_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loyalty_points (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_id text NOT NULL,
    customer_name text,
    customer_mobile text,
    total_points integer DEFAULT 0 NOT NULL,
    redeemed_points integer DEFAULT 0 NOT NULL,
    tier text DEFAULT 'bronze'::text NOT NULL,
    bookings_count integer DEFAULT 0 NOT NULL,
    total_spent numeric(12,2) DEFAULT 0 NOT NULL,
    last_activity timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: loyalty_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loyalty_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    customer_id text NOT NULL,
    points integer NOT NULL,
    type text DEFAULT 'credit'::text NOT NULL,
    reason text,
    source text DEFAULT 'system'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: luggage_tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.luggage_tags (
    id text NOT NULL,
    tag_number text NOT NULL,
    pilgrim_id text,
    booking_id text,
    pilgrim_name text,
    group_id text,
    weight numeric(6,2),
    status text DEFAULT 'assigned'::text,
    location text,
    delivery_status text DEFAULT 'pending'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: marketing_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marketing_campaigns (
    id text NOT NULL,
    name text NOT NULL,
    message text NOT NULL,
    channel text NOT NULL,
    segment text NOT NULL,
    subject text,
    status text DEFAULT 'draft'::text NOT NULL,
    total_recipients integer DEFAULT 0,
    sent_count integer DEFAULT 0,
    failed_count integer DEFAULT 0,
    created_by text,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: medical_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.medical_cases (
    id text NOT NULL,
    pilgrim_id text NOT NULL,
    group_id text,
    case_type text DEFAULT 'general'::text NOT NULL,
    description text,
    severity text DEFAULT 'low'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    handled_by text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_auto_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_auto_settings (
    key text NOT NULL,
    value text DEFAULT 'true'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_campaigns (
    id text NOT NULL,
    name text NOT NULL,
    audience_type text NOT NULL,
    audience_id text,
    channel text NOT NULL,
    message text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    sent_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: notification_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_logs (
    id text NOT NULL,
    notification_id text,
    event_type text NOT NULL,
    customer_id text,
    booking_id text,
    channel text NOT NULL,
    template text,
    recipient text,
    message text,
    status text DEFAULT 'pending'::text NOT NULL,
    provider_response jsonb,
    sent_at timestamp with time zone,
    delivered_at timestamp with time zone,
    retry_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_name text,
    api_endpoint text,
    http_status integer,
    request_payload jsonb,
    error_code text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    customer_name text,
    booking_number text,
    wamid text
);


--
-- Name: notification_retry_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_retry_queue (
    id text NOT NULL,
    notification_log_id text,
    event_type text NOT NULL,
    channel text NOT NULL,
    customer_id text,
    booking_id text,
    recipient text NOT NULL,
    message text NOT NULL,
    context jsonb,
    retry_count integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    last_error text,
    next_retry_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_settings (
    id text NOT NULL,
    event_type text NOT NULL,
    channel text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    template_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id text NOT NULL,
    name text NOT NULL,
    event_type text,
    channel text NOT NULL,
    subject text,
    body text NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    meta_template_id text,
    botbee_template_id text,
    dlt_template_id text,
    dlt_entity_id text,
    sender_id text,
    provider text DEFAULT 'generic'::text,
    language text DEFAULT 'en'::text,
    category text DEFAULT 'UTILITY'::text,
    header_text text,
    footer_text text,
    buttons jsonb DEFAULT '[]'::jsonb,
    html_body text,
    rcs_agent_id text,
    rcs_campaign_id text,
    rich_card jsonb DEFAULT '{}'::jsonb,
    priority integer DEFAULT 0,
    enabled boolean DEFAULT true
);


--
-- Name: offline_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.offline_payments (
    id text NOT NULL,
    booking_id text NOT NULL,
    customer_id text,
    customer_name text,
    mobile text,
    email text,
    amount_paid numeric(12,2),
    payment_date text,
    payment_time text,
    bank_name text,
    branch_name text,
    payment_method text,
    utr_number text,
    sender_account_last4 text,
    remarks text,
    proof_url text,
    status text DEFAULT 'pending'::text NOT NULL,
    rejection_reason text,
    verified_at timestamp with time zone,
    verified_by text,
    verified_by_name text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    payment_reference text,
    admin_remarks text
);


--
-- Name: otps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.otps (
    id text NOT NULL,
    mobile text NOT NULL,
    otp text NOT NULL,
    used boolean DEFAULT false NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: package_media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_media (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    package_id character varying NOT NULL,
    type public.media_type DEFAULT 'image'::public.media_type NOT NULL,
    url text NOT NULL,
    caption text,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: package_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.package_requests (
    id text NOT NULL,
    customer_id text,
    package_id text,
    booking_id text,
    customer_name text NOT NULL,
    customer_mobile text NOT NULL,
    package_name text,
    message text,
    status public.request_status DEFAULT 'pending'::public.request_status NOT NULL,
    rejection_reason text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    group_id text,
    pilgrim_id text
);


--
-- Name: packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.packages (
    id text NOT NULL,
    name text NOT NULL,
    type public.package_type NOT NULL,
    description text,
    duration text,
    price_per_person numeric(12,2) NOT NULL,
    gst_percent numeric(5,2) DEFAULT '5'::numeric NOT NULL,
    includes jsonb DEFAULT '[]'::jsonb,
    highlights jsonb DEFAULT '[]'::jsonb,
    departure_dates jsonb DEFAULT '[]'::jsonb,
    max_pilgrims integer,
    image_url text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    featured boolean DEFAULT false NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    image_urls jsonb DEFAULT '[]'::jsonb,
    video_urls jsonb DEFAULT '[]'::jsonb
);


--
-- Name: payment_audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_audit_logs (
    id text NOT NULL,
    transaction_id text NOT NULL,
    booking_id text NOT NULL,
    action text NOT NULL,
    old_amount numeric(12,2),
    new_amount numeric(12,2),
    old_mode text,
    new_mode text,
    old_date text,
    new_date text,
    changed_by text,
    changed_by_name text,
    change_reason text,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_transactions (
    id text NOT NULL,
    booking_id text NOT NULL,
    amount numeric(12,2) NOT NULL,
    payment_date text NOT NULL,
    payment_mode public.payment_mode NOT NULL,
    reference_number text,
    notes text,
    recorded_by text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    bank_name text,
    received_by text,
    edited_at timestamp with time zone,
    edited_by text,
    deleted_at timestamp with time zone,
    deleted_by text,
    deletion_reason text,
    is_deleted boolean DEFAULT false NOT NULL,
    is_reconciled boolean DEFAULT false NOT NULL,
    reconciled_date text,
    reconciled_by text
);


--
-- Name: payroll_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_entries (
    id text NOT NULL,
    payroll_run_id text NOT NULL,
    employee_id text NOT NULL,
    month text NOT NULL,
    component_name text NOT NULL,
    component_type text DEFAULT 'earning'::text NOT NULL,
    amount numeric(12,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payroll_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_runs (
    id text NOT NULL,
    employee_id text NOT NULL,
    month text NOT NULL,
    present_days numeric(5,2) DEFAULT 26 NOT NULL,
    working_days numeric(5,2) DEFAULT 26 NOT NULL,
    gross_salary numeric(12,2) DEFAULT 0 NOT NULL,
    basic_salary numeric(12,2) DEFAULT 0 NOT NULL,
    hra numeric(12,2) DEFAULT 0 NOT NULL,
    allowances jsonb DEFAULT '{}'::jsonb NOT NULL,
    pf_deduction numeric(12,2) DEFAULT 0 NOT NULL,
    esi_deduction numeric(12,2) DEFAULT 0 NOT NULL,
    tds_deduction numeric(12,2) DEFAULT 0 NOT NULL,
    advance_deduction numeric(12,2) DEFAULT 0 NOT NULL,
    other_deductions numeric(12,2) DEFAULT 0 NOT NULL,
    total_deductions numeric(12,2) DEFAULT 0 NOT NULL,
    net_salary numeric(12,2) DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pilgrim_bus_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pilgrim_bus_assignments (
    id text NOT NULL,
    bus_id text NOT NULL,
    pilgrim_id text NOT NULL,
    seat_number text,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pilgrim_room_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pilgrim_room_assignments (
    id text NOT NULL,
    hotel_id text NOT NULL,
    room_id text NOT NULL,
    pilgrim_id text NOT NULL,
    assigned_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: pilgrims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pilgrims (
    id text NOT NULL,
    group_id text NOT NULL,
    serial_number integer NOT NULL,
    full_name text NOT NULL,
    passport_number text,
    visa_number text,
    date_of_birth text,
    gender text,
    blood_group text,
    photo_url text,
    mobile_india text,
    mobile_saudi text,
    address text,
    city text,
    state text,
    room_number text,
    bus_number text,
    relation text,
    cover_number text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    medical_condition text,
    room_type text,
    seat_number text,
    salutation text,
    passport_issue_date text,
    passport_expiry_date text,
    passport_place_of_issue text,
    room_hotel text,
    room_id text,
    barcode_id text,
    family_id text,
    family_relation text,
    family_head boolean DEFAULT false,
    room_notes text,
    visa_status text,
    visa_type text,
    visa_applied_date text,
    visa_received_date text
);


--
-- Name: pilgrims_families; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pilgrims_families (
    id text NOT NULL,
    group_id text NOT NULL,
    family_name text,
    head_pilgrim_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: reminder_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reminder_logs (
    id text NOT NULL,
    booking_id text NOT NULL,
    channel public.reminder_channel DEFAULT 'whatsapp'::public.reminder_channel NOT NULL,
    status public.reminder_status DEFAULT 'sent'::public.reminder_status NOT NULL,
    sent_at timestamp without time zone DEFAULT now() NOT NULL,
    triggered_by text DEFAULT 'cron'::text NOT NULL,
    notes text
);


--
-- Name: salary_components; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salary_components (
    id text NOT NULL,
    employee_id text NOT NULL,
    name text NOT NULL,
    type text DEFAULT 'earning'::text NOT NULL,
    calculation text DEFAULT 'fixed'::text NOT NULL,
    value numeric(12,2) DEFAULT 0 NOT NULL,
    basis text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: scheduled_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_notifications (
    id text NOT NULL,
    event_type text NOT NULL,
    channel text NOT NULL,
    recipient text NOT NULL,
    customer_id text,
    booking_id text,
    customer_name text,
    message text NOT NULL,
    subject text,
    scheduled_at timestamp with time zone NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: staff; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.staff (
    id text NOT NULL,
    staff_id text,
    company_id text DEFAULT 'alburhan'::text NOT NULL,
    full_name text NOT NULL,
    designation text,
    department text,
    role text DEFAULT 'airport_staff'::text NOT NULL,
    employee_code text,
    mobile_india text,
    blood_group text,
    date_of_birth text,
    address text,
    emergency_contact text,
    emergency_mobile text,
    joining_date text,
    valid_upto text,
    photo_url text,
    qr_token text,
    status text DEFAULT 'active'::text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    group_id text,
    father_name text,
    aadhaar_last_4 text
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    contact_name text,
    contact_mobile text,
    contact_email text,
    address text,
    city text,
    country text,
    gst_number text,
    payment_terms text,
    notes text,
    contract_expiry date,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: support_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_messages (
    id text NOT NULL,
    ticket_id text NOT NULL,
    sender_type text NOT NULL,
    sender_id text NOT NULL,
    sender_name text,
    message text NOT NULL,
    attachment_url text,
    is_internal boolean DEFAULT false NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT support_messages_sender_type_check CHECK ((sender_type = ANY (ARRAY['customer'::text, 'admin'::text])))
);


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_tickets (
    id text NOT NULL,
    ticket_number text NOT NULL,
    customer_id text NOT NULL,
    booking_id text,
    subject text NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    assigned_to text,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    priority text DEFAULT 'medium'::text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    assigned_to text,
    assigned_name text,
    due_date date,
    category text DEFAULT 'general'::text,
    booking_id text,
    created_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    mobile text NOT NULL,
    email text,
    role public.user_role DEFAULT 'customer'::public.user_role NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    admin_role text DEFAULT 'read_only'::text NOT NULL,
    assigned_group_ids text[] DEFAULT '{}'::text[] NOT NULL,
    blood_group text,
    emergency_contact_name text,
    emergency_contact_mobile text,
    profile_photo_url text,
    state text,
    city text,
    country text
);


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id text NOT NULL,
    name text NOT NULL,
    category text DEFAULT 'other'::text NOT NULL,
    gst_number text,
    pan text,
    bank_account text,
    ifsc text,
    contact text,
    email text,
    address text,
    notes text,
    is_active boolean DEFAULT true NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: wa_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wa_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    display_name text NOT NULL,
    category text DEFAULT 'UTILITY'::text NOT NULL,
    language text DEFAULT 'en'::text NOT NULL,
    status text DEFAULT 'local'::text NOT NULL,
    header_type text DEFAULT 'none'::text NOT NULL,
    header_text text,
    body_text text NOT NULL,
    footer_text text,
    buttons jsonb DEFAULT '[]'::jsonb NOT NULL,
    variables jsonb DEFAULT '[]'::jsonb NOT NULL,
    event_type text,
    meta_template_name text,
    enabled boolean DEFAULT true NOT NULL,
    is_builtin boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    template_id text
);


--
-- Name: workflow_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_logs (
    id integer NOT NULL,
    trigger_type text NOT NULL,
    booking_id text,
    customer_id text,
    customer_name text,
    status text DEFAULT 'pending'::text NOT NULL,
    error_message text,
    retry_count integer DEFAULT 0 NOT NULL,
    execution_time_ms integer,
    context jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: workflow_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflow_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflow_logs_id_seq OWNED BY public.workflow_logs.id;


--
-- Name: workflow_queue; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_queue (
    id integer NOT NULL,
    trigger_type text NOT NULL,
    booking_id text,
    customer_id text,
    context jsonb,
    status text DEFAULT 'pending'::text NOT NULL,
    scheduled_at timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflow_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflow_queue_id_seq OWNED BY public.workflow_queue.id;


--
-- Name: workflow_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_rules (
    id integer NOT NULL,
    name text NOT NULL,
    trigger_type text NOT NULL,
    description text,
    enabled boolean DEFAULT true NOT NULL,
    group_name text DEFAULT 'general'::text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: workflow_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflow_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflow_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflow_rules_id_seq OWNED BY public.workflow_rules.id;


--
-- Name: ziyarat_attendance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ziyarat_attendance (
    id integer NOT NULL,
    schedule_id text NOT NULL,
    pilgrim_id text NOT NULL,
    checked_in boolean DEFAULT false,
    check_in_time timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ziyarat_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ziyarat_attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ziyarat_attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ziyarat_attendance_id_seq OWNED BY public.ziyarat_attendance.id;


--
-- Name: ziyarat_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ziyarat_schedules (
    id text NOT NULL,
    name text NOT NULL,
    location text NOT NULL,
    city text DEFAULT 'Makkah'::text NOT NULL,
    schedule_date text NOT NULL,
    departure_time text,
    return_time text,
    bus_id text,
    group_id text,
    guide_name text,
    guide_mobile text,
    capacity integer DEFAULT 50,
    notes text,
    status text DEFAULT 'scheduled'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: admin_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_events ALTER COLUMN id SET DEFAULT nextval('public.admin_events_id_seq'::regclass);


--
-- Name: customer_timeline id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_timeline ALTER COLUMN id SET DEFAULT nextval('public.customer_timeline_id_seq'::regclass);


--
-- Name: delete_audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delete_audit_log ALTER COLUMN id SET DEFAULT nextval('public.delete_audit_log_id_seq'::regclass);


--
-- Name: workflow_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_logs ALTER COLUMN id SET DEFAULT nextval('public.workflow_logs_id_seq'::regclass);


--
-- Name: workflow_queue id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_queue ALTER COLUMN id SET DEFAULT nextval('public.workflow_queue_id_seq'::regclass);


--
-- Name: workflow_rules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_rules ALTER COLUMN id SET DEFAULT nextval('public.workflow_rules_id_seq'::regclass);


--
-- Name: ziyarat_attendance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ziyarat_attendance ALTER COLUMN id SET DEFAULT nextval('public.ziyarat_attendance_id_seq'::regclass);


--
-- Name: account_opening_balances account_opening_balances_account_id_financial_year_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_opening_balances
    ADD CONSTRAINT account_opening_balances_account_id_financial_year_id_key UNIQUE (account_id, financial_year_id);


--
-- Name: account_opening_balances account_opening_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_opening_balances
    ADD CONSTRAINT account_opening_balances_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: admin_events admin_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_events
    ADD CONSTRAINT admin_events_pkey PRIMARY KEY (id);


--
-- Name: admin_notifications admin_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.admin_notifications
    ADD CONSTRAINT admin_notifications_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: agreement_audit_logs agreement_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agreement_audit_logs
    ADD CONSTRAINT agreement_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: agreements agreements_agreement_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_agreement_number_key UNIQUE (agreement_number);


--
-- Name: agreements agreements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_pkey PRIMARY KEY (id);


--
-- Name: agreements agreements_verification_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_verification_token_key UNIQUE (verification_token);


--
-- Name: api_settings api_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_settings
    ADD CONSTRAINT api_settings_pkey PRIMARY KEY (id);


--
-- Name: api_settings api_settings_provider_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_settings
    ADD CONSTRAINT api_settings_provider_key UNIQUE (provider);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: attendance_events attendance_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_events
    ADD CONSTRAINT attendance_events_pkey PRIMARY KEY (id);


--
-- Name: attendance_logs attendance_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attendance_logs
    ADD CONSTRAINT attendance_logs_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_settings bank_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_settings
    ADD CONSTRAINT bank_settings_pkey PRIMARY KEY (id);


--
-- Name: booking_audit_logs booking_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_audit_logs
    ADD CONSTRAINT booking_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: booking_confirmation_notifications booking_confirmation_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_confirmation_notifications
    ADD CONSTRAINT booking_confirmation_notifications_pkey PRIMARY KEY (id);


--
-- Name: booking_settings booking_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.booking_settings
    ADD CONSTRAINT booking_settings_pkey PRIMARY KEY (id);


--
-- Name: bookings bookings_booking_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_booking_number_unique UNIQUE (booking_number);


--
-- Name: bookings bookings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bookings
    ADD CONSTRAINT bookings_pkey PRIMARY KEY (id);


--
-- Name: branches branches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.branches
    ADD CONSTRAINT branches_pkey PRIMARY KEY (id);


--
-- Name: broadcasts broadcasts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.broadcasts
    ADD CONSTRAINT broadcasts_pkey PRIMARY KEY (id);


--
-- Name: buses buses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.buses
    ADD CONSTRAINT buses_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: customer_notification_preferences customer_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notification_preferences
    ADD CONSTRAINT customer_notification_preferences_pkey PRIMARY KEY (customer_id);


--
-- Name: customer_notifications customer_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_notifications
    ADD CONSTRAINT customer_notifications_pkey PRIMARY KEY (id);


--
-- Name: customer_profiles customer_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT customer_profiles_pkey PRIMARY KEY (id);


--
-- Name: customer_profiles customer_profiles_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT customer_profiles_user_id_unique UNIQUE (user_id);


--
-- Name: customer_push_tokens customer_push_tokens_customer_id_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_push_tokens
    ADD CONSTRAINT customer_push_tokens_customer_id_token_key UNIQUE (customer_id, token);


--
-- Name: customer_push_tokens customer_push_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_push_tokens
    ADD CONSTRAINT customer_push_tokens_pkey PRIMARY KEY (id);


--
-- Name: customer_timeline customer_timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_timeline
    ADD CONSTRAINT customer_timeline_pkey PRIMARY KEY (id);


--
-- Name: delete_audit_log delete_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.delete_audit_log
    ADD CONSTRAINT delete_audit_log_pkey PRIMARY KEY (id);


--
-- Name: document_download_logs document_download_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_download_logs
    ADD CONSTRAINT document_download_logs_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: employee_advances employee_advances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_advances
    ADD CONSTRAINT employee_advances_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: financial_years financial_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_years
    ADD CONSTRAINT financial_years_pkey PRIMARY KEY (id);


--
-- Name: gallery_images gallery_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gallery_images
    ADD CONSTRAINT gallery_images_pkey PRIMARY KEY (id);


--
-- Name: group_flights group_flights_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_flights
    ADD CONSTRAINT group_flights_pkey PRIMARY KEY (id);


--
-- Name: group_tracking group_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_tracking
    ADD CONSTRAINT group_tracking_pkey PRIMARY KEY (group_id);


--
-- Name: hajj_groups hajj_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hajj_groups
    ADD CONSTRAINT hajj_groups_pkey PRIMARY KEY (id);


--
-- Name: hajj_rooms hajj_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hajj_rooms
    ADD CONSTRAINT hajj_rooms_pkey PRIMARY KEY (id);


--
-- Name: holy_site_allocations holy_site_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.holy_site_allocations
    ADD CONSTRAINT holy_site_allocations_pkey PRIMARY KEY (id);


--
-- Name: hotel_rooms hotel_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotel_rooms
    ADD CONSTRAINT hotel_rooms_pkey PRIMARY KEY (id);


--
-- Name: hotels hotels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hotels
    ADD CONSTRAINT hotels_pkey PRIMARY KEY (id);


--
-- Name: inquiries inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_entry_lines journal_entry_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_lines
    ADD CONSTRAINT journal_entry_lines_pkey PRIMARY KEY (id);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: loyalty_points loyalty_points_customer_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_points
    ADD CONSTRAINT loyalty_points_customer_id_key UNIQUE (customer_id);


--
-- Name: loyalty_points loyalty_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_points
    ADD CONSTRAINT loyalty_points_pkey PRIMARY KEY (id);


--
-- Name: loyalty_transactions loyalty_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loyalty_transactions
    ADD CONSTRAINT loyalty_transactions_pkey PRIMARY KEY (id);


--
-- Name: luggage_tags luggage_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.luggage_tags
    ADD CONSTRAINT luggage_tags_pkey PRIMARY KEY (id);


--
-- Name: luggage_tags luggage_tags_tag_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.luggage_tags
    ADD CONSTRAINT luggage_tags_tag_number_key UNIQUE (tag_number);


--
-- Name: marketing_campaigns marketing_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaigns
    ADD CONSTRAINT marketing_campaigns_pkey PRIMARY KEY (id);


--
-- Name: medical_cases medical_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.medical_cases
    ADD CONSTRAINT medical_cases_pkey PRIMARY KEY (id);


--
-- Name: notification_auto_settings notification_auto_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_auto_settings
    ADD CONSTRAINT notification_auto_settings_pkey PRIMARY KEY (key);


--
-- Name: notification_campaigns notification_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_campaigns
    ADD CONSTRAINT notification_campaigns_pkey PRIMARY KEY (id);


--
-- Name: notification_logs notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_logs
    ADD CONSTRAINT notification_logs_pkey PRIMARY KEY (id);


--
-- Name: notification_retry_queue notification_retry_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_retry_queue
    ADD CONSTRAINT notification_retry_queue_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_event_type_channel_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_event_type_channel_key UNIQUE (event_type, channel);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- Name: offline_payments offline_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_payments
    ADD CONSTRAINT offline_payments_pkey PRIMARY KEY (id);


--
-- Name: offline_payments offline_payments_utr_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.offline_payments
    ADD CONSTRAINT offline_payments_utr_number_key UNIQUE (utr_number);


--
-- Name: otps otps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.otps
    ADD CONSTRAINT otps_pkey PRIMARY KEY (id);


--
-- Name: package_media package_media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_media
    ADD CONSTRAINT package_media_pkey PRIMARY KEY (id);


--
-- Name: package_requests package_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_requests
    ADD CONSTRAINT package_requests_pkey PRIMARY KEY (id);


--
-- Name: packages packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.packages
    ADD CONSTRAINT packages_pkey PRIMARY KEY (id);


--
-- Name: payment_audit_logs payment_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_audit_logs
    ADD CONSTRAINT payment_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: payroll_entries payroll_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_entries
    ADD CONSTRAINT payroll_entries_pkey PRIMARY KEY (id);


--
-- Name: payroll_runs payroll_runs_employee_id_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_employee_id_month_key UNIQUE (employee_id, month);


--
-- Name: payroll_runs payroll_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_pkey PRIMARY KEY (id);


--
-- Name: pilgrim_bus_assignments pilgrim_bus_assignments_bus_id_pilgrim_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilgrim_bus_assignments
    ADD CONSTRAINT pilgrim_bus_assignments_bus_id_pilgrim_id_key UNIQUE (bus_id, pilgrim_id);


--
-- Name: pilgrim_bus_assignments pilgrim_bus_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilgrim_bus_assignments
    ADD CONSTRAINT pilgrim_bus_assignments_pkey PRIMARY KEY (id);


--
-- Name: pilgrim_room_assignments pilgrim_room_assignments_pilgrim_id_hotel_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilgrim_room_assignments
    ADD CONSTRAINT pilgrim_room_assignments_pilgrim_id_hotel_id_key UNIQUE (pilgrim_id, hotel_id);


--
-- Name: pilgrim_room_assignments pilgrim_room_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilgrim_room_assignments
    ADD CONSTRAINT pilgrim_room_assignments_pkey PRIMARY KEY (id);


--
-- Name: pilgrims_families pilgrims_families_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilgrims_families
    ADD CONSTRAINT pilgrims_families_pkey PRIMARY KEY (id);


--
-- Name: pilgrims pilgrims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pilgrims
    ADD CONSTRAINT pilgrims_pkey PRIMARY KEY (id);


--
-- Name: reminder_logs reminder_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminder_logs
    ADD CONSTRAINT reminder_logs_pkey PRIMARY KEY (id);


--
-- Name: salary_components salary_components_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_components
    ADD CONSTRAINT salary_components_pkey PRIMARY KEY (id);


--
-- Name: scheduled_notifications scheduled_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_notifications
    ADD CONSTRAINT scheduled_notifications_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: staff staff_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_pkey PRIMARY KEY (id);


--
-- Name: staff staff_qr_token_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_qr_token_unique UNIQUE (qr_token);


--
-- Name: staff staff_staff_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.staff
    ADD CONSTRAINT staff_staff_id_unique UNIQUE (staff_id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: support_messages support_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_ticket_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_ticket_number_key UNIQUE (ticket_number);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_mobile_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_mobile_unique UNIQUE (mobile);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: wa_templates wa_templates_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wa_templates
    ADD CONSTRAINT wa_templates_name_key UNIQUE (name);


--
-- Name: wa_templates wa_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wa_templates
    ADD CONSTRAINT wa_templates_pkey PRIMARY KEY (id);


--
-- Name: workflow_logs workflow_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_logs
    ADD CONSTRAINT workflow_logs_pkey PRIMARY KEY (id);


--
-- Name: workflow_queue workflow_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_queue
    ADD CONSTRAINT workflow_queue_pkey PRIMARY KEY (id);


--
-- Name: workflow_rules workflow_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_rules
    ADD CONSTRAINT workflow_rules_pkey PRIMARY KEY (id);


--
-- Name: workflow_rules workflow_rules_trigger_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_rules
    ADD CONSTRAINT workflow_rules_trigger_type_key UNIQUE (trigger_type);


--
-- Name: ziyarat_attendance ziyarat_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ziyarat_attendance
    ADD CONSTRAINT ziyarat_attendance_pkey PRIMARY KEY (id);


--
-- Name: ziyarat_attendance ziyarat_attendance_schedule_id_pilgrim_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ziyarat_attendance
    ADD CONSTRAINT ziyarat_attendance_schedule_id_pilgrim_id_key UNIQUE (schedule_id, pilgrim_id);


--
-- Name: ziyarat_schedules ziyarat_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ziyarat_schedules
    ADD CONSTRAINT ziyarat_schedules_pkey PRIMARY KEY (id);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- Name: accounts_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX accounts_code_idx ON public.accounts USING btree (code);


--
-- Name: admin_notif_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_notif_created_idx ON public.admin_notifications USING btree (created_at DESC);


--
-- Name: admin_notif_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX admin_notif_unread_idx ON public.admin_notifications USING btree (is_read) WHERE (is_read = false);


--
-- Name: agreements_booking_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agreements_booking_id_idx ON public.agreements USING btree (booking_id);


--
-- Name: agreements_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agreements_customer_id_idx ON public.agreements USING btree (customer_id);


--
-- Name: agreements_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agreements_status_idx ON public.agreements USING btree (status);


--
-- Name: agreements_token_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agreements_token_idx ON public.agreements USING btree (verification_token);


--
-- Name: al_actor_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX al_actor_idx ON public.audit_logs USING btree (actor_id);


--
-- Name: al_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX al_created_idx ON public.audit_logs USING btree (created_at);


--
-- Name: al_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX al_entity_idx ON public.audit_logs USING btree (entity_table, entity_id);


--
-- Name: bcn_booking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bcn_booking_idx ON public.booking_confirmation_notifications USING btree (booking_id);


--
-- Name: bookings_customer_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_customer_id_idx ON public.bookings USING btree (customer_id);


--
-- Name: bookings_group_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_group_id_idx ON public.bookings USING btree (group_id);


--
-- Name: bookings_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bookings_status_idx ON public.bookings USING btree (status);


--
-- Name: ddl_booking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ddl_booking_idx ON public.document_download_logs USING btree (booking_id);


--
-- Name: ddl_doc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ddl_doc_idx ON public.document_download_logs USING btree (document_id);


--
-- Name: ea_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ea_employee_idx ON public.employee_advances USING btree (employee_id);


--
-- Name: idx_loyalty_transactions_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loyalty_transactions_customer ON public.loyalty_transactions USING btree (customer_id);


--
-- Name: inv_booking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inv_booking_idx ON public.invoices USING btree (booking_id);


--
-- Name: jel_account_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jel_account_idx ON public.journal_entry_lines USING btree (account_id);


--
-- Name: jel_entry_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX jel_entry_idx ON public.journal_entry_lines USING btree (journal_entry_id);


--
-- Name: leads_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_source_idx ON public.leads USING btree (source);


--
-- Name: leads_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX leads_status_idx ON public.leads USING btree (status);


--
-- Name: nl_booking_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nl_booking_number_idx ON public.notification_logs USING btree (booking_number);


--
-- Name: nl_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nl_created_idx ON public.notification_logs USING btree (created_at DESC);


--
-- Name: nl_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nl_event_idx ON public.notification_logs USING btree (event_type);


--
-- Name: nl_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nl_status_idx ON public.notification_logs USING btree (status);


--
-- Name: nl_updated_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nl_updated_idx ON public.notification_logs USING btree (updated_at);


--
-- Name: notification_logs_booking_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX notification_logs_booking_id_idx ON public.notification_logs USING btree (booking_id);


--
-- Name: nrq_booking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nrq_booking_idx ON public.notification_retry_queue USING btree (booking_id);


--
-- Name: nrq_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nrq_status_idx ON public.notification_retry_queue USING btree (status, next_retry_at);


--
-- Name: offline_payments_booking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX offline_payments_booking_idx ON public.offline_payments USING btree (booking_id);


--
-- Name: offline_payments_customer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX offline_payments_customer_idx ON public.offline_payments USING btree (customer_id);


--
-- Name: offline_payments_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX offline_payments_ref_idx ON public.offline_payments USING btree (payment_reference) WHERE (payment_reference IS NOT NULL);


--
-- Name: pe_run_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pe_run_idx ON public.payroll_entries USING btree (payroll_run_id);


--
-- Name: pilgrims_group_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pilgrims_group_id_idx ON public.pilgrims USING btree (group_id);


--
-- Name: sc_employee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sc_employee_idx ON public.salary_components USING btree (employee_id);


--
-- Name: sm_ticket_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sm_ticket_idx ON public.support_messages USING btree (ticket_id);


--
-- Name: sn_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sn_status_idx ON public.scheduled_notifications USING btree (status, scheduled_at);


--
-- Name: st_customer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX st_customer_idx ON public.support_tickets USING btree (customer_id);


--
-- Name: st_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX st_status_idx ON public.support_tickets USING btree (status);


--
-- Name: suppliers_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX suppliers_type_idx ON public.suppliers USING btree (type);


--
-- Name: tasks_due_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_due_idx ON public.tasks USING btree (due_date);


--
-- Name: tasks_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tasks_status_idx ON public.tasks USING btree (status);


--
-- Name: timeline_booking_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX timeline_booking_idx ON public.customer_timeline USING btree (booking_id);


--
-- Name: timeline_customer_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX timeline_customer_idx ON public.customer_timeline USING btree (customer_id);


--
-- Name: wf_logs_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wf_logs_created_idx ON public.workflow_logs USING btree (created_at DESC);


--
-- Name: wf_logs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wf_logs_status_idx ON public.workflow_logs USING btree (status);


--
-- Name: agents agents_branch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_branch_id_fkey FOREIGN KEY (branch_id) REFERENCES public.branches(id) ON DELETE SET NULL;


--
-- Name: customer_profiles customer_profiles_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_profiles
    ADD CONSTRAINT customer_profiles_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: employee_advances employee_advances_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.employee_advances
    ADD CONSTRAINT employee_advances_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: package_requests package_requests_booking_id_bookings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_requests
    ADD CONSTRAINT package_requests_booking_id_bookings_id_fk FOREIGN KEY (booking_id) REFERENCES public.bookings(id) ON DELETE SET NULL;


--
-- Name: package_requests package_requests_customer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_requests
    ADD CONSTRAINT package_requests_customer_id_users_id_fk FOREIGN KEY (customer_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: package_requests package_requests_package_id_packages_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.package_requests
    ADD CONSTRAINT package_requests_package_id_packages_id_fk FOREIGN KEY (package_id) REFERENCES public.packages(id) ON DELETE SET NULL;


--
-- Name: payment_transactions payment_transactions_booking_id_bookings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_booking_id_bookings_id_fk FOREIGN KEY (booking_id) REFERENCES public.bookings(id);


--
-- Name: payroll_entries payroll_entries_payroll_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_entries
    ADD CONSTRAINT payroll_entries_payroll_run_id_fkey FOREIGN KEY (payroll_run_id) REFERENCES public.payroll_runs(id) ON DELETE CASCADE;


--
-- Name: payroll_runs payroll_runs_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_runs
    ADD CONSTRAINT payroll_runs_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: reminder_logs reminder_logs_booking_id_bookings_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminder_logs
    ADD CONSTRAINT reminder_logs_booking_id_bookings_id_fk FOREIGN KEY (booking_id) REFERENCES public.bookings(id);


--
-- Name: salary_components salary_components_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salary_components
    ADD CONSTRAINT salary_components_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: support_messages support_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_messages
    ADD CONSTRAINT support_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict H1AkvwTg9QkDeFVqNEZwmXk0yy0nOrHvPgLqn77ibCucUrFlN2I3dg9Gc5cuhqN

