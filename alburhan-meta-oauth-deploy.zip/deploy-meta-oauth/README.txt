Al Burhan API — v30.1-meta-oauth-callback
Build: 2026-07-31
Fix: GET /api/social-media/oauth/meta/callback returning "Cannot GET"

WHAT CHANGED
────────────
• Route now properly handles all Meta OAuth cases:
  - code + state present  → exchanges token, stores encrypted, redirects to /admin/social-oauth?connected=meta
  - error param present   → includes error_reason + error_description in redirect
  - missing code AND state → returns HTTP 400 JSON (not "Cannot GET")
• Access tokens encrypted in DB (never logged)
• App Secret never exposed in responses or logs

UPLOAD & INSTALL
────────────────
1. Upload this folder to VPS (e.g. via scp):
   scp -r alburhan-meta-oauth-deploy/ root@<VPS-IP>:/root/

2. SSH into VPS:
   ssh root@<VPS-IP>

3. Run the deploy script:
   cd /root/alburhan-meta-oauth-deploy
   bash deploy-backend.sh

4. Verify the OAuth callback is live:
   curl -i "http://127.0.0.1:3000/api/social-media/oauth/meta/callback"
   Expected: HTTP 400 + JSON {"success":false,"error":"Missing Meta OAuth code or state..."}

   curl -i "https://alburhantravels.online/api/social-media/oauth/meta/callback"
   Expected: same HTTP 400 JSON (nginx forwards /api/ to port 3000)

5. Full OAuth flow test:
   ERP → Social Media OAuth Hub → Connect Facebook/Instagram

ROLLBACK
────────
   cp /var/www/alburhan/artifacts/api-server/dist/index.cjs.backup-<date> \
      /var/www/alburhan/artifacts/api-server/dist/index.cjs
   pm2 restart alburhan-api
