#!/bin/bash
# ── Al Burhan API — backend-only hot-swap ────────────────────────────────────
# Usage: bash deploy-backend.sh
# Replaces /var/www/alburhan/artifacts/api-server/dist/index.cjs and restarts PM2.

set -e
DEST="/var/www/alburhan/artifacts/api-server/dist/index.cjs"
BACKUP="${DEST}.backup-$(date +%Y%m%d-%H%M%S)"
BUNDLE="$(dirname "$0")/index.cjs"

echo "=== Al Burhan API Deploy — v30.1-meta-oauth-callback ==="
echo "Bundle : $BUNDLE"
echo "Target : $DEST"

# Verify bundle exists and looks sane
if [ ! -f "$BUNDLE" ]; then echo "ERROR: bundle not found at $BUNDLE"; exit 1; fi
SIZE=$(stat -c%s "$BUNDLE" 2>/dev/null || stat -f%z "$BUNDLE")
if [ "$SIZE" -lt 5000000 ]; then echo "ERROR: bundle too small ($SIZE bytes), aborting"; exit 1; fi
node --check "$BUNDLE" || { echo "ERROR: node syntax check failed"; exit 1; }
echo "✅ Syntax OK, size=${SIZE} bytes"

# Backup current bundle
if [ -f "$DEST" ]; then
  cp "$DEST" "$BACKUP"
  echo "✅ Backed up to $BACKUP"
fi

# Install new bundle
mkdir -p "$(dirname "$DEST")"
cp "$BUNDLE" "$DEST"
echo "✅ Bundle installed"

# Kill zombie processes holding the port, then restart PM2
fuser -k 3000/tcp 2>/dev/null || true
sleep 1

PM2_PROC=$(pm2 list --no-color 2>/dev/null | grep -o 'alburhan-api\|alburhan-tours' | head -1)
if [ -n "$PM2_PROC" ]; then
  pm2 restart "$PM2_PROC" --update-env
  echo "✅ PM2 process '$PM2_PROC' restarted"
else
  pm2 start "$DEST" --name alburhan-api
  echo "✅ PM2 started new process: alburhan-api"
fi
pm2 save

sleep 3

# Health check
HTTP=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/api/health 2>/dev/null || echo "000")
echo "Health check: /api/health → HTTP $HTTP"

# OAuth callback check (should return 400 JSON, not 404)
OAUTH=$(curl -s -o /dev/null -w "%{http_code}" "http://127.0.0.1:3000/api/social-media/oauth/meta/callback" 2>/dev/null || echo "000")
echo "OAuth callback: /api/social-media/oauth/meta/callback → HTTP $OAUTH"

# Build stamp check
STAMP=$(curl -s "http://127.0.0.1:3000/api/version" 2>/dev/null | grep -o '"build":"[^"]*"' | head -1 || echo "unknown")
echo "Build stamp: $STAMP"

if [ "$HTTP" = "200" ] && [ "$OAUTH" = "400" ]; then
  echo ""
  echo "✅ Deploy successful — OAuth callback confirmed working"
  echo "   Now test: curl -i 'https://alburhantravels.online/api/social-media/oauth/meta/callback'"
else
  echo ""
  echo "⚠️  Unexpected responses. Checking PM2 logs:"
  pm2 logs alburhan-api --lines 20 --nostream 2>/dev/null || true
  if [ "$HTTP" != "200" ] && [ -f "$BACKUP" ]; then
    echo "⚠️  Health check failed — restoring backup"
    cp "$BACKUP" "$DEST"
    pm2 restart "$PM2_PROC" 2>/dev/null || true
    echo "Backup restored. Investigate PM2 logs."
    exit 1
  fi
fi
