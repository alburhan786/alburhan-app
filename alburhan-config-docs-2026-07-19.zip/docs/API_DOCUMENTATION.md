# Al Burhan Tours & Travels — REST API Documentation

**Base URL:** `https://alburhantravels.com/api`  
**Auth:** Session cookie (OTP login) · All admin endpoints require `role=admin`  
**Content-Type:** `application/json` (except file uploads: `multipart/form-data`)

---

## Authentication

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/auth/send-otp` | None | Send OTP to mobile number |
| POST | `/auth/verify-otp` | None | Verify OTP, create session |
| GET  | `/auth/me` | Session | Get current logged-in user |
| POST | `/auth/logout` | Session | Destroy session |

---

## Bookings

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/bookings` | Admin | List all bookings (filter by status, branch, agent) |
| POST | `/bookings` | Admin | Create offline booking |
| GET  | `/bookings/:id` | Admin | Get booking detail |
| PUT  | `/bookings/:id` | Admin | Update booking |
| DELETE | `/bookings/:id` | Admin | Soft delete (move to trash) |
| GET  | `/bookings/:id/timeline` | Admin | Booking event timeline |
| GET  | `/bookings/:id/audit-log` | Admin | Admin action audit log |
| GET  | `/bookings/:id/payments` | Admin | Payment transactions for booking |
| POST | `/bookings/:id/journey-status` | Admin | Update journey status (auto-notifies) |
| GET  | `/bookings/by-booking/:bookingId` | Admin | Find by booking number |
| GET  | `/bookings/reports/bookings` | Admin | Booking summary report |
| GET  | `/bookings/reports/payments` | Admin | Payment summary report |
| GET  | `/bookings/reports/departure-list` | Admin | Departure manifest |
| GET  | `/bookings/stats/:bookingId` | Admin | Single booking stats |

---

## Pilgrims & Hajj Groups

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/pilgrims` | Admin | All pilgrims |
| GET  | `/pilgrims/pilgrim/:pilgrimId` | Admin | Single pilgrim detail |
| GET  | `/hajj-groups` | Admin | All Hajj groups |
| POST | `/hajj-groups` | Admin | Create group |
| GET  | `/hajj-groups/:groupId/pilgrims` | Admin | Pilgrims in group |
| GET  | `/hajj-groups/:groupId/rooms` | Admin | Room assignments |
| GET  | `/hajj-groups/:groupId/families` | Admin | Family list |
| GET  | `/hajj-groups/:groupId/families/pdf` | Admin | Family list PDF |
| GET  | `/hajj-groups/:groupId/rooms/stickers/bulk-pdf` | Admin | Room stickers PDF |
| GET  | `/hajj-groups/:groupId/attendance/events` | Admin | Attendance events |
| GET  | `/hajj-groups/:groupId/haji-list/pdf` | Admin | Haji list PDF |
| GET  | `/hajj-groups/:groupId/families/export.xlsx` | Admin | XLSX export |

---

## Invoices

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/invoices` | Admin | All invoices |
| GET  | `/invoices/:id` | Admin | Invoice detail |
| GET  | `/invoices/:id/pdf` | Admin | Download invoice PDF |
| GET  | `/invoices/by-number/:bookingNumber/pdf` | None | Public invoice PDF (paid only) |
| POST | `/invoices/generate` | Admin | Generate missing invoices |
| POST | `/invoices/generate-16` | Admin | Batch generate 16 invoices |

---

## Payments

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/payments` | Admin | All payment transactions |
| POST | `/payments` | Admin | Record manual payment |
| GET  | `/payments/razorpay-key` | None | Get Razorpay public key |
| POST | `/payments/create-order` | None | Create Razorpay order |
| POST | `/payments/verify` | None | Verify Razorpay payment signature |
| POST | `/payments/create-link` | Admin | Create Razorpay payment link |
| GET  | `/payments/:id/payments/:txnId/history` | Admin | Transaction audit history |
| POST | `/payments/resend-notification/:bookingId` | Admin | Resend payment notification |
| GET  | `/offline-payments` | Admin | Bank transfer submissions |
| POST | `/offline-payments` | Customer | Submit bank transfer proof |
| POST | `/offline-payments/:id/approve` | Admin | Approve bank transfer |
| POST | `/offline-payments/:id/reject` | Admin | Reject bank transfer |

---

## Agreements

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/agreements` | Admin | All agreements |
| POST | `/agreements/generate` | Admin | Generate missing agreements |
| GET  | `/agreements/:id` | Admin | Agreement detail |
| GET  | `/agreements/:id/pdf` | Admin | Download agreement PDF |
| POST | `/agreements/:id/send` | Admin | Send agreement to customer |
| GET  | `/agreements/my` | Customer | My agreements |
| GET  | `/agreements/my/:id` | Customer | My agreement detail |
| POST | `/agreements/my/:id/request-otp` | Customer | Request signing OTP |
| POST | `/agreements/my/:id/sign` | Customer | Sign agreement (OTP verified) |

---

## Documents

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/documents` | Admin | All documents |
| POST | `/documents` | Admin | Upload document (multipart) |
| GET  | `/documents/:id` | Admin | Document detail |
| DELETE | `/documents/:id` | Admin | Delete document |
| POST | `/documents/:id/resend` | Admin | Re-deliver document to customer |
| GET  | `/documents/delivery-logs` | Admin | Document delivery audit |

---

## Notifications

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/notifications/logs` | Admin | All notification logs |
| GET  | `/notifications/logs/:id` | Admin | Single log detail |
| GET  | `/notifications/retry-queue` | Admin | Failed notifications pending retry |
| GET  | `/notifications/auto-settings` | Admin | Auto-notification toggles |
| POST | `/notifications/auto-settings` | Admin | Update auto-notification settings |
| POST | `/notifications/test` | Admin | Fire test notification |
| GET  | `/notifications/stats` | Admin | Delivery stats |

---

## Business Intelligence

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/bi` | Admin | Full BI summary (revenue, bookings, geography, packages) |
| GET  | `/branches` | Admin | All branches |
| GET  | `/branches/:id/stats` | Admin | Branch dashboard stats |
| GET  | `/agents` | Admin | All agents |
| GET  | `/admin/stats` | Admin | Top-level admin dashboard stats |

---

## Accounting & Finance

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/accounting/balance-sheet` | Admin | Balance sheet |
| GET  | `/accounting/pl` | Admin | Profit & Loss |
| GET  | `/accounting/cashbook` | Admin | Cash book |
| GET  | `/accounting/bankbook` | Admin | Bank book |
| GET  | `/accounting/journal-entries` | Admin | Journal entries |
| GET  | `/accounting/ledger` | Admin | General ledger |
| GET  | `/accounting/purchase-register` | Admin | Purchase register |
| GET  | `/accounting/sales-register` | Admin | Sales register |
| GET  | `/accounting/bank-reconciliation` | Admin | Bank reconciliation |
| GET  | `/accounting/accounts` | Admin | Chart of accounts |
| POST | `/accounting/accounts` | Admin | Create account |

---

## Customer Portal

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/customer/booking/:bookingId` | Customer | My booking detail |
| GET  | `/customer/my` | Customer | My bookings list |
| GET  | `/customer/my-group-status/:bookingId` | Customer | Journey & group status |
| GET  | `/notifications/my` | Customer | My notifications |
| GET  | `/notifications/my/unread-count` | Customer | Unread notification count |

---

## System & Operations

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/health` | None | Server health check |
| GET  | `/healthz` | None | K8s/load balancer probe |
| GET  | `/system-health` | Admin | Full system diagnostic |
| POST | `/migrate/self-update` | MIGRATION_KEY | Hot-redeploy: build + PM2 restart |
| GET  | `/migrate/db-check` | Admin | DB connectivity check |
| POST | `/backfill-approved` | Admin | Backfill booking statuses |

---

## Packages & Leads

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/packages` | None | All active packages |
| GET  | `/packages/:id` | None | Package detail |
| POST | `/leads` | None | Submit website enquiry |
| GET  | `/leads` | Admin | All leads |
| POST | `/leads/:id/convert` | Admin | Convert lead to booking |

---

## Employees & Payroll

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/employees` | Admin | All employees |
| POST | `/employees` | Admin | Add employee |
| GET  | `/employees/:id/history` | Admin | Payroll history |
| GET  | `/employees/payslip/:id` | Admin | Payslip PDF |
| POST | `/payroll/runs` | Admin | Run payroll |

---

*87 database tables · 200+ REST endpoints · July 2026*
