# Al Burhan Tours & Travels — Production Backup
**Generated:** 19 July 2026  
**Version:** Production (alburhantravels.com)  
**Tech Stack:** React 18 + Vite · Express.js · PostgreSQL 15 · Node.js 20 · pnpm 9

---

## Contents of This Package

```
alburhan-backup-2026-07-19/
├── source/
│   ├── frontend/          React + Vite SPA (admin portal, customer portal, public site)
│   ├── backend/           Express.js API server (all routes, jobs, services)
│   ├── lib/               Shared packages (db schema, api-spec, api-client)
│   ├── scripts/           Deployment & recovery scripts
│   └── root-config/       pnpm-workspace.yaml, package.json, tsconfig, pm2, nginx
├── database/
│   ├── alburhan_full_dump_2026-07-19.sql   FULL schema + data (pg_dump)
│   ├── migrations/        Drizzle incremental migration SQL files
│   └── seed-*.sql         Package/hajj seed data
├── config/
│   ├── .env.example       All environment variables (no secrets)
│   ├── nginx-alburhan.conf Nginx reverse-proxy config (HTTPS + SPA)
│   └── ecosystem.config.cjs  PM2 process manager config
├── uploads/               All customer-uploaded documents & media
└── docs/
    ├── README.md           This file
    ├── API_DOCUMENTATION.md  Full REST API reference (200+ endpoints)
    └── BACKUP_MANIFEST.txt   Every file in this package with sizes
```

---

## Quick Restore — New VPS (Ubuntu 22.04)

### 1. Prerequisites
```bash
# Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# pnpm 9
npm install -g pnpm@9

# PM2
npm install -g pm2

# PostgreSQL 15
sudo apt install -y postgresql postgresql-contrib

# Nginx
sudo apt install -y nginx certbot python3-certbot-nginx
```

### 2. Create Database
```bash
sudo -u postgres psql << SQL
CREATE USER alburhan_user WITH PASSWORD 'STRONG_PASSWORD_HERE';
CREATE DATABASE alburhan_db OWNER alburhan_user;
GRANT ALL PRIVILEGES ON DATABASE alburhan_db TO alburhan_user;
SQL
```

### 3. Restore Database
```bash
# Full restore (schema + all data)
psql -U alburhan_user -d alburhan_db \
  -f database/alburhan_full_dump_2026-07-19.sql

# Verify
psql -U alburhan_user -d alburhan_db \
  -c "SELECT count(*) FROM bookings;"
# Expected: 26+ rows
```

### 4. Deploy Application Code
```bash
# Create app directory
sudo mkdir -p /var/www/alburhan
sudo chown $USER:$USER /var/www/alburhan

# Copy source code
cp -r source/* /var/www/alburhan/
cd /var/www/alburhan

# Install dependencies
pnpm install

# Copy uploads
cp -r uploads /var/www/alburhan/uploads
```

### 5. Configure Environment
```bash
cp config/.env.example /var/www/alburhan/.env
nano /var/www/alburhan/.env
# Fill in:
#   DATABASE_URL=postgresql://alburhan_user:PASSWORD@localhost:5432/alburhan_db
#   SESSION_SECRET=<generate: openssl rand -hex 32>
#   RAZORPAY_KEY_ID / RAZORPAY_SECRET
#   BOTBEE_API_KEY / BOTBEE_BUSINESS_ID / BOTBEE_PHONE_NUMBER_ID
#   FAST2SMS_API_KEY
#   SMTP_HOST / SMTP_USER / SMTP_PASS
#   MIGRATION_KEY / DELETE_ADMIN_PASSWORD
```

### 6. Build Frontend
```bash
cd /var/www/alburhan
pnpm --filter @workspace/alburhan run build
# Output: artifacts/alburhan/dist/public/
```

### 7. Build & Start Backend
```bash
cd /var/www/alburhan
# Build (uses esbuild via build-vps.sh)
bash build-vps.sh

# Start with PM2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup   # follow instructions to enable on boot

# Verify
curl http://localhost:5000/api/health
# Expected: {"status":"ok"}
```

### 8. Run Database Migrations
```bash
curl -X POST http://localhost:5000/api/migrate/self-update \
  -H "Content-Type: application/json" \
  -d '{"key":"YOUR_MIGRATION_KEY"}'
```

### 9. Configure Nginx
```bash
sudo cp config/nginx-alburhan.conf \
  /etc/nginx/sites-available/alburhan

sudo ln -s /etc/nginx/sites-available/alburhan \
  /etc/nginx/sites-enabled/

# Get SSL certificate
sudo certbot --nginx -d alburhantravels.com -d www.alburhantravels.com

sudo nginx -t && sudo systemctl reload nginx
```

### 10. Verify Production
```bash
# Run automated verification
bash scripts/deploy-vps.sh

# Manual checks:
curl https://alburhantravels.com/api/health
curl https://alburhantravels.com/api/auth/send-otp \
  -X POST -H "Content-Type: application/json" \
  -d '{"mobile":"9893225590"}'
```

---

## Application Architecture

### Portals
| Portal | URL Path | Auth |
|--------|----------|------|
| Public website | `/` | None |
| Customer dashboard | `/customer/dashboard` | OTP (mobile) |
| Admin portal | `/admin/dashboard` | OTP (admin mobile) |
| Branch portal | `/admin/branch-dashboard/:id` | Admin session |
| Agent portal | `/admin/agent-dashboard` | Admin session |

### Key Admin Modules
| Module | Description |
|--------|-------------|
| Bookings | Full booking lifecycle with 7 statuses |
| Hajj Groups | Pilgrim grouping, rooms, buses, flights |
| Invoices | Auto-generated, PDF, Razorpay payment links |
| Agreements | Digital Hajj agreements, OTP-signed |
| Payments | Online (Razorpay) + Offline (bank transfer) |
| Notifications | WhatsApp (BotBee) + SMS (Fast2SMS) + Email |
| Automation Center | 37 active rules, 24-step pipeline |
| Business Intelligence | Revenue, bookings, geography, packages |
| Documents | Passport, visa, tickets — auto-delivered |
| Employees | Staff, payroll, attendance |
| Accounting | Ledger, P&L, balance sheet, GST |
| Branches | Multi-branch with dashboards |
| Agents | Commission tracking |

### Database Schema
87 tables. Core tables:
- `users` — customers + admin accounts
- `bookings` — main booking record (50 columns)
- `pilgrims` — individual pilgrim details + family grouping
- `packages` — Hajj/Umrah package catalogue
- `payment_transactions` — all payment records
- `invoices` — invoice records linked to bookings
- `agreements` — digital signing with OTP verification
- `notification_logs` — every notification sent
- `hajj_groups` + `hajj_rooms` + `pilgrims_families` — group management
- `documents` — uploaded docs with GCS/disk storage
- `workflow_logs` + `workflow_rules` — automation engine

---

## Known Configuration Notes

1. **BotBee WhatsApp Templates** — Template names must match exactly what is
   approved in your BotBee dashboard. Set each `BOTBEE_*_TEMPLATE` env var.

2. **Fast2SMS DLT** — Requires DLT-registered sender ID and template IDs.
   The system auto-falls back to the Quick Route if DLT fails.

3. **Session table** — The `session` table is created automatically by
   `connect-pg-simple` on first boot. Ensure `DATABASE_URL` is correct before
   starting the server.

4. **PDF generation** — `pdfkit` reads font data from disk at runtime.
   Do NOT bundle pdfkit — it is marked external in `build-vps.sh`.

5. **Uploads directory** — Set `UPLOADS_DIR` in `.env` and ensure the path
   exists with write permissions: `mkdir -p /var/www/alburhan/uploads`

6. **Self-update endpoint** — `POST /api/migrate/self-update` with `MIGRATION_KEY`
   triggers a hot-redeploy (builds new bundle, then process.exit(0) for PM2 restart).

---

## Support & Recovery

- **Rollback DB:** `psql -U alburhan_user -d alburhan_db -f database/alburhan_full_dump_2026-07-19.sql`
- **PM2 logs:** `pm2 logs alburhan-tours`
- **Nginx logs:** `tail -f /var/log/nginx/error.log`
- **Restart app:** `pm2 restart alburhan-tours`
- **Rebuild frontend:** `pnpm --filter @workspace/alburhan run build`

---

*Al Burhan Tours & Travels — ERP v1.0 · Built on Replit · July 2026*
