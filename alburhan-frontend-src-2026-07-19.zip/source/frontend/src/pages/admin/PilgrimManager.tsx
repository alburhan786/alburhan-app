import type { ReactElement } from "react";
import { AdminLayout } from "@/components/layout/AdminLayout";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { useToast } from "@/hooks/use-toast";
import { useDeleteGuard } from "@/components/DeleteGuard";
import { Plus, Edit, Trash2, ArrowLeft, Upload, Printer, CreditCard, Luggage, Heart,
  Building2, Bus, DoorOpen, FileDown, Hotel, BedDouble, Users, Wand2, X, AlertTriangle, Sticker, Layers, UserCheck, QrCode, Star,
  Search, LayoutGrid, List, GitBranch, ChevronDown, Share2, RefreshCw, Zap, MessageCircle, GitMerge, Scissors,
  Pencil, ArrowLeftRight, Check } from "lucide-react";
import { Link, useRoute } from "wouter";
import { BulkImportModal } from "./BulkImportModal";
import QuickAddModal from "./QuickAddModal";
import * as XLSX from "xlsx";

const API = import.meta.env.VITE_API_URL || "";

const EXPORT_COLUMNS: { label: string; key: string }[] = [
  { label: "Serial No", key: "serialNumber" },
  { label: "Full Name", key: "fullName" },
  { label: "Salutation", key: "salutation" },
  { label: "Gender", key: "gender" },
  { label: "Date of Birth", key: "dateOfBirth" },
  { label: "Passport Number", key: "passportNumber" },
  { label: "Passport Issue Date", key: "passportIssueDate" },
  { label: "Passport Expiry Date", key: "passportExpiryDate" },
  { label: "Passport Place of Issue", key: "passportPlaceOfIssue" },
  { label: "Visa Number", key: "visaNumber" },
  { label: "Blood Group", key: "bloodGroup" },
  { label: "Mobile India", key: "mobileIndia" },
  { label: "Mobile Saudi", key: "mobileSaudi" },
  { label: "City", key: "city" },
  { label: "State", key: "state" },
  { label: "Address", key: "address" },
  { label: "Bus Number", key: "busNumber" },
  { label: "Seat Number", key: "seatNumber" },
  { label: "Cover Number", key: "coverNumber" },
  { label: "Relation", key: "relation" },
  { label: "Medical Condition", key: "medicalCondition" },
];

interface Pilgrim {
  id: string;
  serialNumber: number;
  fullName: string;
  passportNumber?: string;
  visaNumber?: string;
  dateOfBirth?: string;
  gender?: string;
  bloodGroup?: string;
  photoUrl?: string;
  mobileIndia?: string;
  mobileSaudi?: string;
  address?: string;
  city?: string;
  state?: string;
  roomNumber?: string;
  roomType?: string;
  roomHotel?: string;
  roomId?: string;
  busNumber?: string;
  seatNumber?: string;
  relation?: string;
  coverNumber?: string;
  medicalCondition?: string;
  salutation?: string;
  passportIssueDate?: string;
  passportExpiryDate?: string;
  passportPlaceOfIssue?: string;
  familyId?: string;
  familyRelation?: string;
  familyHead?: boolean;
}

interface FamilyGroup {
  familyId: string;
  members: Pilgrim[];
  head: Pilgrim | null;
  roomNumber?: string | null;
  roomHotel?: string | null;
  roomId?: string | null;
  busNumber?: string | null;
  memberAttendance?: Record<string, { attended: number; total: number }>;
}

interface DetectionSuggestion {
  id: number;
  pilgrimIds: string[];
  memberNames: string[];
  reason: string;
  suggestedFamilyId: string;
  existingFamilyId?: string;
}

interface Group {
  id: string;
  groupName: string;
  year: number;
  startingSerialNumber?: number;
  departureDate?: string;
  returnDate?: string;
  flightNumber?: string;
  maktabNumber?: string;
  hotels?: any;
}

interface HajjRoom {
  id: string;
  groupId: string;
  roomNumber: string;
  hotel: string;
  totalBeds: number;
  occupiedBeds: number;
  roomType: string;
  floor?: string;
  notes?: string;
}

const emptyPilgrim = {
  fullName: "", passportNumber: "", visaNumber: "", dateOfBirth: "", gender: "",
  bloodGroup: "", mobileIndia: "", mobileSaudi: "", address: "", city: "",
  state: "", roomNumber: "", roomType: "", roomHotel: "", busNumber: "", seatNumber: "",
  relation: "", coverNumber: "", medicalCondition: "",
  salutation: "", passportIssueDate: "", passportExpiryDate: "", passportPlaceOfIssue: "",
  serialNumber: "",
};

const emptyRoomForm = {
  roomNumber: "", hotel: "makkah", totalBeds: "4", roomType: "gents", floor: "", notes: "",
};

const HOTEL_LABELS: Record<string, string> = { makkah: "Makkah", madinah: "Madinah", aziziah: "Aziziah" };
const HOTEL_COLORS: Record<string, string> = {
  makkah: "bg-emerald-100 text-emerald-800",
  madinah: "bg-sky-100 text-sky-800",
  aziziah: "bg-violet-100 text-violet-800",
};
const ROOM_TYPE_LABELS: Record<string, string> = { family: "Family", ladies: "Ladies", gents: "Gents" };
const ROOM_TYPE_COLORS: Record<string, string> = {
  family: "bg-amber-100 text-amber-800",
  ladies: "bg-pink-100 text-pink-800",
  gents: "bg-blue-100 text-blue-800",
};
const HOTEL_ORDER = ["makkah", "madinah", "aziziah"];

const FAMILY_PALETTE = [
  { bg: "bg-blue-50", header: "bg-blue-100" },
  { bg: "bg-emerald-50", header: "bg-emerald-100" },
  { bg: "bg-purple-50", header: "bg-purple-100" },
  { bg: "bg-amber-50", header: "bg-amber-100" },
  { bg: "bg-rose-50", header: "bg-rose-100" },
  { bg: "bg-cyan-50", header: "bg-cyan-100" },
  { bg: "bg-orange-50", header: "bg-orange-100" },
  { bg: "bg-teal-50", header: "bg-teal-100" },
  { bg: "bg-indigo-50", header: "bg-indigo-100" },
  { bg: "bg-pink-50", header: "bg-pink-100" },
];

function QrImg({ value, size = 72 }: { value: string; size?: number }) {
  const src = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(value)}&color=0d5040&bgcolor=ffffff`;
  return <img src={src} alt="QR" width={size} height={size} style={{ display: "block" }} />;
}

export default function PilgrimManager() {
  const [, params] = useRoute("/admin/groups/:groupId/pilgrims");
  const groupId = params?.groupId || "";

  const initialTab = (): "pilgrims" | "rooms" | "families" => {
    try {
      const p = new URLSearchParams(window.location.search).get("tab");
      if (p === "families" || p === "rooms") return p;
    } catch {}
    return "pilgrims";
  };
  const [activeTab, setActiveTab] = useState<"pilgrims" | "rooms" | "families">(initialTab);
  const [group, setGroup] = useState<Group | null>(null);
  const [pilgrims, setPilgrims] = useState<Pilgrim[]>([]);
  const [rooms, setRooms] = useState<HajjRoom[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyPilgrim);
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploadingId, setUploadingId] = useState<string | null>(null);
  const [downloadingPdf, setDownloadingPdf] = useState(false);
  const { toast } = useToast();
  const { requestDelete } = useDeleteGuard();

  const [roomDialogOpen, setRoomDialogOpen] = useState(false);
  const [editingRoomId, setEditingRoomId] = useState<string | null>(null);
  const [roomForm, setRoomForm] = useState(emptyRoomForm);
  const [autoAllocating, setAutoAllocating] = useState(false);
  const [downloadingRoomPdf, setDownloadingRoomPdf] = useState(false);
  const [downloadingBulkStickers, setDownloadingBulkStickers] = useState(false);
  const [deleteConfirmRoomId, setDeleteConfirmRoomId] = useState<string | null>(null);
  const [bulkRoomDialogOpen, setBulkRoomDialogOpen] = useState(false);
  const [bulkRoomForm, setBulkRoomForm] = useState({ hotel: "makkah", roomType: "gents", totalBeds: "4", floor: "", fromRoom: "", toRoom: "" });
  const [bulkAdding, setBulkAdding] = useState(false);
  const [bulkImportOpen, setBulkImportOpen] = useState(false);
  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [editingSerial, setEditingSerial] = useState<{ id: string; value: string } | null>(null);
  const [generatingBarcodes, setGeneratingBarcodes] = useState(false);
  const [editingFamilyId, setEditingFamilyId] = useState<{ id: string; value: string } | null>(null);
  const [families, setFamilies] = useState<FamilyGroup[]>([]);
  const [familyAllocating, setFamilyAllocating] = useState(false);
  const [expandedFamilies, setExpandedFamilies] = useState<Set<string>>(new Set());
  const [downloadingFamilyPdf, setDownloadingFamilyPdf] = useState(false);
  const [familyView, setFamilyView] = useState<"card" | "table" | "tree">("card");
  const [familySearch, setFamilySearch] = useState("");
  const [autoDetecting, setAutoDetecting] = useState(false);
  const [detectDialogOpen, setDetectDialogOpen] = useState(false);
  const [suggestions, setSuggestions] = useState<DetectionSuggestion[]>([]);
  const [acceptedSuggestions, setAcceptedSuggestions] = useState<Set<number>>(new Set());
  const [suggestionFamilyIds, setSuggestionFamilyIds] = useState<Record<number, string>>({});
  const [applyingSuggestions, setApplyingSuggestions] = useState(false);
  const [resequencing, setResequencing] = useState(false);
  const [reportsOpen, setReportsOpen] = useState(false);
  const [waFamily, setWaFamily] = useState<FamilyGroup | null>(null);
  const [waMessage, setWaMessage] = useState("");
  const [waSending, setWaSending] = useState(false);
  const [syncPromptData, setSyncPromptData] = useState<{
    familyId: string; familySize: number; roomNumber: string; busNumber: string; roomHotel: string; flightNumber?: string;
  } | null>(null);
  const [syncingFamily, setSyncingFamily] = useState(false);

  const [mergeSourceFam, setMergeSourceFam] = useState<FamilyGroup | null>(null);
  const [mergeTargetId, setMergeTargetId] = useState("");
  const [mergePending, setMergePending] = useState(false);

  const [splitFam, setSplitFam] = useState<FamilyGroup | null>(null);
  const [splitSelectedIds, setSplitSelectedIds] = useState<string[]>([]);
  const [splitPending, setSplitPending] = useState(false);

  const [roomNumAllocOpen, setRoomNumAllocOpen] = useState(false);
  const [roomNumAllocStart, setRoomNumAllocStart] = useState("1501");
  const [roomNumAllocPrefix, setRoomNumAllocPrefix] = useState("");
  const [roomNumAllocHotel, setRoomNumAllocHotel] = useState("makkah");
  const [roomNumAllocForce, setRoomNumAllocForce] = useState(false);
  const [roomNumAllocating, setRoomNumAllocating] = useState(false);

  const [roomSummaryOpen, setRoomSummaryOpen] = useState(false);
  const [roomSummaryData, setRoomSummaryData] = useState<any[]>([]);
  const [roomSummaryLoading, setRoomSummaryLoading] = useState(false);
  const [editingRoom, setEditingRoom] = useState<{ familyId: string; value: string } | null>(null);
  const [swapSelectA, setSwapSelectA] = useState<string | null>(null);
  const [swapPending, setSwapPending] = useState(false);
  const [highlightedFamilyId, setHighlightedFamilyId] = useState<string | null>(null);
  const [pilgrimSearch, setPilgrimSearch] = useState("");
  const [groupByFamily, setGroupByFamily] = useState(false);
  const [pilgrimSortBy, setPilgrimSortBy] = useState<"serial" | "family" | "room" | "bus" | "hotel">("serial");
  const [collapsedFamilies, setCollapsedFamilies] = useState<Set<string>>(new Set());

  const fetchData = useCallback(async () => {
    try {
      const [gRes, pRes, rRes] = await Promise.all([
        fetch(`${API}/api/groups/${groupId}`, { credentials: "include" }),
        fetch(`${API}/api/groups/${groupId}/pilgrims`, { credentials: "include" }),
        fetch(`${API}/api/groups/${groupId}/rooms`, { credentials: "include" }),
      ]);
      if (gRes.ok) setGroup(await gRes.json());
      if (pRes.ok) setPilgrims(await pRes.json());
      if (rRes.ok) setRooms(await rRes.json());
    } catch {} finally { setLoading(false); }
  }, [groupId]);

  const fetchFamilies = useCallback(async () => {
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families`, { credentials: "include" });
      if (res.ok) setFamilies(await res.json());
    } catch {}
  }, [groupId]);

  useEffect(() => { if (groupId) fetchData(); }, [groupId, fetchData]);
  useEffect(() => { if (groupId && activeTab === "families") fetchFamilies(); }, [groupId, activeTab, fetchFamilies]);

  const generateBarcodes = async () => {
    setGeneratingBarcodes(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/pilgrims/generate-barcodes`, {
        method: "POST",
        credentials: "include",
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Failed");
      toast({ title: "Barcodes Generated", description: `${data.generated} new · ${data.skipped} already had barcodes` });
      await fetchData();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setGeneratingBarcodes(false);
    }
  };

  const exportToExcel = () => {
    const safeName = (group?.groupName ?? groupId).replace(/[^a-zA-Z0-9\u0600-\u06FF]+/g, "-");
    const headers = ["Family ID", "Family Head", "Family Relation", ...EXPORT_COLUMNS.map(c => c.label)];
    const aoa: (string | number)[][] = [headers];

    if (groupByFamily && familyGroupsForDisplay) {
      familyGroupsForDisplay.families.forEach(([familyId, members]) => {
        const head = members.find(m => m.familyHead) || members[0];
        members.forEach(p => {
          aoa.push([
            familyId,
            head?.fullName ?? "",
            p.familyRelation ?? "",
            ...EXPORT_COLUMNS.map(c => (p as any)[c.key] ?? ""),
          ]);
        });
        aoa.push(Array(headers.length).fill(""));
      });
      if (familyGroupsForDisplay.ungrouped.length > 0) {
        familyGroupsForDisplay.ungrouped.forEach(p => {
          aoa.push(["—", "—", "—", ...EXPORT_COLUMNS.map(c => (p as any)[c.key] ?? "")]);
        });
      }
    } else {
      sortedPilgrims.forEach(p => {
        aoa.push([
          p.familyId ?? "—",
          p.familyHead ? p.fullName : "",
          p.familyRelation ?? "",
          ...EXPORT_COLUMNS.map(c => (p as any)[c.key] ?? ""),
        ]);
      });
    }

    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = headers.map((_, i) => ({ wch: i < 3 ? 16 : i === 3 ? 10 : 22 }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Pilgrims");
    XLSX.writeFile(wb, `pilgrims-${groupByFamily ? "by-family-" : ""}${safeName}.xlsx`);
  };

  const openCreate = () => { setEditingId(null); setForm(emptyPilgrim); setDialogOpen(true); };
  const openEdit = (p: Pilgrim) => {
    setEditingId(p.id);
    setForm({
      fullName: p.fullName || "", passportNumber: p.passportNumber || "", visaNumber: p.visaNumber || "",
      dateOfBirth: p.dateOfBirth || "", gender: p.gender || "", bloodGroup: p.bloodGroup || "",
      mobileIndia: p.mobileIndia || "", mobileSaudi: p.mobileSaudi || "", address: p.address || "",
      city: p.city || "", state: p.state || "", roomNumber: p.roomNumber || "",
      roomType: p.roomType || "", roomHotel: p.roomHotel || "", busNumber: p.busNumber || "", seatNumber: p.seatNumber || "",
      relation: p.relation || "", coverNumber: p.coverNumber || "",
      medicalCondition: p.medicalCondition || "",
      salutation: p.salutation || "",
      passportIssueDate: p.passportIssueDate || "",
      passportExpiryDate: p.passportExpiryDate || "",
      passportPlaceOfIssue: p.passportPlaceOfIssue || "",
      serialNumber: String(p.serialNumber ?? ""),
    });
    setDialogOpen(true);
  };

  const handleSerialUpdate = async (p: Pilgrim, newVal: string) => {
    const n = parseInt(newVal, 10);
    if (isNaN(n) || n < 1) { fetchData(); return; }
    if (n === p.serialNumber) { setEditingSerial(null); return; }
    try {
      await fetch(`${API}/api/groups/${groupId}/pilgrims/${p.id}`, {
        method: "PUT", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: p.fullName, passportNumber: p.passportNumber, visaNumber: p.visaNumber,
          dateOfBirth: p.dateOfBirth, gender: p.gender, bloodGroup: p.bloodGroup,
          mobileIndia: p.mobileIndia, mobileSaudi: p.mobileSaudi, address: p.address,
          city: p.city, state: p.state, busNumber: p.busNumber, seatNumber: p.seatNumber,
          relation: p.relation, coverNumber: p.coverNumber, medicalCondition: p.medicalCondition,
          salutation: p.salutation, passportIssueDate: p.passportIssueDate,
          passportExpiryDate: p.passportExpiryDate, passportPlaceOfIssue: p.passportPlaceOfIssue,
          serialNumber: n,
        }),
      });
      toast({ title: `Serial updated to ${n}` });
      fetchData();
    } catch { toast({ title: "Failed to update serial", variant: "destructive" }); }
    setEditingSerial(null);
  };

  const handleSave = async () => {
    if (!form.fullName) { toast({ title: "Name is required", variant: "destructive" }); return; }
    const originalPilgrim = editingId ? pilgrims.find(p => p.id === editingId) : null;
    try {
      const url = editingId
        ? `${API}/api/groups/${groupId}/pilgrims/${editingId}`
        : `${API}/api/groups/${groupId}/pilgrims`;
      const res = await fetch(url, {
        method: editingId ? "PUT" : "POST", credentials: "include",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify(form),
      });
      if (!res.ok) throw new Error("Failed");
      toast({ title: editingId ? "Pilgrim updated" : "Pilgrim added" });
      setDialogOpen(false);
      fetchData();
      if (activeTab === "families") fetchFamilies();

      if (editingId && originalPilgrim?.familyHead && originalPilgrim?.familyId) {
        const fId = originalPilgrim.familyId;
        const roomChanged = form.roomNumber !== (originalPilgrim.roomNumber || "");
        const busChanged = form.busNumber !== (originalPilgrim.busNumber || "");
        const hotelChanged = (form.roomHotel || "") !== (originalPilgrim.roomHotel || "");
        if (roomChanged || busChanged || hotelChanged) {
          // Use pilgrims state (always loaded) rather than families state (only loaded when Families tab is active)
          const nonHeadCount = pilgrims.filter(p => p.familyId === fId && !p.familyHead).length;
          if (nonHeadCount > 0) {
            setSyncPromptData({ familyId: fId, familySize: nonHeadCount, roomNumber: form.roomNumber, busNumber: form.busNumber, roomHotel: form.roomHotel || "", flightNumber: group?.flightNumber || "" });
          }
        }
      }
    } catch { toast({ title: "Error saving pilgrim", variant: "destructive" }); }
  };

  const handleDelete = (id: string, name?: string) => {
    requestDelete(`Pilgrim${name ? `: ${name}` : ""}`, async (token) => {
      await fetch(`${API}/api/groups/${groupId}/pilgrims/${id}`, {
        method: "DELETE", credentials: "include",
        headers: { "X-Delete-Token": token },
      });
      toast({ title: "Pilgrim deleted" });
      fetchData();
    });
  };

  const handlePhotoUpload = async (pilgrimId: string, file: File) => {
    setUploadingId(pilgrimId);
    try {
      const fd = new FormData();
      fd.append("photo", file);
      const res = await fetch(`${API}/api/groups/${groupId}/pilgrims/${pilgrimId}/photo`, {
        method: "POST", credentials: "include", body: fd,
      });
      if (!res.ok) throw new Error("Upload failed");
      toast({ title: "Photo uploaded" });
      fetchData();
    } catch { toast({ title: "Upload failed", variant: "destructive" }); }
    finally { setUploadingId(null); }
  };

  const handleDownloadPdf = async () => {
    setDownloadingPdf(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/haji-list/pdf`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `haji-list-${group?.groupName || groupId}-${group?.year || ""}.pdf`;
      a.click(); window.URL.revokeObjectURL(url);
      toast({ title: "Haji List PDF downloaded!" });
    } catch { toast({ title: "Failed to download PDF", variant: "destructive" }); }
    finally { setDownloadingPdf(false); }
  };

  const openCreateRoom = () => { setEditingRoomId(null); setRoomForm(emptyRoomForm); setRoomDialogOpen(true); };
  const openEditRoom = (r: HajjRoom) => {
    setEditingRoomId(r.id);
    setRoomForm({
      roomNumber: r.roomNumber, hotel: r.hotel, totalBeds: String(r.totalBeds),
      roomType: r.roomType, floor: r.floor || "", notes: r.notes || "",
    });
    setRoomDialogOpen(true);
  };

  const handleRoomSave = async () => {
    if (!roomForm.roomNumber || !roomForm.hotel || !roomForm.roomType) {
      toast({ title: "Room number, hotel and type are required", variant: "destructive" }); return;
    }
    try {
      const url = editingRoomId
        ? `${API}/api/groups/${groupId}/rooms/${editingRoomId}`
        : `${API}/api/groups/${groupId}/rooms`;
      const res = await fetch(url, {
        method: editingRoomId ? "PUT" : "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...roomForm, totalBeds: Number(roomForm.totalBeds) }),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.message || "Failed");
      }
      toast({ title: editingRoomId ? "Room updated" : "Room created" });
      setRoomDialogOpen(false);
      fetchData();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Error saving room";
      toast({ title: msg, variant: "destructive" });
    }
  };

  const handleRoomDelete = async (id: string) => {
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/rooms/${id}/delete`, {
        method: "POST", credentials: "include",
      });
      if (!res.ok) {
        let msg = `HTTP ${res.status}`;
        try { const d = await res.json(); msg = d.message || msg; } catch {}
        throw new Error(msg);
      }
      toast({ title: "Room deleted" });
      setDeleteConfirmRoomId(null);
      fetchData();
    } catch (err: any) {
      toast({ title: err?.message || "Error deleting room", variant: "destructive" });
    }
  };

  const handleAutoAllocate = async () => {
    setAutoAllocating(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/rooms/auto-allocate`, {
        method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
      });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      toast({
        title: "Rooms auto-allocated!",
        description: `${data.assigned} pilgrims assigned · ${data.unassigned} unassigned`,
      });
      fetchData();
    } catch { toast({ title: "Auto-allocation failed", variant: "destructive" }); }
    finally { setAutoAllocating(false); }
  };

  const handleDownloadRoomPdf = async () => {
    setDownloadingRoomPdf(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/rooms/list/pdf`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `room-list-${group?.groupName || groupId}-${group?.year || ""}.pdf`;
      a.click(); window.URL.revokeObjectURL(url);
      toast({ title: "Room List PDF downloaded!" });
    } catch { toast({ title: "Failed to download PDF", variant: "destructive" }); }
    finally { setDownloadingRoomPdf(false); }
  };

  const handleRemovePilgrimFromRoom = async (pilgrimId: string) => {
    const pilgrim = pilgrims.find(p => p.id === pilgrimId);
    if (!pilgrim) return;
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/pilgrims/${pilgrimId}`, {
        method: "PUT", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...pilgrim, roomNumber: null, roomHotel: null, roomId: null }),
      });
      if (!res.ok) throw new Error("Failed");
      toast({ title: "Pilgrim removed from room" });
      fetchData();
    } catch { toast({ title: "Error removing pilgrim from room", variant: "destructive" }); }
  };

  const handleAssignPilgrimToRoom = async (pilgrimId: string, selectedRoomId: string | null) => {
    const pilgrim = pilgrims.find(p => p.id === pilgrimId);
    if (!pilgrim) return;
    const targetRoom = selectedRoomId ? rooms.find(r => r.id === selectedRoomId) : null;
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/pilgrims/${pilgrimId}`, {
        method: "PUT", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...pilgrim,
          roomNumber: targetRoom?.roomNumber || null,
          roomHotel: targetRoom?.hotel || null,
          roomId: selectedRoomId || null,
        }),
      });
      if (!res.ok) throw new Error("Failed");
      toast({ title: targetRoom ? `Assigned to Room ${targetRoom.roomNumber} (${HOTEL_LABELS[targetRoom.hotel] || targetRoom.hotel})` : "Room assignment cleared" });
      fetchData();
    } catch { toast({ title: "Error assigning pilgrim to room", variant: "destructive" }); }
  };

  const handleDownloadBulkStickers = async () => {
    setDownloadingBulkStickers(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/rooms/stickers/bulk-pdf`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `room-stickers-${group?.groupName || groupId}-${group?.year || ""}.pdf`;
      a.click(); window.URL.revokeObjectURL(url);
      toast({ title: "Bulk Stickers PDF downloaded!" });
    } catch { toast({ title: "Failed to download stickers PDF", variant: "destructive" }); }
    finally { setDownloadingBulkStickers(false); }
  };

  const handleFamilyIdUpdate = async (p: Pilgrim, newVal: string) => {
    const newFamilyId = newVal.trim().toUpperCase() || null;
    if ((newFamilyId || null) === (p.familyId || null)) { setEditingFamilyId(null); return; }
    try {
      await fetch(`${API}/api/groups/${groupId}/pilgrims/${p.id}`, {
        method: "PUT", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...p, familyId: newFamilyId, serialNumber: p.serialNumber }),
      });
      await fetchData();
      if (activeTab === "families") await fetchFamilies();
    } catch { toast({ title: "Failed to update family ID", variant: "destructive" }); }
    setEditingFamilyId(null);
  };

  const handleToggleFamilyHead = async (p: Pilgrim) => {
    try {
      await fetch(`${API}/api/groups/${groupId}/pilgrims/${p.id}`, {
        method: "PUT", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...p, familyHead: !p.familyHead, serialNumber: p.serialNumber }),
      });
      toast({ title: p.familyHead ? "Removed as family head" : "Set as family head" });
      await fetchData();
      if (activeTab === "families") await fetchFamilies();
    } catch { toast({ title: "Failed to update", variant: "destructive" }); }
  };

  const handleFamilyAutoAllocate = async () => {
    setFamilyAllocating(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/auto-allocate`, {
        method: "POST", credentials: "include", headers: { "Content-Type": "application/json" },
      });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      toast({
        title: "Family-wise rooms allocated!",
        description: `${data.assigned} pilgrims assigned · ${data.unassigned} unassigned`,
      });
      await fetchData();
      await fetchFamilies();
    } catch { toast({ title: "Family auto-allocation failed", variant: "destructive" }); }
    finally { setFamilyAllocating(false); }
  };

  const handleDownloadFamilyPdf = async () => {
    setDownloadingFamilyPdf(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/pdf`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `family-list-${group?.groupName || groupId}-${group?.year || ""}.pdf`;
      a.click(); window.URL.revokeObjectURL(url);
      toast({ title: "Family List PDF downloaded!" });
    } catch { toast({ title: "Failed to download family list PDF", variant: "destructive" }); }
    finally { setDownloadingFamilyPdf(false); }
  };

  const handleAssignFamilyToRoom = async (familyId: string, roomId: string | null) => {
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/${encodeURIComponent(familyId)}/assign-room`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ roomId }),
      });
      if (!res.ok) throw new Error("Failed");
      const targetRoom = roomId ? rooms.find(r => r.id === roomId) : null;
      toast({ title: targetRoom ? `Family ${familyId} → Room ${targetRoom.roomNumber}` : `Family ${familyId} room cleared` });
      await fetchData();
      await fetchFamilies();
    } catch { toast({ title: "Failed to assign family to room", variant: "destructive" }); }
  };

  const doMerge = async () => {
    if (!mergeSourceFam || !mergeTargetId) return;
    setMergePending(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/merge`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceFamily: mergeSourceFam.familyId, targetFamily: mergeTargetId }),
      });
      const data = await res.json();
      if (!res.ok) { toast({ title: data.message || "Merge failed", variant: "destructive" }); return; }
      const targetFam = families.find(f => f.familyId === mergeTargetId);
      toast({ title: `${mergeSourceFam.familyId} merged into ${mergeTargetId} — ${data.newTotal} members` });
      setMergeSourceFam(null);
      setMergeTargetId("");
      await fetchFamilies();
    } catch { toast({ title: "Merge failed", variant: "destructive" }); }
    finally { setMergePending(false); }
  };

  const openSplitModal = (fam: FamilyGroup) => {
    setSplitFam(fam);
    setSplitSelectedIds([]);
  };

  const doSplit = async () => {
    if (!splitFam || splitSelectedIds.length === 0) return;
    setSplitPending(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/${encodeURIComponent(splitFam.familyId)}/split`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pilgrimIds: splitSelectedIds }),
      });
      const data = await res.json();
      if (!res.ok) { toast({ title: data.message || "Split failed", variant: "destructive" }); return; }
      toast({ title: `${data.splitCount} member${data.splitCount !== 1 ? "s" : ""} split into new family ${data.newFamilyId}` });
      setSplitFam(null);
      setSplitSelectedIds([]);
      await fetchFamilies();
    } catch { toast({ title: "Split failed", variant: "destructive" }); }
    finally { setSplitPending(false); }
  };

  const handleAutoAllocateRooms = async () => {
    const start = parseInt(roomNumAllocStart, 10);
    if (!start || isNaN(start)) { toast({ title: "Enter a valid starting room number", variant: "destructive" }); return; }
    setRoomNumAllocating(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/auto-allocate-rooms`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ startRoom: start, prefix: roomNumAllocPrefix.trim(), hotel: roomNumAllocHotel, force: roomNumAllocForce }),
      });
      const data = await res.json();
      if (!res.ok) { toast({ title: data.message || "Allocation failed", variant: "destructive" }); return; }
      // Persist last-used values for this group
      const k = `roomAlloc:${groupId}`;
      localStorage.setItem(`${k}:start`, String(data.nextRoom ?? start));
      localStorage.setItem(`${k}:prefix`, roomNumAllocPrefix.trim());
      localStorage.setItem(`${k}:hotel`, roomNumAllocHotel);
      toast({
        title: `Rooms allocated!`,
        description: `${data.assigned} pilgrims assigned · ${data.skipped} skipped · Next room: ${data.nextRoom}`,
      });
      setRoomNumAllocOpen(false);
      await fetchData();
      await fetchFamilies();
    } catch { toast({ title: "Room allocation failed", variant: "destructive" }); }
    finally { setRoomNumAllocating(false); }
  };

  const fetchRoomSummary = async () => {
    setRoomSummaryLoading(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/room-summary`, { credentials: "include" });
      if (!res.ok) { toast({ title: "Failed to load room summary", variant: "destructive" }); return; }
      const data = await res.json();
      if (!Array.isArray(data)) { toast({ title: "Unexpected response from server", variant: "destructive" }); return; }
      setRoomSummaryData(data);
      setRoomSummaryOpen(true);
    } catch { toast({ title: "Failed to load room summary", variant: "destructive" }); }
    finally { setRoomSummaryLoading(false); }
  };

  const handleChangeRoomNumber = async (familyId: string, newRoomNumber: string) => {
    if (!newRoomNumber.trim()) return;
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/${familyId}/change-room-number`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ newRoomNumber: newRoomNumber.trim() }),
      });
      const data = await res.json();
      if (!res.ok) { toast({ title: data.message || "Failed to update room", variant: "destructive" }); return; }
      toast({ title: `Room updated to ${newRoomNumber}` });
      setEditingRoom(null);
      // Refresh summary in place
      const summaryRes = await fetch(`${API}/api/groups/${groupId}/families/room-summary`, { credentials: "include" });
      if (summaryRes.ok) { const d = await summaryRes.json(); if (Array.isArray(d)) setRoomSummaryData(d); }
    } catch { toast({ title: "Failed to update room number", variant: "destructive" }); }
  };

  const handleSwapRooms = async (familyBId: string) => {
    if (!swapSelectA || swapSelectA === familyBId) { setSwapSelectA(null); return; }
    setSwapPending(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/swap-rooms`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ familyAId: swapSelectA, familyBId }),
      });
      const data = await res.json();
      if (!res.ok) { toast({ title: data.message || "Swap failed", variant: "destructive" }); return; }
      toast({ title: `Rooms swapped!`, description: `${data.roomAFrom} ↔ ${data.roomBFrom}` });
      setSwapSelectA(null);
      const summaryRes = await fetch(`${API}/api/groups/${groupId}/families/room-summary`, { credentials: "include" });
      if (summaryRes.ok) { const d = await summaryRes.json(); if (Array.isArray(d)) setRoomSummaryData(d); }
    } catch { toast({ title: "Swap failed", variant: "destructive" }); }
    finally { setSwapPending(false); }
  };

  const exportRoomSummaryExcel = () => {
    if (!roomSummaryData.length) { toast({ title: "No room data to export" }); return; }
    const rows: any[] = [];
    for (const row of roomSummaryData) {
      for (const fam of row.families) {
        rows.push({
          "Room No": row.roomNumber,
          "Room Type": row.roomType,
          "Family ID": fam.familyId,
          "Family Head": fam.headName,
          "Members": fam.memberCount,
          "Total in Room": row.totalMembers,
        });
      }
    }
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(rows);
    ws["!cols"] = [{ wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 28 }, { wch: 10 }, { wch: 14 }];
    XLSX.utils.book_append_sheet(wb, ws, "Room Summary");
    XLSX.writeFile(wb, `room-summary-${group?.groupName || groupId}.xlsx`);
  };

  const handleAutoDetect = async () => {
    setAutoDetecting(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/auto-detect`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      if (data.suggestions.length === 0) {
        toast({ title: "No family groups detected", description: "Try assigning families manually in the Pilgrims tab." });
        return;
      }
      setSuggestions(data.suggestions);
      setAcceptedSuggestions(new Set(data.suggestions.map((s: DetectionSuggestion) => s.id)));
      setSuggestionFamilyIds(Object.fromEntries(data.suggestions.map((s: DetectionSuggestion) => [s.id, s.suggestedFamilyId])));
      setDetectDialogOpen(true);
    } catch { toast({ title: "Auto-detect failed", variant: "destructive" }); }
    finally { setAutoDetecting(false); }
  };

  const handleApplySuggestions = async () => {
    const accepted = suggestions.filter(s => acceptedSuggestions.has(s.id)).map(s => ({
      pilgrimIds: s.pilgrimIds,
      familyId: suggestionFamilyIds[s.id] || s.suggestedFamilyId,
      familyHeadId: s.pilgrimIds[0],
    }));
    if (accepted.length === 0) { toast({ title: "No suggestions selected", variant: "destructive" }); return; }
    setApplyingSuggestions(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/apply-suggestions`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ suggestions: accepted }),
      });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      toast({ title: `Applied ${data.applied} family group${data.applied !== 1 ? "s" : ""}!` });
      setDetectDialogOpen(false);
      await fetchData();
      await fetchFamilies();
    } catch { toast({ title: "Failed to apply suggestions", variant: "destructive" }); }
    finally { setApplyingSuggestions(false); }
  };

  const handleResequenceIds = async () => {
    setResequencing(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/auto-generate-ids`, { method: "POST", credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const data = await res.json();
      toast({ title: "IDs re-sequenced!", description: `${data.updated} famil${data.updated !== 1 ? "ies" : "y"} renamed to F001, F002… format` });
      await fetchData();
      await fetchFamilies();
    } catch { toast({ title: "Re-sequence failed", variant: "destructive" }); }
    finally { setResequencing(false); }
  };

  const openFamilyWA = (fam: FamilyGroup) => {
    const head = fam.head;
    const memberLines = fam.members.map(m =>
      `  • ${m.fullName}${m.familyRelation ? ` (${m.familyRelation})` : ""}${m.roomNumber ? ` — Rm ${m.roomNumber}` : ""}`
    ).join("\n");
    const lines = [
      "🕌 *Al Burhan Tours & Travels*",
      "",
      `Assalamu Alaikum, *${head?.fullName || "Pilgrim"}*! 🌙`,
      "",
      "Here are your family travel details:",
      "",
      `📋 *Family ID:* ${fam.familyId}`,
      `👨‍👩‍👧‍👦 *Members (${fam.members.length}):*`,
      memberLines,
      "",
      head?.roomNumber ? `🏨 *Room:* ${head.roomNumber}${head.roomHotel ? ` — ${HOTEL_LABELS[head.roomHotel] || head.roomHotel}` : ""}` : null,
      group?.flightNumber ? `✈️ *Flight:* ${group.flightNumber}` : null,
      head?.busNumber ? `🚌 *Bus:* ${head.busNumber}` : null,
      "",
      "May Allah accept your Hajj and grant you a blessed journey. 🤲",
      "",
      "— Al Burhan Tours & Travels",
    ].filter(l => l !== null).join("\n");
    setWaFamily(fam);
    setWaMessage(lines);
  };

  const sendFamilyWA = async () => {
    if (!waFamily) return;
    setWaSending(true);
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/${encodeURIComponent(waFamily.familyId)}/whatsapp`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: waMessage }),
      });
      const data = await res.json();
      if (data.sent) {
        toast({ title: `WhatsApp sent to ${waFamily.head?.fullName || waFamily.familyId}` });
        setWaFamily(null);
      } else if (data.waLink) {
        window.open(data.waLink, "_blank");
        toast({ title: "Opened WhatsApp — tap Send to deliver the message" });
        setWaFamily(null);
      } else {
        toast({ title: data.message || "Could not send", variant: "destructive" });
      }
    } catch { toast({ title: "WhatsApp failed", variant: "destructive" }); }
    finally { setWaSending(false); }
  };

  const exportFamiliesExcel = async () => {
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/export.xlsx`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `family-list-${(group?.groupName ?? groupId).replace(/[^a-zA-Z0-9]+/g, "-")}-${group?.year || ""}.xlsx`;
      a.click();
      window.URL.revokeObjectURL(url);
      toast({ title: "Excel file downloaded!" });
    } catch { toast({ title: "Excel export failed", variant: "destructive" }); }
  };

  const downloadFamilyReport = async (type: "pdf" | "flight-list" | "bus-list" | "hotel-list" | "badges", label: string) => {
    const epMap: Record<string, string> = { "pdf": "pdf", "flight-list": "flight-list/pdf", "bus-list": "bus-list/pdf", "hotel-list": "hotel-list/pdf", "badges": "badges/pdf" };
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/${epMap[type]}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      const ext = type === "badges" ? "pdf" : "pdf";
      a.href = url; a.download = `family-${type}-${group?.groupName || groupId}-${group?.year || ""}.${ext}`;
      a.click(); window.URL.revokeObjectURL(url);
      toast({ title: `${label} downloaded!` });
    } catch { toast({ title: `Failed to download ${label}`, variant: "destructive" }); }
  };

  const downloadFamilyBadges = async (familyId: string) => {
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/${encodeURIComponent(familyId)}/badges/pdf`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `badges-${familyId}-${(group?.groupName ?? groupId).replace(/[^a-zA-Z0-9]+/g, "-")}-${group?.year || ""}.pdf`;
      a.click(); window.URL.revokeObjectURL(url);
      toast({ title: `Badges PDF for ${familyId} downloaded!` });
    } catch { toast({ title: "Badges download failed", variant: "destructive" }); }
  };

  const handleWhatsAppShare = async () => {
    try {
      const res = await fetch(`${API}/api/groups/${groupId}/families/pdf`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed");
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `family-list-${group?.groupName || groupId}-${group?.year || ""}.pdf`;
      a.click(); window.URL.revokeObjectURL(url);
      const text = encodeURIComponent(`Al Burhan Tours & Travels — Family List for ${group?.groupName || ""} (${group?.year || ""}). PDF downloaded — please share.`);
      setTimeout(() => window.open(`https://wa.me/?text=${text}`, "_blank"), 500);
      toast({ title: "PDF downloaded — share it via WhatsApp" });
    } catch { toast({ title: "Failed", variant: "destructive" }); }
  };

  const f = (key: string, val: string) => setForm(prev => ({ ...prev, [key]: val }));
  const rf = (key: string, val: string) => setRoomForm(prev => ({ ...prev, [key]: val }));
  const brf = (key: string, val: string) => setBulkRoomForm(prev => ({ ...prev, [key]: val }));

  const handleBulkRoomAdd = async () => {
    const from = parseInt(bulkRoomForm.fromRoom, 10);
    const to = parseInt(bulkRoomForm.toRoom, 10);
    if (isNaN(from) || isNaN(to)) { toast({ title: "Enter valid room numbers", variant: "destructive" }); return; }
    if (from > to) { toast({ title: '"From" must be ≤ "To"', variant: "destructive" }); return; }
    if (to - from + 1 > 200) { toast({ title: "Range cannot exceed 200 rooms", variant: "destructive" }); return; }
    setBulkAdding(true);
    try {
      const rooms = [];
      for (let n = from; n <= to; n++) {
        rooms.push({ roomNumber: String(n), hotel: bulkRoomForm.hotel, totalBeds: Number(bulkRoomForm.totalBeds), roomType: bulkRoomForm.roomType, floor: bulkRoomForm.floor || undefined });
      }
      const res = await fetch(`${API}/api/groups/${groupId}/rooms/bulk`, {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify({ rooms }),
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.message || "Failed"); }
      const data = await res.json();
      toast({ title: `${data.created} rooms added successfully!` });
      setBulkRoomDialogOpen(false);
      setBulkRoomForm({ hotel: "makkah", roomType: "gents", totalBeds: "4", floor: "", fromRoom: "", toRoom: "" });
      fetchData();
    } catch (err: any) { toast({ title: err.message || "Failed to add rooms", variant: "destructive" }); }
    finally { setBulkAdding(false); }
  };

  const unassignedPilgrims = pilgrims.filter(p => !p.roomNumber);
  const familyCountMap = useMemo(() => {
    const map: Record<string, number> = {};
    for (const pg of pilgrims) {
      if (pg.familyId) map[pg.familyId] = (map[pg.familyId] || 0) + 1;
    }
    return map;
  }, [pilgrims]);

  const familyStats = useMemo(() => {
    const totalFamilies = families.length;
    const totalInFamilies = families.reduce((s, f) => s + f.members.length, 0);
    const avgSize = totalFamilies > 0 ? (totalInFamilies / totalFamilies).toFixed(1) : "0";
    const largestFamily = families.reduce((max, f) => Math.max(max, f.members.length), 0);
    const withoutRoom = families.filter(f => !f.members.some(m => m.roomNumber)).length;
    const withoutBus = families.filter(f => !f.members.some(m => m.busNumber)).length;
    return { totalFamilies, totalInFamilies, avgSize, largestFamily, withoutRoom, withoutBus };
  }, [families]);
  const filteredFamilies = familySearch.trim()
    ? families.filter(fam => {
        const q = familySearch.toLowerCase();
        if (fam.familyId.toLowerCase().includes(q)) return true;
        if ((fam.head?.fullName || "").toLowerCase().includes(q)) return true;
        if ((group?.flightNumber || "").toLowerCase().includes(q)) return true;
        return fam.members.some(m =>
          m.fullName.toLowerCase().includes(q) ||
          (m.passportNumber || "").toLowerCase().includes(q) ||
          (m.roomNumber || "").toLowerCase().includes(q) ||
          (m.busNumber || "").toLowerCase().includes(q)
        );
      })
    : families;
  const pilgrimsInRoom = (room: HajjRoom) =>
    pilgrims.filter(p => p.roomNumber === room.roomNumber && p.roomHotel === room.hotel);
  const numericRoom = (rn: string) => { const n = parseInt(rn, 10); return isNaN(n) ? Infinity : n; };
  const compareRoomNumbers = (a: string, b: string) => {
    const na = numericRoom(a), nb = numericRoom(b);
    if (na !== Infinity || nb !== Infinity) return na - nb;
    return a.localeCompare(b);
  };
  const sortedRooms = [...rooms].sort((a, b) => {
    const hi = HOTEL_ORDER.indexOf(a.hotel) - HOTEL_ORDER.indexOf(b.hotel);
    return hi !== 0 ? hi : compareRoomNumbers(a.roomNumber, b.roomNumber);
  });
  const pilgrimsForTable = [...pilgrims].sort((a, b) => {
    const ra = a.roomNumber, rb = b.roomNumber;
    if (ra !== rb) {
      if (!ra) return 1;
      if (!rb) return -1;
      return compareRoomNumbers(ra, rb);
    }
    return (a.serialNumber || 0) - (b.serialNumber || 0);
  });
  const roomCardClass = (r: HajjRoom) => {
    if (r.occupiedBeds >= r.totalBeds) return "border-red-300 bg-red-50";
    if (r.occupiedBeds > 0) return "border-amber-300 bg-amber-50";
    return "border-emerald-300 bg-emerald-50";
  };

  const filteredPilgrimsBase = useMemo(() => {
    if (!pilgrimSearch.trim()) return pilgrims;
    const q = pilgrimSearch.toLowerCase();
    const matchingFamilyIds = new Set<string>();
    for (const p of pilgrims) {
      const ok = p.fullName.toLowerCase().includes(q)
        || (p.passportNumber || "").toLowerCase().includes(q)
        || (p.familyId || "").toLowerCase().includes(q)
        || (p.roomNumber || "").toLowerCase().includes(q)
        || (p.busNumber || "").toLowerCase().includes(q)
        || (p.familyRelation || "").toLowerCase().includes(q)
        || (p.mobileIndia || "").toLowerCase().includes(q);
      if (ok && p.familyId) matchingFamilyIds.add(p.familyId);
    }
    return pilgrims.filter(p => {
      if (p.familyId && matchingFamilyIds.has(p.familyId)) return true;
      return p.fullName.toLowerCase().includes(q)
        || (p.passportNumber || "").toLowerCase().includes(q)
        || (p.familyId || "").toLowerCase().includes(q)
        || (p.roomNumber || "").toLowerCase().includes(q)
        || (p.busNumber || "").toLowerCase().includes(q)
        || (p.mobileIndia || "").toLowerCase().includes(q);
    });
  }, [pilgrimSearch, pilgrims]);

  const sortedPilgrims = useMemo(() => {
    const arr = [...filteredPilgrimsBase];
    switch (pilgrimSortBy) {
      case "family":
        return arr.sort((a, b) => {
          const fa = a.familyId || "\uffff", fb = b.familyId || "\uffff";
          if (fa !== fb) return fa.localeCompare(fb);
          if (a.familyHead && !b.familyHead) return -1;
          if (!a.familyHead && b.familyHead) return 1;
          return (a.serialNumber || 0) - (b.serialNumber || 0);
        });
      case "room":
        return arr.sort((a, b) => {
          if (!a.roomNumber && b.roomNumber) return 1;
          if (a.roomNumber && !b.roomNumber) return -1;
          if (!a.roomNumber && !b.roomNumber) return (a.serialNumber||0)-(b.serialNumber||0);
          return compareRoomNumbers(a.roomNumber!, b.roomNumber!);
        });
      case "bus":
        return arr.sort((a, b) => (a.busNumber || "\uffff").localeCompare(b.busNumber || "\uffff"));
      case "hotel":
        return arr.sort((a, b) => {
          const ha = HOTEL_ORDER.indexOf(a.roomHotel || ""), hb = HOTEL_ORDER.indexOf(b.roomHotel || "");
          return (ha === -1 ? 99 : ha) - (hb === -1 ? 99 : hb);
        });
      default:
        return arr.sort((a, b) => (a.serialNumber || 0) - (b.serialNumber || 0));
    }
  }, [filteredPilgrimsBase, pilgrimSortBy]);

  const familyGroupsForDisplay = useMemo(() => {
    if (!groupByFamily) return null;
    const map = new Map<string, Pilgrim[]>();
    const ungrouped: Pilgrim[] = [];
    for (const p of sortedPilgrims) {
      if (p.familyId) {
        if (!map.has(p.familyId)) map.set(p.familyId, []);
        map.get(p.familyId)!.push(p);
      } else {
        ungrouped.push(p);
      }
    }
    const families = [...map.entries()].sort((a, b) => a[0].localeCompare(b[0]));
    return { families, ungrouped };
  }, [groupByFamily, sortedPilgrims]);

  const renderPilgrimRow = (p: Pilgrim, rowClass: string) => (
    <tr key={p.id} className={rowClass}>
      <td className="px-4 py-3">
        {editingSerial?.id === p.id ? (
          <input autoFocus type="number" min="1"
            value={editingSerial.value}
            onChange={e => setEditingSerial({ id: p.id, value: e.target.value })}
            onBlur={() => handleSerialUpdate(p, editingSerial.value)}
            onKeyDown={e => {
              if (e.key === "Enter") handleSerialUpdate(p, editingSerial.value);
              if (e.key === "Escape") setEditingSerial(null);
            }}
            className="w-14 h-7 text-center font-mono font-bold text-primary border-2 border-primary rounded focus:outline-none text-sm"
          />
        ) : (
          <span title="Click to edit serial number"
            onClick={() => setEditingSerial({ id: p.id, value: String(p.serialNumber) })}
            className="font-mono font-bold text-primary cursor-pointer hover:bg-primary/10 px-1.5 py-0.5 rounded transition-colors">
            {p.serialNumber}
          </span>
        )}
      </td>
      <td className="px-4 py-3">
        <div className="w-10 h-10 rounded-lg bg-muted overflow-hidden cursor-pointer"
          onClick={() => { setUploadingId(p.id); fileRef.current?.click(); }}>
          {p.photoUrl
            ? <img src={`${API}${p.photoUrl}`} alt="" className="w-full h-full object-cover" />
            : <div className="w-full h-full flex items-center justify-center text-muted-foreground/40"><Upload size={14} /></div>}
        </div>
      </td>
      <td className="px-4 py-3 text-xs text-muted-foreground">{p.salutation || "—"}</td>
      <td className="px-4 py-3 font-medium">{p.fullName}</td>
      <td className="px-4 py-3 font-mono text-xs">{p.passportNumber || "—"}</td>
      <td className="px-4 py-3 text-xs">{p.mobileIndia || "—"}</td>
      <td className="px-4 py-3 text-xs">
        {p.roomNumber
          ? <span className="font-semibold">{p.roomNumber}{p.roomHotel ? ` · ${HOTEL_LABELS[p.roomHotel] || p.roomHotel}` : ""}</span>
          : "—"}
      </td>
      <td className="px-4 py-3">{p.busNumber || "—"}</td>
      <td className="px-4 py-3 text-xs">{p.relation || "—"}</td>
      <td
        className={`px-3 py-3 sticky right-[112px] z-10 border-l-2 border-gray-200 ${p.familyId && p.familyId === highlightedFamilyId ? "bg-blue-50" : "bg-white"}`}
        style={{minWidth:140}}
      >
        {editingFamilyId?.id === p.id ? (
          <input autoFocus type="text" placeholder="e.g. F01"
            value={editingFamilyId.value}
            onChange={e => setEditingFamilyId({ id: p.id, value: e.target.value })}
            onBlur={() => handleFamilyIdUpdate(p, editingFamilyId.value)}
            onKeyDown={e => {
              if (e.key === "Enter") handleFamilyIdUpdate(p, editingFamilyId.value);
              if (e.key === "Escape") setEditingFamilyId(null);
            }}
            className="w-24 h-7 text-center font-mono font-bold border-2 border-blue-400 rounded-lg focus:outline-none text-xs"
          />
        ) : p.familyId ? (() => {
          const count = familyCountMap[p.familyId] ?? 1;
          const isHead = p.familyHead;
          const isMissingData = !p.passportNumber;
          const badgeCls = isHead
            ? "bg-orange-500 hover:bg-orange-600 ring-orange-300"
            : isMissingData
            ? "bg-red-500 hover:bg-red-600 ring-red-300"
            : p.passportNumber
            ? "bg-green-600 hover:bg-green-700 ring-green-300"
            : "bg-blue-600 hover:bg-blue-700 ring-blue-300";
          return (
            <div className="flex flex-col gap-1">
              <button
                title={`Click to highlight family ${p.familyId}. Double-click to edit.`}
                onClick={() => setHighlightedFamilyId(prev => prev === p.familyId ? null : p.familyId!)}
                onDoubleClick={() => setEditingFamilyId({ id: p.id, value: p.familyId || "" })}
                className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-white font-bold text-xs cursor-pointer transition-all ring-2 ring-offset-1 select-none ${badgeCls}`}
              >
                <span>{isHead ? "👑" : "👨‍👩‍👧"}</span>
                <span className="font-mono">{p.familyId}</span>
                <span className="opacity-80">({count})</span>
              </button>
              <div className="flex items-center gap-1">
                <select
                  value={p.familyRelation || ""}
                  onChange={e => {
                    const val = e.target.value;
                    fetch(`${API}/api/groups/${groupId}/pilgrims/${p.id}`, {
                      method: "PUT", credentials: "include",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({ ...p, familyRelation: val || null }),
                    }).then(() => fetchData());
                  }}
                  className="h-5 text-[10px] rounded border border-gray-200 bg-gray-50 text-gray-700 px-1 max-w-[72px]"
                >
                  <option value="">Relation</option>
                  {["Self","Husband","Wife","Son","Daughter","Father","Mother","Brother","Sister","Nephew","Niece","Father in Law","Mother in Law","Bhabhi","Uncle","Aunty","Other"].map(r => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
                <button
                  title={isHead ? "Remove as family head" : "Set as family head"}
                  onClick={() => handleToggleFamilyHead(p)}
                  className={`transition-colors ${isHead ? "text-orange-500" : "text-muted-foreground/30 hover:text-orange-400"}`}
                >
                  <Star size={11} fill={isHead ? "currentColor" : "none"} />
                </button>
              </div>
            </div>
          );
        })() : (
          <button
            title="Click to set family ID"
            onClick={() => setEditingFamilyId({ id: p.id, value: "" })}
            className="text-xs text-muted-foreground/40 hover:text-blue-500 hover:bg-blue-50 px-2 py-1 rounded-full transition-colors font-medium border border-dashed border-gray-200 hover:border-blue-300"
          >
            + Family
          </button>
        )}
      </td>
      <td className={`px-3 py-3 text-right sticky right-0 z-10 ${p.familyId && p.familyId === highlightedFamilyId ? "bg-blue-50" : "bg-white"}`} style={{width:112}}>
        <div className="flex items-center justify-end gap-1">
          <Button variant="ghost" size="icon"
            title={`Print ID card for ${p.fullName}`}
            onClick={() => window.open(`/admin/groups/${groupId}/print/single-card/${p.id}`, "_blank")}
            className="text-emerald-700 hover:bg-emerald-50"
          >
            <Printer size={14} />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => openEdit(p)}><Edit size={14} /></Button>
          <Button variant="ghost" size="icon" className="text-red-600" onClick={() => handleDelete(p.id, p.fullName)}><Trash2 size={14} /></Button>
        </div>
      </td>
    </tr>
  );

  if (loading) return <AdminLayout><div className="py-12 text-center text-muted-foreground animate-pulse">Loading...</div></AdminLayout>;

  return (
    <AdminLayout>
      <div className="mb-6">
        <Link href="/admin/groups">
          <Button variant="ghost" size="sm" className="gap-1 mb-2"><ArrowLeft size={16} /> Back to Groups</Button>
        </Link>
        <div className="flex justify-between items-start flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-serif font-bold">{group?.groupName || "Group"}</h1>
            <p className="text-muted-foreground mt-1">{pilgrims.length} pilgrims · {rooms.length} rooms</p>
          </div>
          <div className="flex gap-2 flex-wrap items-center">
            <Button
              variant="outline" size="sm"
              className="gap-1.5 rounded-lg border-emerald-300 text-emerald-700 hover:bg-emerald-50"
              onClick={handleDownloadPdf} disabled={downloadingPdf}
            >
              <FileDown size={14} />
              {downloadingPdf ? "Generating..." : "Haji List PDF"}
            </Button>
            <div className="relative group">
              <Button variant="outline" size="sm" className="gap-1 rounded-lg"><Printer size={14} /> Print</Button>
              <div className="absolute right-0 top-full mt-1 bg-white border rounded-xl shadow-lg py-2 w-48 hidden group-hover:block z-50">
                <Link href={`/admin/groups/${groupId}/print/id-cards`}>
                  <span className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-muted cursor-pointer"><CreditCard size={14} /> ID Cards</span>
                </Link>
                <Link href={`/admin/groups/${groupId}/print/luggage`}>
                  <span className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-muted cursor-pointer"><Luggage size={14} /> Luggage Stickers</span>
                </Link>
                <Link href={`/admin/groups/${groupId}/print/medical`}>
                  <span className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-muted cursor-pointer"><Heart size={14} /> Medical Stickers</span>
                </Link>
                <Link href={`/admin/groups/${groupId}/print/hotel-list`}>
                  <span className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-muted cursor-pointer"><Building2 size={14} /> Hotel Room List</span>
                </Link>
                <Link href={`/admin/groups/${groupId}/print/bus-list`}>
                  <span className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-muted cursor-pointer"><Bus size={14} /> Bus List</span>
                </Link>
                <Link href={`/admin/groups/${groupId}/print/room-stickers`}>
                  <span className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-muted cursor-pointer"><DoorOpen size={14} /> Room Stickers</span>
                </Link>
              </div>
            </div>
            {activeTab === "pilgrims" && (
              <>
                <Button
                  variant="outline"
                  onClick={generateBarcodes}
                  disabled={generatingBarcodes || pilgrims.length === 0}
                  className="gap-1.5 rounded-xl border-purple-300 text-purple-700 hover:bg-purple-50"
                >
                  <Layers size={15} /> {generatingBarcodes ? "Generating…" : "Generate Barcodes"}
                </Button>
                <Button variant="outline" onClick={exportToExcel} disabled={pilgrims.length === 0} className="gap-1.5 rounded-xl border-emerald-300 text-emerald-700 hover:bg-emerald-50">
                  <FileDown size={15} /> Export Excel
                </Button>
                <Button variant="outline" onClick={() => setQuickAddOpen(true)} className="gap-1.5 rounded-xl border-amber-300 text-amber-700 hover:bg-amber-50">
                  <Zap size={15} /> Quick Add
                </Button>
                <Button variant="outline" onClick={() => setBulkImportOpen(true)} className="gap-1.5 rounded-xl border-blue-300 text-blue-700 hover:bg-blue-50">
                  <Upload size={15} /> Bulk Import
                </Button>
                <Button onClick={openCreate} className="bg-primary text-white gap-1 rounded-xl">
                  <Plus size={16} /> Add Pilgrim
                </Button>
              </>
            )}
            {activeTab === "rooms" && (
              <Button onClick={openCreateRoom} className="bg-primary text-white gap-1 rounded-xl">
                <Plus size={16} /> Add Room
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="flex flex-wrap gap-2 mb-4 p-3 bg-gradient-to-r from-[#0d5040]/5 to-[#C9A84C]/5 rounded-xl border border-[#0d5040]/10">
        {[
          { label: "Families", value: new Set(pilgrims.filter(p => p.familyId).map(p => p.familyId!)).size, color: "text-amber-700 bg-amber-50 border-amber-200" },
          { label: "Pilgrims", value: pilgrims.length, color: "text-emerald-700 bg-emerald-50 border-emerald-200" },
          { label: "Grouped", value: pilgrims.filter(p => p.familyId).length, color: "text-blue-700 bg-blue-50 border-blue-200" },
          { label: "Ungrouped", value: pilgrims.filter(p => !p.familyId).length, color: "text-orange-700 bg-orange-50 border-orange-200" },
          { label: "Rooms Assigned", value: pilgrims.filter(p => p.roomId).length, color: "text-purple-700 bg-purple-50 border-purple-200" },
          { label: "Flights Assigned", value: group?.flightNumber ? pilgrims.length : 0, color: "text-teal-700 bg-teal-50 border-teal-200" },
        ].map(stat => (
          <div key={stat.label} className={`flex flex-col items-center px-3 py-1.5 rounded-lg border text-xs font-semibold ${stat.color}`}>
            <span className="text-lg font-black leading-tight">{stat.value}</span>
            <span className="text-[10px] font-medium opacity-80">{stat.label}</span>
          </div>
        ))}
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 mb-6 border-b">
        <button
          onClick={() => setActiveTab("pilgrims")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors -mb-px ${activeTab === "pilgrims" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
        >
          <Users size={15} /> Pilgrims ({pilgrims.length})
        </button>
        <button
          onClick={() => setActiveTab("rooms")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors -mb-px ${activeTab === "rooms" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
        >
          <Hotel size={15} /> Room Management ({rooms.length})
        </button>
        <button
          onClick={() => setActiveTab("families")}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors -mb-px ${activeTab === "families" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
        >
          <UserCheck size={15} /> Families ({new Set(pilgrims.filter(p => p.familyId).map(p => p.familyId!)).size})
        </button>
        <Link href={`/admin/groups/${groupId}/attendance`}>
          <span className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold border-b-2 border-transparent text-muted-foreground hover:text-foreground transition-colors -mb-px cursor-pointer">
            <QrCode size={15} /> Attendance
          </span>
        </Link>
      </div>

      <input ref={fileRef} type="file" accept="image/*" className="hidden"
        onChange={e => { if (e.target.files?.[0] && uploadingId) handlePhotoUpload(uploadingId, e.target.files[0]); e.target.value = ""; }} />

      {/* ============ PILGRIMS TAB ============ */}
      {activeTab === "pilgrims" && (
        <div className="space-y-3">
          {/* Search + Sort + Group by Family toolbar */}
          <div className="flex flex-wrap gap-2 items-center">
            <div className="relative flex-1 min-w-[200px]">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              <input
                value={pilgrimSearch}
                onChange={e => setPilgrimSearch(e.target.value)}
                placeholder="Search name, passport, family ID, room, bus…"
                className="w-full pl-8 pr-8 h-9 rounded-xl border border-gray-200 text-sm focus:outline-none focus:border-primary bg-white"
              />
              {pilgrimSearch && (
                <button onClick={() => setPilgrimSearch("")} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700">
                  <X size={14} />
                </button>
              )}
            </div>
            <select
              value={pilgrimSortBy}
              onChange={e => setPilgrimSortBy(e.target.value as typeof pilgrimSortBy)}
              className="h-9 px-3 rounded-xl border border-gray-200 text-sm bg-white focus:outline-none focus:border-primary"
            >
              <option value="serial">Sort: Serial #</option>
              <option value="family">Sort: Family ID</option>
              <option value="room">Sort: Room No.</option>
              <option value="bus">Sort: Bus</option>
              <option value="hotel">Sort: Hotel</option>
            </select>
            <button
              onClick={() => { const next = !groupByFamily; setGroupByFamily(next); if (next && pilgrimSortBy === "serial") setPilgrimSortBy("family"); }}
              className={`flex items-center gap-2 h-9 px-4 rounded-xl border text-sm font-semibold transition-colors ${
                groupByFamily ? "bg-[#0d5040] text-white border-[#0d5040]" : "bg-white text-gray-600 border-gray-200 hover:border-[#0d5040] hover:text-[#0d5040]"
              }`}
            >
              <GitBranch size={14} />
              {groupByFamily ? "Family View ON" : "Group by Family"}
            </button>
            {groupByFamily && (
              <>
                <button onClick={() => setCollapsedFamilies(new Set())} className="h-9 px-3 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 whitespace-nowrap">Expand All</button>
                <button
                  onClick={() => { if (familyGroupsForDisplay) setCollapsedFamilies(new Set(familyGroupsForDisplay.families.map(([fid]) => fid))); }}
                  className="h-9 px-3 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 whitespace-nowrap"
                >Collapse All</button>
              </>
            )}
          </div>

          {pilgrimSearch.trim() && (
            <p className="text-xs text-muted-foreground px-1">
              <span className="font-semibold text-foreground">{sortedPilgrims.length}</span> pilgrim{sortedPilgrims.length !== 1 ? "s" : ""} found
              {groupByFamily && familyGroupsForDisplay
                ? ` across ${familyGroupsForDisplay.families.length} famil${familyGroupsForDisplay.families.length !== 1 ? "ies" : "y"}`
                : ""}
              {" · "}
              <button onClick={() => setPilgrimSearch("")} className="text-primary underline">Clear</button>
            </p>
          )}

          <Card className="border-none shadow-sm rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="bg-muted text-muted-foreground uppercase text-xs font-semibold">
                  <tr>
                    <th className="px-4 py-3">#</th>
                    <th className="px-4 py-3">Photo</th>
                    <th className="px-4 py-3">Title</th>
                    <th className="px-4 py-3">Name</th>
                    <th className="px-4 py-3">Passport</th>
                    <th className="px-4 py-3">Mobile</th>
                    <th className="px-4 py-3">Room</th>
                    <th className="px-4 py-3">Bus</th>
                    <th className="px-4 py-3">Relation</th>
                    <th className="px-3 py-3 sticky right-[112px] z-20 bg-muted border-l-2 border-gray-200" style={{minWidth:140}}>Family</th>
                    <th className="px-3 py-3 text-right sticky right-0 z-20 bg-muted" style={{width:112}}>Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {groupByFamily && familyGroupsForDisplay ? (
                    (() => {
                      if (familyGroupsForDisplay.families.length === 0 && familyGroupsForDisplay.ungrouped.length === 0)
                        return <tr><td colSpan={11} className="text-center py-8 text-muted-foreground">{pilgrimSearch ? `No pilgrims match "${pilgrimSearch}"` : "No pilgrims with a Family ID yet."}</td></tr>;
                      const rows: ReactElement[] = [];
                      familyGroupsForDisplay.families.forEach(([familyId, members], fi) => {
                        const head = members.find(m => m.familyHead) || members[0];
                        const isCollapsed = collapsedFamilies.has(familyId);
                        const pal = FAMILY_PALETTE[fi % FAMILY_PALETTE.length];
                        if (fi > 0) rows.push(
                          <tr key={`sp-${familyId}`}><td colSpan={11} style={{height:22,padding:0,background:"#f8fafc",borderTop:"2px solid #e2e8f0"}} /></tr>
                        );
                        rows.push(
                          <tr key={`hdr-${familyId}`} className={pal.header}>
                            <td colSpan={11} className="px-3 py-2.5 border-b border-gray-200">
                              <div className="flex items-center gap-3 flex-wrap">
                                <button
                                  onClick={() => setCollapsedFamilies(prev => { const s = new Set(prev); s.has(familyId) ? s.delete(familyId) : s.add(familyId); return s; })}
                                  className="flex items-center gap-2 flex-1 min-w-0 text-left"
                                >
                                  <ChevronDown size={15} className={`shrink-0 text-gray-500 transition-transform duration-200 ${isCollapsed ? "-rotate-90" : ""}`} />
                                  <span className="font-bold text-sm text-gray-800">
                                    👨‍👩‍👧‍👦 Family:&nbsp;<span className="font-mono text-[#0d5040]">{familyId}</span>
                                  </span>
                                  <span className="shrink-0 px-2 py-0.5 rounded-full text-[11px] font-bold bg-[#0d5040]/10 text-[#0d5040]">
                                    {members.length} member{members.length !== 1 ? "s" : ""}
                                  </span>
                                  {head && (
                                    <span className="text-xs text-gray-600 truncate">
                                      Head: <span className="font-semibold">{head.fullName}</span>
                                    </span>
                                  )}
                                </button>
                                <div className="flex items-center gap-3 text-xs text-gray-600 shrink-0 flex-wrap">
                                  {head?.roomNumber && (
                                    <span className="flex items-center gap-1">
                                      <BedDouble size={11} />
                                      <span className="font-semibold">{head.roomNumber}</span>
                                      {head.roomHotel && (
                                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${HOTEL_COLORS[head.roomHotel] || "bg-gray-100"}`}>
                                          {HOTEL_LABELS[head.roomHotel] || head.roomHotel}
                                        </span>
                                      )}
                                    </span>
                                  )}
                                  {head?.busNumber && (
                                    <span className="flex items-center gap-1">
                                      <Bus size={11} />
                                      <span className="font-semibold">{head.busNumber}</span>
                                    </span>
                                  )}
                                  {group?.flightNumber && (
                                    <span className="text-sky-600 font-semibold">✈ {group.flightNumber}</span>
                                  )}
                                </div>
                              </div>
                            </td>
                          </tr>
                        );
                        if (!isCollapsed) {
                          members.forEach((p, mi) => rows.push(renderPilgrimRow(p, `${mi % 2 === 0 ? pal.bg : "bg-white"} hover:brightness-95 transition-colors`)));
                        }
                      });
                      if (familyGroupsForDisplay.ungrouped.length > 0) {
                        if (familyGroupsForDisplay.families.length > 0)
                          rows.push(<tr key="sp-ungrouped"><td colSpan={11} style={{height:22,padding:0,background:"#f8fafc",borderTop:"2px solid #e2e8f0"}} /></tr>);
                        rows.push(
                          <tr key="hdr-ungrouped" className="bg-gray-100">
                            <td colSpan={11} className="px-4 py-2.5 border-b border-gray-200">
                              <span className="text-sm font-bold text-gray-500">⚪ Ungrouped Pilgrims ({familyGroupsForDisplay.ungrouped.length})</span>
                            </td>
                          </tr>
                        );
                        familyGroupsForDisplay.ungrouped.forEach(p => rows.push(renderPilgrimRow(p, "hover:bg-muted/30 transition-colors")));
                      }
                      return rows;
                    })()
                  ) : sortedPilgrims.length === 0 ? (
                    <tr><td colSpan={11} className="text-center py-8 text-muted-foreground">
                      {pilgrimSearch ? `No pilgrims match "${pilgrimSearch}"` : 'No pilgrims yet. Click "Add Pilgrim" to start.'}
                    </td></tr>
                  ) : (
                    sortedPilgrims.map(p =>
                      renderPilgrimRow(p, `transition-colors ${p.familyId && p.familyId === highlightedFamilyId ? "bg-blue-50" : "hover:bg-muted/30"}`)
                    )
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}

      {/* ============ ROOMS TAB ============ */}
      {activeTab === "rooms" && (
        <div className="space-y-6">

          {/* Action bar */}
          <div className="flex flex-wrap gap-2">
            <Button onClick={openCreateRoom} className="gap-1.5 rounded-xl bg-primary text-white">
              <Plus size={16} /> Add Room
            </Button>
            <Button onClick={() => setBulkRoomDialogOpen(true)} variant="outline" className="gap-1.5 rounded-xl border-primary text-primary hover:bg-primary/10">
              <Layers size={16} /> Bulk Add Rooms
            </Button>
            <div className="flex gap-1 rounded-xl border border-emerald-600 overflow-hidden">
              <Button
                onClick={handleAutoAllocate}
                disabled={autoAllocating || familyAllocating || rooms.length === 0}
                className="gap-1.5 rounded-none rounded-l-xl bg-emerald-600 hover:bg-emerald-700 text-white disabled:opacity-60"
                title="Allocate rooms by gender"
              >
                <Wand2 size={16} /> {autoAllocating ? "Allocating..." : "By Gender"}
              </Button>
              <Button
                onClick={handleFamilyAutoAllocate}
                disabled={autoAllocating || familyAllocating || rooms.length === 0}
                className="gap-1.5 rounded-none rounded-r-xl bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-60"
                title="Allocate rooms keeping families together"
              >
                <Wand2 size={16} /> {familyAllocating ? "Allocating..." : "By Family"}
              </Button>
            </div>
            <Button
              onClick={handleDownloadRoomPdf}
              disabled={downloadingRoomPdf || rooms.length === 0}
              variant="outline"
              className="gap-1.5 rounded-xl border-emerald-300 text-emerald-700 hover:bg-emerald-50 disabled:opacity-60"
            >
              <FileDown size={16} /> {downloadingRoomPdf ? "Generating..." : "Room List PDF"}
            </Button>
            <Button
              onClick={handleDownloadBulkStickers}
              disabled={downloadingBulkStickers || rooms.length === 0}
              variant="outline"
              className="gap-1.5 rounded-xl border-amber-300 text-amber-700 hover:bg-amber-50 disabled:opacity-60"
            >
              <Sticker size={16} /> {downloadingBulkStickers ? "Generating..." : "Bulk Stickers PDF"}
            </Button>
          </div>

          {/* Unassigned pilgrims banner */}
          {unassignedPilgrims.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle size={16} className="text-amber-600 shrink-0" />
                <p className="text-sm font-semibold text-amber-800">
                  {unassignedPilgrims.length} pilgrim{unassignedPilgrims.length > 1 ? "s" : ""} not assigned to any room
                </p>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {unassignedPilgrims.map(p => (
                  <span key={p.id} className="text-xs bg-amber-100 border border-amber-200 text-amber-900 px-2 py-0.5 rounded-full font-medium">
                    {p.serialNumber}. {p.fullName}
                  </span>
                ))}
              </div>
            </div>
          )}

          {rooms.length === 0 ? (
            <Card className="p-12 text-center border-dashed border-2">
              <Hotel className="w-12 h-12 mx-auto text-muted-foreground/40 mb-4" />
              <h3 className="text-lg font-semibold mb-2">No rooms yet</h3>
              <p className="text-muted-foreground text-sm mb-4">Add rooms then use Auto Allocate to assign pilgrims by family and gender.</p>
              <Button onClick={openCreateRoom} variant="outline" className="rounded-xl"><Plus className="w-4 h-4 mr-2" /> Add First Room</Button>
            </Card>
          ) : (
            <>
              {/* Room cards grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {sortedRooms.map(room => {
                  const roomPilgrims = pilgrimsInRoom(room);
                  const pct = room.totalBeds > 0 ? Math.round((room.occupiedBeds / room.totalBeds) * 100) : 0;
                  const isFull = room.occupiedBeds >= room.totalBeds;
                  const isEmpty = room.occupiedBeds === 0;
                  return (
                    <Card key={room.id} className={`rounded-xl border-2 ${roomCardClass(room)} overflow-hidden`}>
                      <div className="p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xl font-bold">Room {room.roomNumber}</span>
                              {room.floor && <span className="text-xs text-muted-foreground">Floor {room.floor}</span>}
                            </div>
                            <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${HOTEL_COLORS[room.hotel] || "bg-gray-100 text-gray-700"}`}>
                                {HOTEL_LABELS[room.hotel] || room.hotel}
                              </span>
                              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${ROOM_TYPE_COLORS[room.roomType] || "bg-gray-100 text-gray-700"}`}>
                                {ROOM_TYPE_LABELS[room.roomType] || room.roomType}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center gap-0.5 shrink-0">
                            <Button
                              variant="ghost" size="icon" className="h-8 w-8 text-amber-600 hover:text-amber-800 hover:bg-amber-50"
                              title="Download Room Sticker PDF"
                              onClick={() => window.open(`${API}/api/groups/${groupId}/rooms/${room.id}/sticker`, "_blank")}
                            >
                              <Sticker size={14} />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditRoom(room)}>
                              <Edit size={14} />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50" onClick={() => setDeleteConfirmRoomId(room.id)}>
                              <Trash2 size={14} />
                            </Button>
                          </div>
                        </div>

                        {/* Bed occupancy bar */}
                        <div className="mb-3">
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="text-muted-foreground flex items-center gap-1">
                              <BedDouble size={12} /> {room.occupiedBeds}/{room.totalBeds} beds
                            </span>
                            <span className={`font-semibold ${isFull ? "text-red-600" : isEmpty ? "text-emerald-600" : "text-amber-600"}`}>
                              {isFull ? "FULL" : isEmpty ? "EMPTY" : `${room.totalBeds - room.occupiedBeds} free`}
                            </span>
                          </div>
                          <div className="w-full h-2 rounded-full bg-black/10 overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all ${isFull ? "bg-red-500" : isEmpty ? "bg-emerald-400" : "bg-amber-400"}`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </div>

                        {/* Family label for this room */}
                        {(() => {
                          if (roomPilgrims.length === 0) return null;
                          const famIds = [...new Set(roomPilgrims.filter(p => p.familyId).map(p => p.familyId!))];
                          if (famIds.length === 0) return null;
                          if (famIds.length === 1) return (
                            <div className="mb-2">
                              <span className="text-[10px] bg-amber-100 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded-full font-bold">👨‍👩‍👧 Family: {famIds[0]}</span>
                            </div>
                          );
                          return (
                            <div className="mb-2">
                              <span className="text-[10px] bg-gray-100 text-gray-600 border border-gray-200 px-1.5 py-0.5 rounded-full font-semibold">Mixed ({famIds.length} families)</span>
                            </div>
                          );
                        })()}

                        {/* Pilgrim chips */}
                        {roomPilgrims.length === 0 ? (
                          <p className="text-xs text-muted-foreground italic">No pilgrims assigned</p>
                        ) : (
                          <div className="flex flex-wrap gap-1.5">
                            {roomPilgrims.map(p => (
                              <div key={p.id} className="flex items-center gap-1 bg-white/70 border border-black/10 rounded-full pl-0.5 pr-1.5 py-0.5 max-w-[140px]">
                                <div className="w-5 h-5 rounded-full bg-muted overflow-hidden shrink-0">
                                  {p.photoUrl
                                    ? <img src={`${API}${p.photoUrl}`} alt="" className="w-full h-full object-cover" />
                                    : <div className="w-full h-full flex items-center justify-center text-muted-foreground/50 text-[8px]">👤</div>}
                                </div>
                                <span className="text-xs font-medium truncate">{p.fullName.split(" ")[0]}</span>
                                <button
                                  onClick={() => handleRemovePilgrimFromRoom(p.id)}
                                  title="Remove from room"
                                  className="text-muted-foreground/50 hover:text-red-500 transition-colors shrink-0 ml-0.5"
                                >
                                  <X size={10} />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </Card>
                  );
                })}
              </div>

              {/* Room-wise table */}
              <Card className="border-none shadow-sm rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b bg-muted/30 flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-sm">Room-wise Pilgrim List</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">All pilgrims sorted by room number</p>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-muted text-muted-foreground uppercase text-xs font-semibold">
                      <tr>
                        <th className="px-4 py-3">Sr</th>
                        <th className="px-4 py-3">Photo</th>
                        <th className="px-4 py-3">Name</th>
                        <th className="px-4 py-3">Passport No.</th>
                        <th className="px-4 py-3">Relation</th>
                        <th className="px-4 py-3">Room No.</th>
                        <th className="px-4 py-3">Hotel</th>
                        <th className="px-4 py-3">Gender</th>
                        <th className="px-4 py-3">Assign Room</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {pilgrimsForTable.length === 0 ? (
                        <tr><td colSpan={9} className="text-center py-8 text-muted-foreground">No pilgrims yet.</td></tr>
                      ) : pilgrimsForTable.map(p => (
                        <tr key={p.id} className="hover:bg-muted/30">
                          <td className="px-4 py-2.5 font-mono font-bold text-primary text-xs">{p.serialNumber}</td>
                          <td className="px-4 py-2.5">
                            <div className="w-8 h-8 rounded-md bg-muted overflow-hidden">
                              {p.photoUrl
                                ? <img src={`${API}${p.photoUrl}`} alt="" className="w-full h-full object-cover" />
                                : <div className="w-full h-full flex items-center justify-center text-muted-foreground/30"><Users size={12} /></div>}
                            </div>
                          </td>
                          <td className="px-4 py-2.5 font-medium">{[p.salutation, p.fullName].filter(Boolean).join(" ")}</td>
                          <td className="px-4 py-2.5 font-mono text-xs">{p.passportNumber || "—"}</td>
                          <td className="px-4 py-2.5 text-xs">{p.relation || "—"}</td>
                          <td className="px-4 py-2.5">
                            {p.roomNumber
                              ? <span className="font-semibold text-primary">{p.roomNumber}</span>
                              : <span className="text-amber-600 text-xs font-medium">Unassigned</span>}
                          </td>
                          <td className="px-4 py-2.5">
                            {p.roomHotel
                              ? <span className={`px-1.5 py-0.5 rounded text-xs font-semibold ${HOTEL_COLORS[p.roomHotel] || "bg-gray-100"}`}>{HOTEL_LABELS[p.roomHotel] || p.roomHotel}</span>
                              : <span className="text-muted-foreground text-xs">—</span>}
                          </td>
                          <td className="px-4 py-2.5 text-xs">{p.gender || "—"}</td>
                          <td className="px-4 py-2.5">
                            <select
                              value={p.roomId || ""}
                              onChange={e => handleAssignPilgrimToRoom(p.id, e.target.value || null)}
                              className="h-8 px-2 rounded border bg-background text-xs min-w-[160px]"
                            >
                              <option value="">— Unassigned —</option>
                              {sortedRooms.map(r => (
                                <option key={r.id} value={r.id}>
                                  Rm {r.roomNumber} · {HOTEL_LABELS[r.hotel] || r.hotel} ({ROOM_TYPE_LABELS[r.roomType] || r.roomType})
                                </option>
                              ))}
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Card>
            </>
          )}
        </div>
      )}

      {/* ============ FAMILIES TAB ============ */}
      {activeTab === "families" && (
        <div className="space-y-6">
          {/* Action bar */}
          <div className="flex flex-wrap gap-2 items-center">
            <Button onClick={handleAutoDetect} disabled={autoDetecting || pilgrims.length === 0}
              className="gap-1.5 rounded-xl bg-[#0d5040] hover:bg-[#0d5040]/90 text-white disabled:opacity-60">
              <Zap size={15} /> {autoDetecting ? "Detecting..." : "Auto-detect Families"}
            </Button>
            <Button onClick={handleResequenceIds} disabled={resequencing || families.length === 0} variant="outline"
              className="gap-1.5 rounded-xl border-[#0d5040] text-[#0d5040] hover:bg-[#0d5040]/10 disabled:opacity-60">
              <RefreshCw size={14} /> {resequencing ? "Re-sequencing..." : "Re-sequence IDs"}
            </Button>
            <Button onClick={handleFamilyAutoAllocate} disabled={familyAllocating || families.length === 0 || rooms.length === 0}
              className="gap-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white disabled:opacity-60">
              <Wand2 size={15} /> {familyAllocating ? "Allocating..." : "Family Auto Allocate"}
            </Button>
            <Button onClick={() => {
              const k = `roomAlloc:${groupId}`;
              setRoomNumAllocStart(localStorage.getItem(`${k}:start`) || "1501");
              setRoomNumAllocPrefix(localStorage.getItem(`${k}:prefix`) || "");
              setRoomNumAllocHotel(localStorage.getItem(`${k}:hotel`) || "makkah");
              setRoomNumAllocOpen(true);
            }} disabled={families.length === 0} variant="outline"
              className="gap-1.5 rounded-xl border-blue-300 text-blue-700 hover:bg-blue-50 disabled:opacity-60">
              <BedDouble size={14} /> Assign Room Numbers
            </Button>
            <div className="relative">
              <Button variant="outline" disabled={families.length === 0}
                className="gap-1.5 rounded-xl border-emerald-300 text-emerald-700 hover:bg-emerald-50 disabled:opacity-60"
                onClick={() => setReportsOpen(o => !o)}>
                <FileDown size={14} /> Reports <ChevronDown size={12} />
              </Button>
              {reportsOpen && (
                <div className="absolute left-0 top-full mt-1 bg-white border rounded-xl shadow-lg py-1 z-50 min-w-[190px]"
                  onMouseLeave={() => setReportsOpen(false)}>
                  {([
                    { key: "pdf", label: "Family List PDF" },
                    { key: "flight-list", label: "Flight List PDF" },
                    { key: "bus-list", label: "Bus List PDF" },
                    { key: "hotel-list", label: "Hotel List PDF" },
                    { key: "badges", label: "Family Badges PDF" },
                  ] as const).map(item => (
                    <button key={item.key}
                      onClick={() => { downloadFamilyReport(item.key, item.label); setReportsOpen(false); }}
                      className="flex items-center gap-2 w-full px-4 py-2 text-sm hover:bg-muted text-left">
                      <FileDown size={13} className={item.key === "badges" ? "text-amber-600" : "text-emerald-600"} />
                      {item.label}
                    </button>
                  ))}
                  <button
                    onClick={() => { fetchRoomSummary(); setReportsOpen(false); }}
                    disabled={roomSummaryLoading}
                    className="flex items-center gap-2 w-full px-4 py-2 text-sm hover:bg-muted text-left border-t mt-1 pt-2">
                    <BedDouble size={13} className="text-blue-600" />
                    {roomSummaryLoading ? "Loading…" : "Room Summary"}
                  </button>
                </div>
              )}
            </div>
            <Button onClick={exportFamiliesExcel} disabled={families.length === 0} variant="outline"
              className="gap-1.5 rounded-xl border-teal-300 text-teal-700 hover:bg-teal-50 disabled:opacity-60">
              <FileDown size={14} /> Export Excel
            </Button>
            <Button onClick={handleWhatsAppShare} disabled={families.length === 0} variant="outline"
              className="gap-1.5 rounded-xl border-green-400 text-green-700 hover:bg-green-50 disabled:opacity-60">
              <Share2 size={14} /> Share PDF
            </Button>
            <Button onClick={fetchFamilies} variant="outline" className="gap-1.5 rounded-xl">Refresh</Button>
          </div>

          {/* Search + view toggle */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px] max-w-sm">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
              <input value={familySearch} onChange={e => setFamilySearch(e.target.value)}
                placeholder="Search family ID, name, passport, room…"
                className="w-full pl-8 pr-3 h-9 text-sm rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30" />
            </div>
            <div className="flex border rounded-lg overflow-hidden shrink-0">
              {([
                { v: "card" as const, Icon: LayoutGrid, label: "Card" },
                { v: "table" as const, Icon: List, label: "Table" },
                { v: "tree" as const, Icon: GitBranch, label: "Tree" },
              ]).map(({ v, Icon, label }) => (
                <button key={v} title={`${label} view`} onClick={() => setFamilyView(v)}
                  className={`flex items-center gap-1 px-3 py-1.5 text-xs font-semibold transition-colors ${familyView === v ? "bg-primary text-white" : "text-muted-foreground hover:bg-muted"}`}>
                  <Icon size={13} /> {label}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 text-sm">
              {filteredFamilies.length !== families.length && (
                <span className="text-xs text-muted-foreground">{filteredFamilies.length} of</span>
              )}
              <span className="bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-semibold text-xs">{families.length} families</span>
              <span className="bg-gray-100 text-gray-700 px-2 py-0.5 rounded-full font-semibold text-xs">
                {pilgrims.filter(p => !p.familyId).length} ungrouped
              </span>
            </div>
          </div>

          {/* Statistics bar */}
          {families.length > 0 && (
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
              {[
                { label: "Total Families", value: familyStats.totalFamilies, color: "text-amber-700 bg-amber-50 border-amber-200" },
                { label: "Total Pilgrims", value: familyStats.totalInFamilies, color: "text-emerald-700 bg-emerald-50 border-emerald-200" },
                { label: "Avg Size", value: familyStats.avgSize, color: "text-blue-700 bg-blue-50 border-blue-200" },
                { label: "Largest", value: familyStats.largestFamily, color: "text-purple-700 bg-purple-50 border-purple-200" },
                { label: "No Room", value: familyStats.withoutRoom, color: familyStats.withoutRoom > 0 ? "text-orange-700 bg-orange-50 border-orange-200" : "text-gray-400 bg-gray-50 border-gray-100" },
                { label: "No Bus", value: familyStats.withoutBus, color: familyStats.withoutBus > 0 ? "text-red-700 bg-red-50 border-red-200" : "text-gray-400 bg-gray-50 border-gray-100" },
              ].map(stat => (
                <div key={stat.label} className={`flex flex-col items-center py-2 px-2 rounded-xl border text-center ${stat.color}`}>
                  <span className="text-xl font-black leading-tight">{stat.value}</span>
                  <span className="text-[9px] font-medium leading-tight mt-0.5 opacity-80">{stat.label}</span>
                </div>
              ))}
            </div>
          )}

          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 text-sm text-blue-800">
            <strong>Tip:</strong> Use <strong>Auto-detect</strong> to automatically group pilgrims by shared mobile number or surname+city. Or click "<span className="font-mono font-bold">+Fam</span>" in the Pilgrims tab to assign manually. Click ⭐ to mark the family head.
          </div>

          {/* Ungrouped pilgrims */}
          {pilgrims.filter(p => !p.familyId).length > 0 && (
            <Card className="rounded-xl border-dashed border-2 border-gray-300">
              <div className="px-5 py-3 border-b bg-muted/20 flex items-center gap-2">
                <Users size={15} className="text-muted-foreground" />
                <span className="font-semibold text-sm text-muted-foreground">Ungrouped Pilgrims ({pilgrims.filter(p => !p.familyId).length})</span>
              </div>
              <div className="p-4 flex flex-wrap gap-1.5">
                {pilgrims.filter(p => !p.familyId).sort((a, b) => a.serialNumber - b.serialNumber).map(p => (
                  <span key={p.id} className="text-xs bg-gray-100 border border-gray-200 text-gray-700 px-2 py-1 rounded-full">
                    {p.serialNumber}. {p.fullName.split(" ")[0]}
                  </span>
                ))}
              </div>
            </Card>
          )}

          {/* Family content - view-based */}
          {families.length === 0 ? (
            <Card className="p-12 text-center border-dashed border-2">
              <UserCheck className="w-12 h-12 mx-auto text-muted-foreground/40 mb-4" />
              <h3 className="text-lg font-semibold mb-2">No families yet</h3>
              <p className="text-muted-foreground text-sm">Click <strong>Auto-detect Families</strong> above, or go to the Pilgrims tab and click "+Fam" to assign families manually.</p>
            </Card>
          ) : filteredFamilies.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground">
              <Search className="w-8 h-8 mx-auto mb-2 opacity-30" />
              <p className="text-sm">No families match "<strong>{familySearch}</strong>"</p>
              <button onClick={() => setFamilySearch("")} className="text-xs text-primary underline mt-1">Clear search</button>
            </div>
          ) : familyView === "table" ? (
            <div className="space-y-3">
              <Card className="border-none shadow-sm rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="bg-muted text-muted-foreground uppercase text-xs font-semibold">
                      <tr>
                        <th className="px-4 py-3">Family ID</th>
                        <th className="px-4 py-3">Head</th>
                        <th className="px-4 py-3">Members</th>
                        <th className="px-4 py-3">Room</th>
                        <th className="px-4 py-3">Hotel</th>
                        <th className="px-4 py-3">Flight</th>
                        <th className="px-4 py-3">Bus</th>
                        <th className="px-4 py-3">Mobile</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {filteredFamilies.map(fam => {
                        const headName = fam.head ? [fam.head.salutation, fam.head.fullName].filter(Boolean).join(" ") : fam.familyId;
                        const roomInfo = fam.roomId ? rooms.find(r => r.id === fam.roomId) : null;
                        const memberRoomIds = [...new Set(fam.members.filter(m => m.roomId).map(m => m.roomId!))];
                        const busNos = [...new Set(fam.members.filter(m => m.busNumber).map(m => m.busNumber!))];
                        return (
                          <tr key={fam.familyId} className="hover:bg-muted/30">
                            <td className="px-4 py-2.5">
                              <span className="bg-amber-500 text-white font-black text-xs px-2 py-1 rounded-lg">{fam.familyId}</span>
                            </td>
                            <td className="px-4 py-2.5 font-medium text-sm">{headName}</td>
                            <td className="px-4 py-2.5 text-xs text-muted-foreground">{fam.members.length} member{fam.members.length !== 1 ? "s" : ""}</td>
                            <td className="px-4 py-2.5 text-xs font-semibold text-primary">
                              {roomInfo ? `Rm ${roomInfo.roomNumber}` : memberRoomIds.length > 0 ? `${memberRoomIds.length} rooms` : "—"}
                            </td>
                            <td className="px-4 py-2.5">
                              {fam.head?.roomHotel ? (
                                <span className={`text-xs px-1.5 py-0.5 rounded font-semibold ${HOTEL_COLORS[fam.head.roomHotel] || "bg-gray-100"}`}>
                                  {HOTEL_LABELS[fam.head.roomHotel] || fam.head.roomHotel}
                                </span>
                              ) : <span className="text-muted-foreground">—</span>}
                            </td>
                            <td className="px-4 py-2.5 text-xs">{group?.flightNumber || "—"}</td>
                            <td className="px-4 py-2.5 text-xs">{busNos.join(", ") || "—"}</td>
                            <td className="px-4 py-2.5 text-xs">{fam.head?.mobileIndia || "—"}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
              {/* Ungrouped quick-assign section */}
              {pilgrims.filter(p => !p.familyId).length > 0 && (
                <Card className="rounded-xl border-dashed border-2 border-orange-200 bg-orange-50/30">
                  <div className="px-4 py-2 border-b bg-orange-100/40 flex items-center gap-2">
                    <AlertTriangle size={13} className="text-orange-600" />
                    <span className="text-xs font-semibold text-orange-800">Ungrouped Pilgrims — Quick Assign</span>
                  </div>
                  <div className="divide-y">
                    {pilgrims.filter(p => !p.familyId).sort((a, b) => a.serialNumber - b.serialNumber).map(p => (
                      <div key={p.id} className="flex items-center gap-3 px-4 py-2">
                        <span className="text-xs font-medium text-gray-700 flex-1 min-w-0 truncate">
                          {p.serialNumber}. {p.fullName}
                        </span>
                        <span className="text-[10px] text-muted-foreground shrink-0">{p.gender || ""}</span>
                        <select
                          defaultValue=""
                          onChange={async e => {
                            if (!e.target.value) return;
                            try {
                              await fetch(`${API}/api/groups/${groupId}/pilgrims/${p.id}`, {
                                method: "POST", credentials: "include",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ familyId: e.target.value }),
                              });
                              toast({ title: `${p.fullName.split(" ")[0]} assigned to ${e.target.value}` });
                              await fetchData(); await fetchFamilies();
                            } catch { toast({ title: "Assignment failed", variant: "destructive" }); }
                          }}
                          className="h-7 text-xs rounded border bg-background px-1 shrink-0 max-w-[140px]"
                        >
                          <option value="">Assign to family…</option>
                          {families.map(f => (
                            <option key={f.familyId} value={f.familyId}>
                              {f.familyId} — {f.head?.fullName?.split(" ")[0] || "?"}
                            </option>
                          ))}
                        </select>
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
          ) : familyView === "tree" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredFamilies.map(fam => {
                const headMember = fam.members.find(m => m.familyHead) || fam.members[0];
                return (
                  <Card key={fam.familyId} className="rounded-xl border-2 border-[#0d5040]/20 overflow-hidden">
                    <div className="bg-[#0d5040] px-4 py-2 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-black text-sm">{fam.familyId}</span>
                        <span className="text-[#C9A84C] text-xs font-semibold">{fam.members.length} member{fam.members.length !== 1 ? "s" : ""}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {fam.head?.mobileIndia && (
                          <span className="text-white/70 text-[10px]">📞 {fam.head.mobileIndia}</span>
                        )}
                        {fam.head?.mobileIndia && (
                          <button
                            onClick={() => openFamilyWA(fam)}
                            className="text-green-300 hover:text-green-100 transition-colors"
                            title="Send WhatsApp"
                          >
                            <MessageCircle size={13} />
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="p-3 space-y-1">
                      {fam.members.map(m => {
                        const isHead = m.familyHead || m.id === headMember?.id;
                        return (
                          <div key={m.id}
                            className={`flex items-center gap-2 py-1.5 px-2 rounded-lg text-xs ${isHead ? "bg-amber-50 border border-amber-200" : "bg-white/50"}`}
                            style={{ marginLeft: isHead ? 0 : 12 }}>
                            <div className="w-6 h-6 rounded-full bg-muted overflow-hidden shrink-0">
                              {m.photoUrl
                                ? <img src={`${API}${m.photoUrl}`} alt="" className="w-full h-full object-cover" />
                                : <div className="w-full h-full flex items-center justify-center text-[10px]">{m.gender?.toLowerCase() === "female" ? "👩" : "👨"}</div>}
                            </div>
                            {isHead && <Star size={10} className="text-amber-500 shrink-0" fill="currentColor" />}
                            <span className={`font-medium truncate ${isHead ? "text-amber-900" : "text-gray-700"}`}>{m.fullName}</span>
                            {m.familyRelation && (
                              <span className="bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded-full text-[9px] font-semibold shrink-0">{m.familyRelation}</span>
                            )}
                            {m.roomNumber && (
                              <span className="ml-auto bg-primary/10 text-primary font-semibold px-1.5 py-0.5 rounded text-[9px] shrink-0">Rm {m.roomNumber}</span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                    {(fam.head?.roomNumber || fam.head?.busNumber) && (
                      <div className="px-3 pb-2 flex gap-2">
                        {fam.head.roomNumber && <span className="text-[10px] bg-primary/10 text-primary font-semibold px-2 py-0.5 rounded">🏨 Rm {fam.head.roomNumber}</span>}
                        {fam.head.busNumber && <span className="text-[10px] bg-blue-100 text-blue-700 font-semibold px-2 py-0.5 rounded">🚌 Bus {fam.head.busNumber}</span>}
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredFamilies.map(fam => {
                const isExpanded = expandedFamilies.has(fam.familyId);
                const headName = fam.head ? [fam.head.salutation, fam.head.fullName].filter(Boolean).join(" ") : fam.familyId;
                const roomInfo = fam.roomId ? rooms.find(r => r.id === fam.roomId) : null;
                const memberRoomIds = [...new Set(fam.members.map(m => m.roomId || ""))].filter(Boolean);
                const allSameRoom = memberRoomIds.length === 1 && !!fam.roomId;
                const hasRoom = memberRoomIds.length > 0;
                const familyQrUrl = `${window.location.origin}${import.meta.env.BASE_URL.replace(/\/$/, "")}/verify/family/${groupId}/${encodeURIComponent(fam.familyId)}`;

                return (
                  <Card key={fam.familyId} className="rounded-xl border-2 border-amber-200 bg-amber-50/30 overflow-hidden">
                    <div className="p-4">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="bg-amber-500 text-white rounded-xl px-3 py-1.5 text-center min-w-[52px]">
                            <div className="text-[9px] font-bold uppercase tracking-wide opacity-80">Family</div>
                            <div className="text-base font-black leading-tight">{fam.familyId}</div>
                          </div>
                          <div>
                            <div className="font-bold text-sm flex items-center gap-1">
                              {headName}
                              {fam.head?.familyHead && <Star size={11} className="text-amber-500" fill="currentColor" />}
                            </div>
                            <div className="text-xs text-muted-foreground mt-0.5">{fam.members.length} member{fam.members.length !== 1 ? "s" : ""}</div>
                            {fam.head?.mobileIndia && (
                              <div className="text-[10px] text-muted-foreground">📞 {fam.head.mobileIndia}</div>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7 text-violet-600 hover:bg-violet-50"
                            title={`Merge ${fam.familyId} into another family`}
                            onClick={() => { setMergeSourceFam(fam); setMergeTargetId(""); }}
                          >
                            <GitMerge size={13} />
                          </Button>
                          {fam.members.length >= 2 && (
                            <Button
                              variant="ghost" size="icon" className="h-7 w-7 text-orange-600 hover:bg-orange-50"
                              title={`Split members out of ${fam.familyId}`}
                              onClick={() => openSplitModal(fam)}
                            >
                              <Scissors size={13} />
                            </Button>
                          )}
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7 text-amber-600 hover:bg-amber-50"
                            title={`Print Badges — ${fam.familyId}`}
                            onClick={() => downloadFamilyBadges(fam.familyId)}
                          >
                            <Printer size={13} />
                          </Button>
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7 text-[#0d5040] hover:bg-[#0d5040]/10"
                            title={`Print Family Sheet — ${fam.familyId}`}
                            onClick={() => window.open(`/admin/groups/${groupId}/families/${encodeURIComponent(fam.familyId)}/print`, "_blank")}
                          >
                            <FileDown size={13} />
                          </Button>
                          {fam.head?.mobileIndia && (
                            <Button
                              variant="ghost" size="icon" className="h-7 w-7 text-green-600 hover:bg-green-50"
                              title={`WhatsApp ${fam.head.fullName}`}
                              onClick={() => openFamilyWA(fam)}
                            >
                              <MessageCircle size={13} />
                            </Button>
                          )}
                          <Button
                            variant="ghost" size="icon" className="h-7 w-7"
                            title="View Family QR Page"
                            onClick={() => window.open(familyQrUrl, "_blank")}
                          >
                            <QrCode size={13} />
                          </Button>
                          <button
                            onClick={() => setExpandedFamilies(prev => {
                              const next = new Set(prev);
                              isExpanded ? next.delete(fam.familyId) : next.add(fam.familyId);
                              return next;
                            })}
                            className="text-xs text-muted-foreground px-2 py-1 rounded hover:bg-muted"
                          >
                            {isExpanded ? "▲ Hide" : "▼ Show"}
                          </button>
                        </div>
                      </div>

                      {/* Room + Bus status (collapsed summary) */}
                      <div className="mb-3 flex flex-wrap items-center gap-1.5">
                        {allSameRoom && roomInfo ? (
                          <>
                            <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${HOTEL_COLORS[roomInfo.hotel] || "bg-gray-100"}`}>
                              {HOTEL_LABELS[roomInfo.hotel] || roomInfo.hotel}
                            </span>
                            <span className="text-xs font-bold text-primary">Room {roomInfo.roomNumber}</span>
                            <span className={`text-xs px-1.5 py-0.5 rounded-full ${ROOM_TYPE_COLORS[roomInfo.roomType] || "bg-gray-100"}`}>
                              {ROOM_TYPE_LABELS[roomInfo.roomType] || roomInfo.roomType}
                            </span>
                          </>
                        ) : hasRoom ? (
                          <span className="text-xs text-amber-700 font-medium bg-amber-100 px-2 py-0.5 rounded-full">Mixed rooms ({memberRoomIds.length})</span>
                        ) : (
                          <span className="text-xs text-muted-foreground italic">No room</span>
                        )}
                        {fam.busNumber ? (
                          <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-blue-100 text-blue-800">🚌 Bus {fam.busNumber}</span>
                        ) : (
                          <span className="text-xs text-muted-foreground italic">· No bus</span>
                        )}
                        {group?.flightNumber && (
                          <span className="text-xs px-2 py-0.5 rounded-full bg-teal-50 text-teal-700 font-semibold">✈️ {group.flightNumber}</span>
                        )}
                        <span className="text-xs text-muted-foreground">· {group?.groupName} {group?.year}</span>
                      </div>

                      {/* Member list (expandable) */}
                      {isExpanded && (
                        <div className="mb-3 bg-white rounded-lg border overflow-hidden">
                          {fam.members.map(m => (
                            <div key={m.id} className={`flex items-start gap-2 text-xs py-2 px-3 border-b last:border-0 ${m.familyHead ? "bg-amber-50" : ""}`}>
                              <div className="w-8 h-8 rounded-full bg-muted overflow-hidden shrink-0 mt-0.5">
                                {m.photoUrl
                                  ? <img src={`${API}${m.photoUrl}`} alt="" className="w-full h-full object-cover" />
                                  : <div className="w-full h-full flex items-center justify-center text-[11px]">{m.gender?.toLowerCase() === "female" ? "👩" : "👨"}</div>}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-1 flex-wrap">
                                  <span className="font-semibold text-gray-800">{m.fullName}</span>
                                  {m.familyHead && <span className="text-[9px] bg-amber-400 text-white rounded px-1.5 py-0.5 font-bold">HEAD</span>}
                                  {(m.familyRelation || m.relation) && (
                                    <span className="text-[10px] text-muted-foreground">· {m.familyRelation || m.relation}</span>
                                  )}
                                </div>
                                <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-0.5">
                                  {m.passportNumber && <span className="font-mono text-[10px] text-gray-500">{m.passportNumber}</span>}
                                  {m.mobileIndia && <span className="text-[10px] text-gray-500">📞 {m.mobileIndia}</span>}
                                  {m.roomNumber && <span className="text-[10px] font-semibold text-primary">🏨 Rm {m.roomNumber}</span>}
                                  {m.busNumber && <span className="text-[10px] font-semibold text-blue-600">🚌 Bus {m.busNumber}</span>}
                                  {(() => {
                                    const att = fam.memberAttendance?.[m.id];
                                    if (!att || att.total === 0) return null;
                                    const pct = Math.round((att.attended / att.total) * 100);
                                    return (
                                      <span className={`text-[10px] font-semibold px-1 py-0.5 rounded ${att.attended === att.total ? "text-emerald-700 bg-emerald-50" : att.attended === 0 ? "text-red-600 bg-red-50" : "text-amber-700 bg-amber-50"}`}>
                                        ✓ {att.attended}/{att.total} ({pct}%)
                                      </span>
                                    );
                                  })()}
                                </div>
                              </div>
                              {!m.familyHead && (
                                <button
                                  title="Set as family head"
                                  onClick={async () => {
                                    try {
                                      await fetch(`${API}/api/groups/${groupId}/pilgrims/${m.id}`, {
                                        method: "PUT", credentials: "include",
                                        headers: { "Content-Type": "application/json" },
                                        body: JSON.stringify({ ...m, familyHead: true, serialNumber: m.serialNumber }),
                                      });
                                      toast({ title: `${m.fullName.split(" ")[0]} set as family head` });
                                      await fetchData();
                                      await fetchFamilies();
                                    } catch { toast({ title: "Failed to update", variant: "destructive" }); }
                                  }}
                                  className="shrink-0 mt-1 text-muted-foreground/30 hover:text-amber-500 transition-colors"
                                >
                                  <Star size={11} />
                                </button>
                              )}
                            </div>
                          ))}
                        </div>
                      )}

                      {/* QR code */}
                      {isExpanded && (
                        <div className="mb-3 flex items-start gap-3 bg-white border rounded-lg p-3">
                          <div className="bg-white p-1 border rounded shrink-0">
                            <QrImg value={familyQrUrl} size={72} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold text-gray-700 mb-0.5">Family Verify QR</p>
                            <p className="text-[10px] text-muted-foreground break-all mb-1">{familyQrUrl}</p>
                            <div className="flex flex-wrap gap-2">
                              <button
                                onClick={() => window.open(familyQrUrl, "_blank")}
                                className="text-[10px] text-primary underline"
                              >Open ↗</button>
                              <button
                                onClick={() => {
                                  const img = new Image();
                                  img.crossOrigin = "anonymous";
                                  img.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(familyQrUrl)}&color=0d5040&bgcolor=ffffff`;
                                  img.onload = () => {
                                    const canvas = document.createElement("canvas");
                                    canvas.width = 200; canvas.height = 200;
                                    canvas.getContext("2d")?.drawImage(img, 0, 0);
                                    const a = document.createElement("a");
                                    a.href = canvas.toDataURL("image/png");
                                    a.download = `family-qr-${fam.familyId}.png`; a.click();
                                  };
                                }}
                                className="text-[10px] text-emerald-700 underline"
                              >Download QR ↓</button>
                              <button
                                onClick={() => window.open(`/admin/groups/${groupId}/families/${encodeURIComponent(fam.familyId)}/print`, "_blank")}
                                className="text-[10px] text-[#0d5040] underline"
                              >Print Sheet ↗</button>
                            </div>
                            <div className="flex flex-wrap gap-2 mt-2 pt-2 border-t border-gray-100">
                              <button
                                onClick={() => {
                                  const msg = `🕌 *Al Burhan Tours & Travels 2026*\nFamily: *${fam.familyId}* | ${headName} (${fam.members.length} member${fam.members.length !== 1 ? "s" : ""})\n\nVerify your family pilgrims here:\n${familyQrUrl}`;
                                  window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, "_blank");
                                }}
                                className="flex items-center gap-1 text-[10px] font-medium text-white bg-[#25D366] hover:bg-[#1ebe5d] px-2 py-1 rounded-full transition-colors"
                              >
                                <svg viewBox="0 0 24 24" className="w-3 h-3 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.123.556 4.116 1.528 5.845L0 24l6.335-1.508A11.93 11.93 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.797 9.797 0 0 1-5.003-1.368l-.36-.214-3.76.896.952-3.653-.234-.373A9.796 9.796 0 0 1 2.182 12C2.182 6.57 6.57 2.182 12 2.182S21.818 6.57 21.818 12 17.43 21.818 12 21.818z"/></svg>
                                WhatsApp
                              </button>
                              <button
                                onClick={async () => {
                                  if (navigator.share) {
                                    try {
                                      await navigator.share({
                                        title: `Family ${fam.familyId} — Al Burhan Tours 2026`,
                                        text: `Verify family pilgrims: ${headName} (${fam.members.length} members)`,
                                        url: familyQrUrl,
                                      });
                                    } catch { /* dismissed */ }
                                  } else {
                                    await navigator.clipboard.writeText(familyQrUrl);
                                    toast({ title: "Link copied!", description: "Family verify link copied to clipboard" });
                                  }
                                }}
                                className="flex items-center gap-1 text-[10px] font-medium text-white bg-blue-500 hover:bg-blue-600 px-2 py-1 rounded-full transition-colors"
                              >
                                <svg viewBox="0 0 24 24" className="w-3 h-3 fill-none stroke-current stroke-2"><path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 1 1 0-2.684m0 2.684 6.632 3.316m-6.632-6 6.632-3.316m0 0a3 3 0 1 0 5.367-2.684 3 3 0 0 0-5.367 2.684zm0 9.316a3 3 0 1 0 5.368 2.684 3 3 0 0 0-5.368-2.684z"/></svg>
                                Share
                              </button>
                              <button
                                onClick={async () => {
                                  await navigator.clipboard.writeText(familyQrUrl);
                                  toast({ title: "Copied!", description: "Family verify link copied to clipboard" });
                                }}
                                className="flex items-center gap-1 text-[10px] font-medium text-gray-600 bg-gray-100 hover:bg-gray-200 px-2 py-1 rounded-full transition-colors"
                              >
                                <svg viewBox="0 0 24 24" className="w-3 h-3 fill-none stroke-current stroke-2"><path strokeLinecap="round" strokeLinejoin="round" d="M8 5H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-1M8 5a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2M8 5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2m0 0h2a2 2 0 0 1 2 2v3m2 4H10m0 0 3-3m-3 3 3 3"/></svg>
                                Copy Link
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Assign Room dropdown */}
                      <div className="flex items-center gap-2">
                        <label className="text-xs text-muted-foreground shrink-0">Assign all to:</label>
                        <select
                          value={fam.roomId || ""}
                          onChange={e => handleAssignFamilyToRoom(fam.familyId, e.target.value || null)}
                          className="flex-1 h-8 px-2 rounded border bg-background text-xs"
                        >
                          <option value="">— Unassigned —</option>
                          {sortedRooms.map(r => (
                            <option key={r.id} value={r.id}>
                              Rm {r.roomNumber} · {HOTEL_LABELS[r.hotel] || r.hotel} ({ROOM_TYPE_LABELS[r.roomType] || r.roomType}) [{r.totalBeds - r.occupiedBeds} free]
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ===== Auto-Allocate Room Numbers Dialog ===== */}
      <Dialog open={roomNumAllocOpen} onOpenChange={setRoomNumAllocOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <BedDouble size={16} className="text-blue-600" />
              Assign Room Numbers by Family Size
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-1">
            <div className="bg-blue-50 border border-blue-200 rounded-lg px-3 py-2 text-xs text-blue-800 space-y-0.5">
              <p className="font-semibold">Rules applied:</p>
              <p>2 members → Double · 3 → Triple · 4 → Quad · 5 → Quint · 6+ → Multi (adjacent blocks of 5)</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-gray-700">Starting Room No.</label>
                <Input
                  type="number"
                  value={roomNumAllocStart}
                  onChange={e => setRoomNumAllocStart(e.target.value)}
                  placeholder="e.g. 1501"
                  className="h-9 text-sm"
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-semibold text-gray-700">Prefix <span className="text-muted-foreground font-normal">(optional)</span></label>
                <Input
                  value={roomNumAllocPrefix}
                  onChange={e => setRoomNumAllocPrefix(e.target.value)}
                  placeholder="e.g. Makkah-A"
                  className="h-9 text-sm"
                />
              </div>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-gray-700">Hotel</label>
              <select
                value={roomNumAllocHotel}
                onChange={e => setRoomNumAllocHotel(e.target.value)}
                className="w-full h-9 px-3 text-sm rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
              >
                <option value="makkah">Makkah</option>
                <option value="madinah">Madinah</option>
                <option value="aziziah">Aziziah</option>
              </select>
            </div>
            {roomNumAllocPrefix && roomNumAllocStart && (
              <p className="text-xs text-muted-foreground">First room will be: <strong>{roomNumAllocPrefix}-{roomNumAllocStart}</strong></p>
            )}
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="roomAllocForce"
                checked={roomNumAllocForce}
                onChange={e => setRoomNumAllocForce(e.target.checked)}
                className="rounded"
              />
              <label htmlFor="roomAllocForce" className="text-xs text-gray-700 cursor-pointer">
                Override existing room assignments
              </label>
            </div>
            {(() => {
              const toProcess = roomNumAllocForce
                ? families
                : families.filter(f => !f.members.every((m: any) => m.roomNumber));
              const roomsNeeded = toProcess.reduce((total, f) => {
                const sz = f.members.length;
                return total + (sz <= 5 ? 1 : Math.ceil(sz / 5));
              }, 0);
              const startNum = parseInt(roomNumAllocStart, 10) || 0;
              const endNum = startNum ? startNum + roomsNeeded - 1 : 0;
              return (
                <div className="bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-xs text-amber-800">
                  <strong>Preview:</strong> {toProcess.length} families → <strong>{roomsNeeded} rooms needed</strong>
                  {startNum > 0 && <span> · rooms {startNum}–{endNum}</span>}
                  {!roomNumAllocForce && families.length > toProcess.length && (
                    <span> · {families.length - toProcess.length} already-assigned families skipped</span>
                  )}
                </div>
              );
            })()}
            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={() => setRoomNumAllocOpen(false)}>Cancel</Button>
              <Button
                size="sm"
                className="bg-blue-600 hover:bg-blue-700 text-white gap-1.5"
                onClick={handleAutoAllocateRooms}
                disabled={!roomNumAllocStart || roomNumAllocating}
              >
                <BedDouble size={13} />
                {roomNumAllocating ? "Allocating…" : "Allocate"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Room Summary Modal ===== */}
      <Dialog open={roomSummaryOpen} onOpenChange={setRoomSummaryOpen}>
        <DialogContent className="max-w-2xl max-h-[85vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between gap-2 text-base">
              <span className="flex items-center gap-2">
                <BedDouble size={16} className="text-blue-600" />
                Room Summary — {group?.groupName || "Group"}
              </span>
              <div className="flex gap-1.5">
                <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={exportRoomSummaryExcel}>
                  <FileDown size={12} /> Excel
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-1.5 text-xs text-red-700 border-red-200 hover:bg-red-50"
                  onClick={() => {
                    const url = `${API}/api/groups/${groupId}/families/room-summary/pdf`;
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = "";
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                  }}
                >
                  <FileDown size={12} /> PDF
                </Button>
              </div>
            </DialogTitle>
          </DialogHeader>
          <div className="overflow-auto flex-1 mt-2">
            {roomSummaryData.length === 0 ? (
              <p className="text-center text-muted-foreground text-sm py-8">No room assignments found. Use "Assign Room Numbers" to allocate rooms.</p>
            ) : (
              <>
              {swapSelectA && (
                <div className="mb-2 px-3 py-1.5 bg-amber-50 border border-amber-300 rounded-lg text-xs text-amber-800 flex items-center justify-between">
                  <span><ArrowLeftRight size={11} className="inline mr-1" />Swap mode: now click another family's <ArrowLeftRight size={11} className="inline mx-0.5" /> to complete the swap</span>
                  <button className="text-amber-600 hover:text-amber-900 font-semibold" onClick={() => setSwapSelectA(null)}>Cancel</button>
                </div>
              )}
              <table className="w-full text-sm text-left border-collapse">
                <thead className="bg-[#0d5040] text-white text-xs uppercase sticky top-0">
                  <tr>
                    <th className="px-3 py-2.5 rounded-tl-lg">Room No.</th>
                    <th className="px-3 py-2.5">Family Head</th>
                    <th className="px-3 py-2.5 text-center">Members</th>
                    <th className="px-3 py-2.5">Room Type</th>
                    <th className="px-3 py-2.5 rounded-tr-lg text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {roomSummaryData.map((row: any) =>
                    row.families.map((fam: any, fi: number) => {
                      const isSwapSelected = swapSelectA === fam.familyId;
                      const isEditing = editingRoom?.familyId === fam.familyId;
                      return (
                        <tr key={`${row.roomNumber}-${fam.familyId}`}
                          className={`hover:bg-muted/30 transition-colors ${isSwapSelected ? "bg-amber-50 ring-1 ring-inset ring-amber-300" : ""}`}>
                          {fi === 0 ? (
                            <td rowSpan={row.families.length} className="px-3 py-2 border-r align-top pt-3">
                              {isEditing ? (
                                <div className="flex flex-col gap-1">
                                  <input
                                    autoFocus
                                    className="w-20 border rounded px-1.5 py-0.5 text-xs font-mono"
                                    value={editingRoom!.value}
                                    onChange={e => setEditingRoom({ familyId: fam.familyId, value: e.target.value })}
                                    onKeyDown={e => {
                                      if (e.key === "Enter") handleChangeRoomNumber(fam.familyId, editingRoom!.value);
                                      if (e.key === "Escape") setEditingRoom(null);
                                    }}
                                  />
                                  <div className="flex gap-1">
                                    <button onClick={() => handleChangeRoomNumber(fam.familyId, editingRoom!.value)}
                                      className="text-green-600 hover:text-green-800"><Check size={12} /></button>
                                    <button onClick={() => setEditingRoom(null)}
                                      className="text-red-400 hover:text-red-700"><X size={12} /></button>
                                  </div>
                                </div>
                              ) : (
                                <span className="font-black text-primary">{row.roomNumber}</span>
                              )}
                            </td>
                          ) : null}
                          <td className="px-3 py-2">
                            <div className="font-medium">{fam.headName}</div>
                            <div className="text-[10px] text-muted-foreground">{fam.familyId}</div>
                          </td>
                          <td className="px-3 py-2 text-center">
                            <span className="bg-amber-100 text-amber-800 font-semibold px-2 py-0.5 rounded-full text-xs">{fam.memberCount}</span>
                          </td>
                          {fi === 0 ? (
                            <td rowSpan={row.families.length} className="px-3 py-2 border-l align-top pt-3">
                              <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                                row.roomType === "Double" ? "bg-blue-100 text-blue-800" :
                                row.roomType === "Triple" ? "bg-purple-100 text-purple-800" :
                                row.roomType === "Quad" ? "bg-green-100 text-green-800" :
                                row.roomType === "Quint" ? "bg-amber-100 text-amber-800" :
                                row.roomType === "Multi" ? "bg-red-100 text-red-800" :
                                "bg-gray-100 text-gray-700"
                              }`}>{row.roomType}</span>
                              <div className="text-[10px] text-muted-foreground mt-0.5">{row.totalMembers} total</div>
                            </td>
                          ) : null}
                          <td className="px-3 py-2 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                title="Edit room number"
                                className="p-1 rounded hover:bg-blue-50 text-blue-500 hover:text-blue-700 transition-colors"
                                onClick={() => setEditingRoom(isEditing ? null : { familyId: fam.familyId, value: row.roomNumber })}
                              ><Pencil size={12} /></button>
                              <button
                                title={swapSelectA ? (isSwapSelected ? "Cancel swap" : "Swap with this family") : "Select to swap"}
                                disabled={swapPending}
                                className={`p-1 rounded transition-colors ${
                                  isSwapSelected ? "bg-amber-100 text-amber-700" :
                                  swapSelectA ? "text-amber-600 hover:bg-amber-50 animate-pulse" :
                                  "hover:bg-amber-50 text-gray-400 hover:text-amber-600"
                                }`}
                                onClick={() => {
                                  if (!swapSelectA) { setSwapSelectA(fam.familyId); }
                                  else if (isSwapSelected) { setSwapSelectA(null); }
                                  else { handleSwapRooms(fam.familyId); }
                                }}
                              ><ArrowLeftRight size={12} /></button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
              </>
            )}
          </div>
          <div className="pt-2 border-t flex justify-between items-center">
            <p className="text-xs text-muted-foreground">{roomSummaryData.length} rooms · {roomSummaryData.reduce((s: number, r: any) => s + r.totalMembers, 0)} pilgrims assigned</p>
            <Button size="sm" variant="outline" onClick={() => setRoomSummaryOpen(false)}>Close</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Family Merge Dialog ===== */}
      <Dialog open={!!mergeSourceFam} onOpenChange={open => !open && setMergeSourceFam(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <GitMerge size={16} className="text-violet-600" />
              Merge Family {mergeSourceFam?.familyId}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-1">
            <p className="text-xs text-muted-foreground">
              All {mergeSourceFam?.members.length} members of <strong>{mergeSourceFam?.familyId}</strong> will be moved into the target family. <strong>{mergeSourceFam?.familyId}</strong> will cease to exist.
            </p>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-700">Merge into:</label>
              <select
                value={mergeTargetId}
                onChange={e => setMergeTargetId(e.target.value)}
                className="w-full h-9 px-3 text-sm rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-primary/30"
              >
                <option value="">— Select target family —</option>
                {families.filter(f => f.familyId !== mergeSourceFam?.familyId).map(f => (
                  <option key={f.familyId} value={f.familyId}>
                    {f.familyId} — {f.head?.fullName?.split(" ")[0] || "?"} ({f.members.length} members)
                  </option>
                ))}
              </select>
            </div>
            {mergeTargetId && mergeSourceFam && (
              <div className="bg-violet-50 border border-violet-200 rounded-lg px-3 py-2 text-xs text-violet-800">
                <strong>Preview:</strong> Merge {mergeSourceFam.familyId} ({mergeSourceFam.members.length} members) into {mergeTargetId} ({families.find(f => f.familyId === mergeTargetId)?.members.length ?? "?"} members)
                {" → "}{mergeTargetId} ({(mergeSourceFam.members.length) + (families.find(f => f.familyId === mergeTargetId)?.members.length ?? 0)} members)
              </div>
            )}
            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={() => setMergeSourceFam(null)}>Cancel</Button>
              <Button
                size="sm"
                className="bg-violet-600 hover:bg-violet-700 text-white gap-1.5"
                onClick={doMerge}
                disabled={!mergeTargetId || mergePending}
              >
                <GitMerge size={13} />
                {mergePending ? "Merging…" : "Confirm Merge"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Family Split Dialog ===== */}
      <Dialog open={!!splitFam} onOpenChange={open => !open && setSplitFam(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <Scissors size={16} className="text-orange-600" />
              Split Family {splitFam?.familyId}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-1">
            <p className="text-xs text-muted-foreground">
              Select members to split out into a new auto-generated family. At least one member must remain in <strong>{splitFam?.familyId}</strong>.
            </p>
            <div className="border rounded-lg divide-y max-h-60 overflow-y-auto">
              {splitFam?.members.map(m => {
                const isHead = !!m.familyHead;
                const checked = splitSelectedIds.includes(m.id);
                return (
                  <label
                    key={m.id}
                    className={`flex items-center gap-3 px-3 py-2.5 cursor-pointer hover:bg-muted/40 ${isHead ? "bg-amber-50" : ""}`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={e => {
                        setSplitSelectedIds(prev =>
                          e.target.checked ? [...prev, m.id] : prev.filter(id => id !== m.id)
                        );
                      }}
                      className="rounded"
                    />
                    <div className="flex-1 min-w-0">
                      <span className="text-sm font-medium truncate">{m.fullName}</span>
                      {isHead && <Star size={10} className="inline ml-1 text-amber-500" fill="currentColor" />}
                      {m.familyRelation && <span className="ml-1.5 text-[10px] text-muted-foreground">{m.familyRelation}</span>}
                    </div>
                    <span className="text-[10px] text-muted-foreground shrink-0">{m.gender || ""}</span>
                  </label>
                );
              })}
            </div>
            {splitSelectedIds.length > 0 && splitFam && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg px-3 py-2 text-xs text-orange-800">
                <strong>Preview:</strong> {splitSelectedIds.length} member{splitSelectedIds.length !== 1 ? "s" : ""} will move to a new auto-generated family.{" "}
                {splitFam.members.length - splitSelectedIds.length} remain in {splitFam.familyId}.
                {splitSelectedIds.length >= splitFam.members.length && (
                  <span className="block mt-1 font-semibold text-red-700">⚠ At least one member must stay — deselect one.</span>
                )}
              </div>
            )}
            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={() => setSplitFam(null)}>Cancel</Button>
              <Button
                size="sm"
                className="bg-orange-600 hover:bg-orange-700 text-white gap-1.5"
                onClick={doSplit}
                disabled={splitSelectedIds.length === 0 || splitSelectedIds.length >= (splitFam?.members.length ?? 0) || splitPending}
              >
                <Scissors size={13} />
                {splitPending ? "Splitting…" : "Split into New Family"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Family WhatsApp Compose Dialog ===== */}
      <Dialog open={!!waFamily} onOpenChange={open => !open && setWaFamily(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <MessageCircle size={16} className="text-green-600" />
              WhatsApp — {waFamily?.familyId}
              {waFamily?.head?.fullName ? ` · ${waFamily.head.fullName}` : ""}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 pt-1">
            <div className="flex items-center gap-2 text-xs bg-green-50 border border-green-200 px-3 py-2 rounded-lg">
              <MessageCircle size={12} className="text-green-600 shrink-0" />
              <span className="text-green-800">Sending to: <strong>{waFamily?.head?.mobileIndia || "—"}</strong></span>
            </div>
            <textarea
              value={waMessage}
              onChange={e => setWaMessage(e.target.value)}
              rows={13}
              className="w-full border rounded-lg p-3 text-xs font-mono resize-none focus:outline-none focus:ring-2 focus:ring-green-400/50 bg-white"
            />
            <div className="flex gap-2 justify-between">
              <button
                onClick={() => {
                  const phone = (waFamily?.head?.mobileIndia || "").replace(/\D/g, "");
                  const full = phone.length === 10 ? `91${phone}` : phone;
                  window.open(`https://wa.me/${full}?text=${encodeURIComponent(waMessage)}`, "_blank");
                }}
                className="text-xs text-green-700 underline px-2 py-1 rounded hover:bg-green-50"
              >
                Open in WhatsApp ↗
              </button>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => setWaFamily(null)}>Cancel</Button>
                <Button
                  size="sm"
                  className="bg-green-600 hover:bg-green-700 text-white gap-1.5"
                  onClick={sendFamilyWA}
                  disabled={waSending || !waFamily?.head?.mobileIndia}
                >
                  <MessageCircle size={13} />
                  {waSending ? "Sending…" : "Send via BotBee"}
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Sync Logistics Dialog ===== */}
      <Dialog open={!!syncPromptData} onOpenChange={open => !open && setSyncPromptData(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-[#0d5040]">
              <RefreshCw size={16} /> Sync Family Logistics?
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              You changed the room/hotel/bus for the family head of <strong>Family {syncPromptData?.familyId}</strong>. 
              Apply the same room, hotel, bus and flight context to all <strong>{syncPromptData?.familySize}</strong> other family members?
            </p>
            {syncPromptData && (
              <div className="bg-muted rounded-lg p-3 text-sm space-y-1">
                {syncPromptData.roomNumber
                  ? <div>🏨 Room: <strong>{syncPromptData.roomNumber}</strong>{syncPromptData.roomHotel ? ` — ${HOTEL_LABELS[syncPromptData.roomHotel] || syncPromptData.roomHotel}` : ""}</div>
                  : <div className="text-muted-foreground">🏨 Room: <em>will be cleared</em></div>}
                {syncPromptData.busNumber
                  ? <div>🚌 Bus: <strong>{syncPromptData.busNumber}</strong></div>
                  : <div className="text-muted-foreground">🚌 Bus: <em>will be cleared</em></div>}
                {syncPromptData.flightNumber && (
                  <div className="text-muted-foreground">✈️ Flight: <strong>{syncPromptData.flightNumber}</strong> <span className="text-xs">(group-wide, shown for reference)</span></div>
                )}
              </div>
            )}
            <div className="flex gap-2 pt-1">
              <Button variant="outline" size="sm" className="flex-1" onClick={() => setSyncPromptData(null)}>
                No, skip
              </Button>
              <Button
                size="sm"
                className="flex-1 bg-[#0d5040] hover:bg-[#0d5040]/90 text-white gap-1.5"
                disabled={syncingFamily}
                onClick={async () => {
                  if (!syncPromptData) return;
                  setSyncingFamily(true);
                  try {
                    const res = await fetch(`${API}/api/groups/${groupId}/families/${encodeURIComponent(syncPromptData.familyId)}/sync-logistics`, {
                      method: "POST", credentials: "include",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        roomNumber: syncPromptData.roomNumber,
                        busNumber: syncPromptData.busNumber,
                        roomHotel: syncPromptData.roomHotel,
                      }),
                    });
                    if (!res.ok) throw new Error("Failed");
                    const data = await res.json();
                    toast({ title: `Synced ${data.updated ?? syncPromptData.familySize} family members ✓` });
                    fetchData(); fetchFamilies();
                  } catch { toast({ title: "Sync failed", variant: "destructive" }); }
                  finally { setSyncingFamily(false); setSyncPromptData(null); }
                }}
              >
                <RefreshCw size={13} />
                {syncingFamily ? "Syncing…" : "Yes, sync all"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Pilgrim Dialog ===== */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">{editingId ? "Edit Pilgrim" : "Add Pilgrim"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-medium">Title / Salutation</label>
                <select value={form.salutation} onChange={e => f("salutation", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="">Select</option>
                  <option value="Haji">Haji (Male)</option>
                  <option value="Hajjah">Hajjah (Female)</option>
                  <option value="Mr.">Mr.</option>
                  <option value="Mrs.">Mrs.</option>
                  <option value="Miss">Miss</option>
                  <option value="Master">Master</option>
                  <option value="Infant">Infant</option>
                </select>
              </div>
              <div className="space-y-1"><label className="text-sm font-medium">Full Name *</label><Input value={form.fullName} onChange={e => f("fullName", e.target.value)} placeholder="As per passport" /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Passport Number</label><Input value={form.passportNumber} onChange={e => f("passportNumber", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Visa Number</label><Input value={form.visaNumber} onChange={e => f("visaNumber", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Passport Issue Date</label><Input value={form.passportIssueDate} onChange={e => f("passportIssueDate", e.target.value)} placeholder="DD/MM/YYYY" /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Passport Expiry Date</label><Input value={form.passportExpiryDate} onChange={e => f("passportExpiryDate", e.target.value)} placeholder="DD/MM/YYYY" /></div>
              <div className="col-span-2 space-y-1"><label className="text-sm font-medium">Place of Issue</label><Input value={form.passportPlaceOfIssue} onChange={e => f("passportPlaceOfIssue", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Date of Birth</label><Input value={form.dateOfBirth} onChange={e => f("dateOfBirth", e.target.value)} placeholder="DD/MM/YYYY" /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Gender</label>
                <select value={form.gender} onChange={e => {
                  const g = e.target.value;
                  setForm(prev => ({ ...prev, gender: g, salutation: prev.salutation ? prev.salutation : g === "Male" ? "Mr." : g === "Female" ? "Mrs." : prev.salutation }));
                }} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="">Select</option><option value="Male">Male</option><option value="Female">Female</option>
                </select>
              </div>
              <div className="space-y-1"><label className="text-sm font-medium">Blood Group</label>
                <select value={form.bloodGroup} onChange={e => f("bloodGroup", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="">Select</option>
                  {["A+","A-","B+","B-","AB+","AB-","O+","O-"].map(bg => <option key={bg} value={bg}>{bg}</option>)}
                </select>
              </div>
              <div className="space-y-1"><label className="text-sm font-medium">India Mobile</label><Input value={form.mobileIndia} onChange={e => f("mobileIndia", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Saudi Mobile</label><Input value={form.mobileSaudi} onChange={e => f("mobileSaudi", e.target.value)} /></div>
              <div className="col-span-2 space-y-1"><label className="text-sm font-medium">Address</label><Input value={form.address} onChange={e => f("address", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">City</label><Input value={form.city} onChange={e => f("city", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">State</label><Input value={form.state} onChange={e => f("state", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Room Number</label><Input value={form.roomNumber} onChange={e => f("roomNumber", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Room Type</label>
                <select value={form.roomType} onChange={e => f("roomType", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="">Select</option>
                  {["Single","Double","Triple","Quad","Quint"].map(rt => <option key={rt} value={rt}>{rt}</option>)}
                </select>
              </div>
              <div className="space-y-1"><label className="text-sm font-medium">Bus Number</label><Input value={form.busNumber} onChange={e => f("busNumber", e.target.value)} /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Seat Number</label><Input value={form.seatNumber} onChange={e => f("seatNumber", e.target.value)} placeholder="e.g. 14A" /></div>
              <div className="space-y-1"><label className="text-sm font-medium">Relation</label>
                <select value={form.relation} onChange={e => f("relation", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="">Select</option>
                  {["Self","Husband","Wife","Son","Daughter","Father","Mother","Brother","Sister","Nephew","Niece","Father in Law","Mother in Law","Bhabhi","Uncle","Aunty","Other"].map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div className="space-y-1"><label className="text-sm font-medium">Cover Number (HGO ID)</label><Input value={form.coverNumber} onChange={e => f("coverNumber", e.target.value)} /></div>
              <div className="col-span-2 space-y-1">
                <label className="text-sm font-medium">Medical Condition</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {["Diabetic","BP Patient","Heart Patient","Allergy"].map(cond => (
                    <button key={cond} type="button" onClick={() => {
                      const existing = form.medicalCondition ? form.medicalCondition.split(", ").filter(Boolean) : [];
                      if (existing.includes(cond)) f("medicalCondition", existing.filter(c => c !== cond).join(", "));
                      else f("medicalCondition", [...existing, cond].join(", "));
                    }} className={`px-3 py-1 rounded-full text-xs font-semibold border transition-all ${form.medicalCondition?.includes(cond) ? "bg-red-600 text-white border-red-600" : "bg-white text-red-600 border-red-300 hover:bg-red-50"}`}>
                      {cond}
                    </button>
                  ))}
                </div>
                <Input value={form.medicalCondition} onChange={e => f("medicalCondition", e.target.value)} placeholder="e.g. Diabetic, BP Patient" />
              </div>
              {editingId && (
                <div className="col-span-2 space-y-1 border-t pt-3">
                  <label className="text-sm font-semibold text-primary">Serial Number</label>
                  <p className="text-xs text-muted-foreground mb-1">Change this pilgrim's position/order number within the group.</p>
                  <Input
                    type="number" min="1"
                    value={form.serialNumber}
                    onChange={e => f("serialNumber", e.target.value)}
                    placeholder="e.g. 5"
                    className="w-32"
                  />
                </div>
              )}
            </div>
            <Button onClick={handleSave} className="w-full">{editingId ? "Save Changes" : "Add Pilgrim"}</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Room Create/Edit Dialog ===== */}
      <Dialog open={roomDialogOpen} onOpenChange={setRoomDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif text-xl">{editingRoomId ? "Edit Room" : "Add Room"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-medium">Room Number *</label>
                <Input value={roomForm.roomNumber} onChange={e => rf("roomNumber", e.target.value)} placeholder="e.g. 201, 501" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Hotel *</label>
                <select value={roomForm.hotel} onChange={e => rf("hotel", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="aziziah">Makkah 1 (Aziziah)</option>
                  <option value="makkah">Makkah 2</option>
                  <option value="madinah">Madinah</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Room Type *</label>
                <select value={roomForm.roomType} onChange={e => rf("roomType", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="gents">Gents</option>
                  <option value="ladies">Ladies</option>
                  <option value="family">Family</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Total Beds *</label>
                <select value={roomForm.totalBeds} onChange={e => rf("totalBeds", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  {[2,3,4,5,6].map(n => <option key={n} value={n}>{n} Beds</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Floor (optional)</label>
                <Input value={roomForm.floor} onChange={e => rf("floor", e.target.value)} placeholder="e.g. 3" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Notes (optional)</label>
                <Input value={roomForm.notes} onChange={e => rf("notes", e.target.value)} placeholder="Any notes..." />
              </div>
            </div>
            <div className="flex gap-2 pt-1">
              <Button variant="outline" onClick={() => setRoomDialogOpen(false)} className="flex-1">Cancel</Button>
              <Button onClick={handleRoomSave} className="flex-1">{editingRoomId ? "Save Changes" : "Create Room"}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Room Delete Confirm ===== */}
      <Dialog open={!!deleteConfirmRoomId} onOpenChange={() => setDeleteConfirmRoomId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Delete Room?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground mt-2">
            This removes the room record. Existing pilgrim room assignments will not be cleared automatically.
          </p>
          <div className="flex gap-2 mt-4">
            <Button variant="outline" onClick={() => setDeleteConfirmRoomId(null)} className="flex-1">Cancel</Button>
            <Button variant="destructive" onClick={() => deleteConfirmRoomId && handleRoomDelete(deleteConfirmRoomId)} className="flex-1">Delete Room</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ===== Bulk Add Rooms Dialog ===== */}
      <Dialog open={bulkRoomDialogOpen} onOpenChange={setBulkRoomDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif text-xl flex items-center gap-2"><Layers size={18} /> Bulk Add Rooms</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground -mt-1">Enter a range of room numbers to create multiple rooms at once.</p>
          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-sm font-medium">Hotel *</label>
                <select value={bulkRoomForm.hotel} onChange={e => brf("hotel", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="aziziah">Makkah 1 (Aziziah)</option>
                  <option value="makkah">Makkah 2</option>
                  <option value="madinah">Madinah</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Room Type *</label>
                <select value={bulkRoomForm.roomType} onChange={e => brf("roomType", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  <option value="gents">Gents</option>
                  <option value="ladies">Ladies</option>
                  <option value="family">Family</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Total Beds *</label>
                <select value={bulkRoomForm.totalBeds} onChange={e => brf("totalBeds", e.target.value)} className="w-full h-10 px-3 rounded-md border bg-background text-sm">
                  {[2,3,4,5,6].map(n => <option key={n} value={n}>{n} Beds</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Floor (optional)</label>
                <Input value={bulkRoomForm.floor} onChange={e => brf("floor", e.target.value)} placeholder="e.g. 3" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">From Room # *</label>
                <Input value={bulkRoomForm.fromRoom} onChange={e => brf("fromRoom", e.target.value)} placeholder="e.g. 501" type="number" min="1" />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">To Room # *</label>
                <Input value={bulkRoomForm.toRoom} onChange={e => brf("toRoom", e.target.value)} placeholder="e.g. 520" type="number" min="1" />
              </div>
            </div>
            {bulkRoomForm.fromRoom && bulkRoomForm.toRoom && !isNaN(parseInt(bulkRoomForm.fromRoom)) && !isNaN(parseInt(bulkRoomForm.toRoom)) && parseInt(bulkRoomForm.fromRoom) <= parseInt(bulkRoomForm.toRoom) && (
              <p className="text-sm text-emerald-700 font-medium bg-emerald-50 rounded-lg px-3 py-2">
                Will create {parseInt(bulkRoomForm.toRoom) - parseInt(bulkRoomForm.fromRoom) + 1} rooms (#{bulkRoomForm.fromRoom} to #{bulkRoomForm.toRoom})
              </p>
            )}
            <div className="flex gap-2 pt-1">
              <Button variant="outline" onClick={() => setBulkRoomDialogOpen(false)} className="flex-1">Cancel</Button>
              <Button onClick={handleBulkRoomAdd} disabled={bulkAdding} className="flex-1">
                {bulkAdding ? "Adding..." : "Create Rooms"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      {/* ===== Auto-detect Dialog ===== */}
      <Dialog open={detectDialogOpen} onOpenChange={setDetectDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif text-xl flex items-center gap-2">
              <Zap size={18} className="text-[#0d5040]" /> Auto-detected Family Groups
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground -mt-1">
            Found <strong>{suggestions.length}</strong> suggestion{suggestions.length !== 1 ? "s" : ""} covering{" "}
            <strong>{[...new Set(suggestions.flatMap(s => s.pilgrimIds))].length}</strong> pilgrims.
            Review and toggle which ones to apply.
          </p>
          <div className="flex items-center gap-2 py-1">
            <button onClick={() => setAcceptedSuggestions(new Set(suggestions.map(s => s.id)))}
              className="text-xs text-primary underline">Select All</button>
            <span className="text-muted-foreground">·</span>
            <button onClick={() => setAcceptedSuggestions(new Set())}
              className="text-xs text-muted-foreground underline">Deselect All</button>
            <span className="ml-auto text-xs text-muted-foreground">
              {acceptedSuggestions.size} of {suggestions.length} selected
            </span>
          </div>
          <div className="space-y-3 mt-1">
            {suggestions.map(s => {
              const accepted = acceptedSuggestions.has(s.id);
              return (
                <div key={s.id}
                  className={`border rounded-xl p-3 transition-all ${accepted ? "border-[#0d5040]/40 bg-[#0d5040]/5" : "border-gray-200 bg-gray-50 opacity-60"}`}>
                  <div className="flex items-start gap-3">
                    <input type="checkbox" checked={accepted} onChange={e => {
                      const next = new Set(acceptedSuggestions);
                      e.target.checked ? next.add(s.id) : next.delete(s.id);
                      setAcceptedSuggestions(next);
                    }} className="mt-1 w-4 h-4 accent-[#0d5040] shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <input
                          value={suggestionFamilyIds[s.id] || s.suggestedFamilyId}
                          onChange={e => setSuggestionFamilyIds(prev => ({ ...prev, [s.id]: e.target.value }))}
                          className="font-mono font-black text-sm text-[#0d5040] bg-amber-100 border border-amber-300 rounded px-2 py-0.5 w-20"
                          title="Edit family ID"
                        />
                        <span className="text-xs text-muted-foreground">{s.reason}</span>
                        {s.existingFamilyId && (
                          <span className="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full font-semibold shrink-0">existing</span>
                        )}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {s.memberNames.map((name, i) => (
                          <span key={i} className="text-xs bg-white border border-gray-200 text-gray-700 px-2 py-0.5 rounded-full">
                            {i === 0 && <Star size={8} className="inline mr-0.5 text-amber-500 mb-0.5" fill="currentColor" />}
                            {name}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex gap-2 mt-2 pt-2 border-t">
            <Button variant="outline" onClick={() => setDetectDialogOpen(false)} className="flex-1">Cancel</Button>
            <Button onClick={handleApplySuggestions} disabled={applyingSuggestions || acceptedSuggestions.size === 0}
              className="flex-1 bg-[#0d5040] hover:bg-[#0d5040]/90 text-white gap-1.5">
              <Zap size={14} /> {applyingSuggestions ? "Applying..." : `Apply ${acceptedSuggestions.size} Group${acceptedSuggestions.size !== 1 ? "s" : ""}`}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <BulkImportModal
        groupId={groupId}
        open={bulkImportOpen}
        onClose={() => setBulkImportOpen(false)}
        onImported={fetchData}
        existingPassports={pilgrims.map(p => p.passportNumber).filter(Boolean) as string[]}
      />

      <QuickAddModal
        open={quickAddOpen}
        onClose={() => setQuickAddOpen(false)}
        groupId={groupId}
        onImported={fetchData}
      />
    </AdminLayout>
  );
}
