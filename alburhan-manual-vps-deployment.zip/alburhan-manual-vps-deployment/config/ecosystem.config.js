// PM2 ecosystem config for Al Burhan Tours & Travels
// Build: alburhan-v9
//
// Usage:
//   pm2 start ecosystem.config.js
//   pm2 restart all --update-env
//
// NOTE: The .env file at /var/www/alburhan/.env is loaded
//       separately by the process. Do NOT commit .env.

module.exports = {
  apps: [
    {
      name: "alburhan-api",
      script: "/var/www/alburhan/artifacts/api-server/dist/index.cjs",
      cwd: "/var/www/alburhan",
      interpreter: "node",
      instances: 1,
      exec_mode: "fork",
      watch: false,
      env: {
        NODE_ENV: "production",
        PORT: "5000",
      },
      env_file: "/var/www/alburhan/.env",
      error_file: "/var/log/pm2/alburhan-api-error.log",
      out_file: "/var/log/pm2/alburhan-api-out.log",
      log_date_format: "YYYY-MM-DD HH:mm:ss Z",
      restart_delay: 3000,
      max_restarts: 10,
      min_uptime: "10s",
    },
  ],
};
