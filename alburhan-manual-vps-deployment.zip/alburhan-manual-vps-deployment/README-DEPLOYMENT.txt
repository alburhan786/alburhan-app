====================================================================
Al Burhan Tours & Travels ERP — Manual VPS Deployment Package
Build:   alburhan-v9
Bundle:  index-Bf4FHbEF.js
Date:    2026-07-31
====================================================================

WHAT IS IN THIS PACKAGE
────────────────────────
  frontend/            React SPA build (all 5 login routes included)
  backend/index.cjs    Node.js API server bundle (~6.6 MB)
  config/              PM2 ecosystem config (reference)
  scripts/             install-on-vps.sh (automated installer)
  nginx/               Nginx config reference
  checksums.txt        SHA-256 checksums for verification
  README-DEPLOYMENT.txt  This file

LOGIN ROUTES INCLUDED IN THIS BUILD
─────────────────────────────────────
  /admin/login    → Admin portal
  /staff/login    → Staff portal
  /branch/login   → Branch manager portal
  /agent/login    → Agent portal
  /customer/login → Customer portal

  Each route renders the correct portal login directly.
  No redirects. SPA routing via try_files handles page refresh.

SERVICE WORKER
──────────────
  Cache name: alburhan-v9
  Old cache (alburhan-v8) is discarded automatically on next visit.

NO SECRETS IN THIS PACKAGE
────────────────────────────
  - No .env file included
  - No database passwords
  - No API keys or tokens
  - The existing /var/www/alburhan/.env on VPS is preserved


====================================================================
HOW TO DEPLOY — MAC / LOCAL MACHINE
====================================================================

STEP 1: Download the ZIP from Replit
  - Open your Replit project
  - In the Files panel, find:
      alburhan-manual-vps-deployment.zip
  - Right-click → Download

STEP 2: Upload to your Hostinger VPS

  OPTION A — Hostinger File Manager (easiest):
    1. Log in to hpanel.hostinger.com
    2. Go to VPS → Manage → File Manager
    3. Navigate to /root
    4. Click Upload and select alburhan-manual-vps-deployment.zip
    5. After upload, click the ZIP → Extract

  OPTION B — SCP from your Mac terminal:
    scp alburhan-manual-vps-deployment.zip root@YOUR_VPS_IP:/root/
    (replace YOUR_VPS_IP with your actual VPS IP address)

  OPTION C — Hostinger SSH in browser:
    - Use the SSH web terminal in Hostinger hpanel
    - Run the VPS commands below after uploading via File Manager


====================================================================
HOW TO DEPLOY — HOSTINGER VPS (SSH)
====================================================================

Run these commands one by one in your VPS SSH terminal:

  # 1. Go to root home
  cd /root

  # 2. Remove any old package (if re-deploying)
  rm -rf alburhan-manual-vps-deployment

  # 3. Unzip the package
  unzip alburhan-manual-vps-deployment.zip

  # 4. Enter the directory
  cd alburhan-manual-vps-deployment

  # 5. Make the script executable
  chmod +x scripts/install-on-vps.sh

  # 6. Run the installer
  sudo bash scripts/install-on-vps.sh

The script will:
  - Validate checksums
  - Run node --check on the backend
  - Verify all 5 login routes exist in the bundle
  - Back up current frontend and backend
  - Install new frontend to /var/www/alburhan/artifacts/alburhan/dist/public
  - Install new backend to /var/www/alburhan/artifacts/api-server/dist/index.cjs
  - Reload nginx
  - Restart PM2 (alburhan-api and alburhan-tours)
  - Check /api/health — auto-rolls back backend if it fails
  - Test all 5 login routes on alburhantravels.com


====================================================================
NGINX CONFIGURATION
====================================================================

The nginx/alburhan.conf file is provided as a REFERENCE only.
The installer does NOT automatically replace your nginx config.

To apply the nginx config manually (ONLY if your current config
is broken or missing):

  # View your current config
  cat /etc/nginx/sites-enabled/alburhan

  # If you want to replace it:
  cp /root/alburhan-manual-vps-deployment/nginx/alburhan.conf \
     /etc/nginx/sites-available/alburhan

  ln -sf /etc/nginx/sites-available/alburhan \
         /etc/nginx/sites-enabled/alburhan

  # Test and reload
  nginx -t && nginx -s reload

The key setting that makes all 5 login routes work:
  location / {
      try_files $uri $uri/ /index.html;
  }
This returns index.html for any path nginx doesn't know about,
letting React Router handle /admin/login etc. client-side.


====================================================================
ROLLBACK INSTRUCTIONS
====================================================================

If anything goes wrong, the installer saves a timestamped backup at:
  /var/www/alburhan-backups/YYYYMMDD_HHMMSS/

To roll back manually:

  # Replace frontend
  BACKUP=/var/www/alburhan-backups/YYYYMMDD_HHMMSS
  rm -rf /var/www/alburhan/artifacts/alburhan/dist/public
  tar -xzf $BACKUP/frontend.tar.gz \
      -C /var/www/alburhan/artifacts/alburhan/dist
  
  # Replace backend
  cp $BACKUP/index.cjs \
     /var/www/alburhan/artifacts/api-server/dist/index.cjs

  # Restart and reload
  pm2 restart alburhan-api --update-env
  nginx -s reload

  # Verify
  curl -s https://alburhantravels.com/sw.js | head -3


====================================================================
TROUBLESHOOTING
====================================================================

404 on /admin/login after deploy?
  → nginx try_files is missing. Check:
      grep 'try_files' /etc/nginx/sites-enabled/alburhan
  → If missing, add:  try_files $uri $uri/ /index.html;
  → Reload:  nginx -s reload

Still seeing old frontend (alburhan-v8)?
  → Browser is using a cached service worker. 
  → Hard-refresh: Cmd+Shift+R (Mac) or Ctrl+Shift+R (Windows)
  → Or in DevTools: Application → Service Workers → Unregister
  → The v9 service worker will auto-discard v8 cache on next load

API returns 502 Bad Gateway?
  → PM2 process not running. Check:
      pm2 list
      pm2 logs alburhan-api --lines 30
  → Restart:  pm2 restart alburhan-api --update-env
  → If still failing, check .env file:
      cat /var/www/alburhan/.env | grep -v '=' (shows keys, not values)

nginx -t fails?
  → Syntax error in config. Run:  nginx -T 2>&1 | grep -i error
  → Restore from backup before this deploy
