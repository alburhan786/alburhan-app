#!/usr/bin/env bash
# ============================================================
# Al Burhan Tours & Travels — VPS Installation Script
# Build: alburhan-v9  |  Bundle: Bf4FHbEF
# ============================================================
# Usage (run as root from the extracted ZIP directory):
#   chmod +x scripts/install-on-vps.sh
#   sudo bash scripts/install-on-vps.sh
# ============================================================
set -euo pipefail

FRONTEND_SRC="$(cd "$(dirname "$0")/.." && pwd)/frontend"
BACKEND_SRC="$(cd "$(dirname "$0")/.." && pwd)/backend/index.cjs"
NGINX_CONF_SRC="$(cd "$(dirname "$0")/.." && pwd)/nginx/alburhan.conf"
CHECKSUMS_FILE="$(cd "$(dirname "$0")/.." && pwd)/checksums.txt"

FRONTEND_DEST="/var/www/alburhan/artifacts/alburhan/dist/public"
BACKEND_DEST="/var/www/alburhan/artifacts/api-server/dist/index.cjs"
ENV_FILE="/var/www/alburhan/.env"

EXPECTED_SW="alburhan-v9"
EXPECTED_HASH="Bf4FHbEF"
API_PORT="5000"
DOMAIN="https://alburhantravels.com"

BACKUP_DIR="/var/www/alburhan-backups/$(date +%Y%m%d_%H%M%S)"
PM2_API="alburhan-api"
PM2_TOURS="alburhan-tours"

die()  { echo ""; echo "FATAL: $*" >&2; exit 1; }
ok()   { echo "  [OK] $*"; }
warn() { echo "  [WARN] $*"; }
sep()  { echo ""; echo "=== $* ==="; }

sep "Al Burhan VPS Installation — $(date)"

# ── 0. Pre-flight checks ──────────────────────────────────────────
sep "0. Pre-flight checks"

[ "$(id -u)" = "0" ] || die "Must run as root"
ok "Running as root"

[ -f "$BACKEND_SRC" ] || die "backend/index.cjs not found — run from the extracted ZIP directory"
ok "backend/index.cjs found"

[ -d "$FRONTEND_SRC" ] || die "frontend/ directory not found"
ok "frontend/ directory found"

[ -f "$ENV_FILE" ] || die ".env file not found at $ENV_FILE — do NOT copy secrets into this package"
ok ".env file preserved at $ENV_FILE"

# ── 1. Validate checksums ─────────────────────────────────────────
sep "1. Validating checksums"
if [ -f "$CHECKSUMS_FILE" ]; then
  cd "$(dirname "$CHECKSUMS_FILE")"
  sha256sum -c checksums.txt 2>&1 | head -20 || warn "Some checksums differ — files may have been modified"
  cd - > /dev/null
else
  warn "checksums.txt not found — skipping"
fi

# ── 2. Validate backend ───────────────────────────────────────────
sep "2. Validating backend bundle"
node --check "$BACKEND_SRC" 2>&1 || die "node --check failed for backend/index.cjs — do not install a broken bundle"
ok "node --check passed"

BE_BYTES=$(wc -c < "$BACKEND_SRC")
[ "$BE_BYTES" -lt 1000000 ] && die "Backend bundle too small ($BE_BYTES bytes) — may be corrupted"
ok "Backend size: $BE_BYTES bytes"

# ── 3. Validate frontend ──────────────────────────────────────────
sep "3. Validating frontend"

[ -f "${FRONTEND_SRC}/index.html" ]  || die "frontend/index.html missing"
[ -f "${FRONTEND_SRC}/sw.js" ]       || die "frontend/sw.js missing"
[ -d "${FRONTEND_SRC}/assets" ]      || die "frontend/assets/ missing"
ok "index.html, sw.js, assets/ all present"

SW_VER=$(grep -o 'alburhan-v[0-9]*' "${FRONTEND_SRC}/sw.js" 2>/dev/null | head -1 || echo "?")
[ "$SW_VER" = "$EXPECTED_SW" ] || die "sw.js version='$SW_VER', expected '$EXPECTED_SW'"
ok "sw.js: $SW_VER"

JS_FILE=$(find "${FRONTEND_SRC}/assets" -name "index-${EXPECTED_HASH}.js" 2>/dev/null | head -1)
[ -n "$JS_FILE" ] || die "assets/index-${EXPECTED_HASH}.js not found"
ok "Bundle: index-${EXPECTED_HASH}.js"

MISSING_ROUTES=""
echo "  Route verification (grep -Rao):"
for ROUTE in admin/login staff/login branch/login agent/login customer/login; do
  RESULT=$(grep -Rao "$ROUTE" "$JS_FILE" | head -1)
  if [ -n "$RESULT" ]; then
    echo "    $RESULT — OK"
  else
    echo "    $ROUTE — MISSING"
    MISSING_ROUTES="$MISSING_ROUTES $ROUTE"
  fi
done
[ -n "$MISSING_ROUTES" ] && die "Routes missing in bundle:$MISSING_ROUTES"
ok "All 5 login routes confirmed"

# ── 4. Back up existing deployment ───────────────────────────────
sep "4. Backing up current deployment"
mkdir -p "$BACKUP_DIR"

if [ -d "$FRONTEND_DEST" ]; then
  tar -czf "${BACKUP_DIR}/frontend.tar.gz" -C "$(dirname "$FRONTEND_DEST")" "$(basename "$FRONTEND_DEST")" 2>/dev/null \
    && ok "Frontend backed up: ${BACKUP_DIR}/frontend.tar.gz" \
    || warn "Frontend backup failed (non-fatal)"
fi

if [ -f "$BACKEND_DEST" ]; then
  cp "$BACKEND_DEST" "${BACKUP_DIR}/index.cjs" \
    && ok "Backend backed up: ${BACKUP_DIR}/index.cjs" \
    || warn "Backend backup failed (non-fatal)"
fi

ok "Backup location: $BACKUP_DIR"

# ── 5. Install frontend ───────────────────────────────────────────
sep "5. Installing frontend"
mkdir -p "$(dirname "$FRONTEND_DEST")"
rm -rf "$FRONTEND_DEST"
cp -r "$FRONTEND_SRC" "$FRONTEND_DEST"
ok "Frontend installed to: $FRONTEND_DEST"

# Re-verify routes on disk
for ROUTE in admin/login staff/login branch/login agent/login customer/login; do
  RESULT=$(grep -Rao "$ROUTE" "${FRONTEND_DEST}/assets/index-${EXPECTED_HASH}.js" | head -1)
  [ -n "$RESULT" ] && echo "  [OK] $ROUTE on disk" || die "$ROUTE MISSING on disk after install"
done
SW_DISK=$(grep -o 'alburhan-v[0-9]*' "${FRONTEND_DEST}/sw.js" | head -1 || echo "?")
ok "sw.js on disk: $SW_DISK"

# ── 6. Install backend ────────────────────────────────────────────
sep "6. Installing backend"
mkdir -p "$(dirname "$BACKEND_DEST")"
cp "$BACKEND_SRC" "$BACKEND_DEST"
ok "Backend installed to: $BACKEND_DEST"

# ── 7. Optional: update nginx config ─────────────────────────────
sep "7. Nginx configuration"
if [ -f "$NGINX_CONF_SRC" ]; then
  NGINX_ENABLED="/etc/nginx/sites-enabled/alburhan"
  NGINX_AVAILABLE="/etc/nginx/sites-available/alburhan"
  echo "  Found nginx/alburhan.conf in package."
  echo "  To apply: cp \"$NGINX_CONF_SRC\" \"$NGINX_AVAILABLE\" && ln -sf \"$NGINX_AVAILABLE\" \"$NGINX_ENABLED\""
  echo "  Skipping automatic nginx config replacement to preserve existing settings."
  warn "Review nginx/alburhan.conf manually and apply if needed"
else
  warn "nginx/alburhan.conf not found — skipping"
fi

# Test current nginx config
if nginx -t 2>/dev/null; then
  nginx -s reload && ok "Nginx reloaded"
else
  warn "Nginx config test failed — skipping reload"
fi

# ── 8. Restart PM2 ────────────────────────────────────────────────
sep "8. Restarting PM2 processes"
RESTARTED=""
for APP in "$PM2_API" "$PM2_TOURS"; do
  if pm2 describe "$APP" &>/dev/null; then
    pm2 restart "$APP" --update-env && ok "Restarted: $APP" && RESTARTED="$RESTARTED $APP"
  else
    warn "PM2 process not found: $APP"
  fi
done
[ -z "$RESTARTED" ] && warn "No PM2 processes restarted — check process names with: pm2 list"
sleep 10

# ── 9. Health check & rollback on failure ────────────────────────
sep "9. Health checks"

# Local API health
HEALTH_HTTP=$(curl -so /dev/null -w '%{http_code}' --max-time 15 \
  "http://127.0.0.1:${API_PORT}/api/health" 2>/dev/null || echo "000")
echo "  http://127.0.0.1:$API_PORT/api/health => HTTP $HEALTH_HTTP"

if [ "$HEALTH_HTTP" != "200" ]; then
  warn "API health check failed (HTTP $HEALTH_HTTP) — rolling back backend"
  if [ -f "${BACKUP_DIR}/index.cjs" ]; then
    cp "${BACKUP_DIR}/index.cjs" "$BACKEND_DEST"
    for APP in "$PM2_API" "$PM2_TOURS"; do
      pm2 describe "$APP" &>/dev/null && pm2 restart "$APP" --update-env
    done
    sleep 5
    ROLLBACK_HTTP=$(curl -so /dev/null -w '%{http_code}' --max-time 15 \
      "http://127.0.0.1:${API_PORT}/api/health" 2>/dev/null || echo "000")
    ok "Rollback complete — health after rollback: HTTP $ROLLBACK_HTTP"
  else
    warn "No backend backup to roll back to"
  fi
  die "Backend health check failed — rolled back to previous version"
else
  ok "API health: HTTP $HEALTH_HTTP"
fi

# Production URL checks
echo ""
echo "  Production route checks:"
for ROUTE in / /admin/login /staff/login /branch/login /agent/login /customer/login; do
  S=$(curl -o /dev/null -sw '%{http_code}' --max-time 20 \
    "${DOMAIN}${ROUTE}" 2>/dev/null || echo "000")
  [ "$S" = "200" ] && echo "    [OK] $DOMAIN$ROUTE => HTTP $S" \
                    || echo "    [WARN] $DOMAIN$ROUTE => HTTP $S"
done

# Live bundle verification
LIVE_BUNDLE=$(curl -s --max-time 20 "$DOMAIN/" \
  | grep -o 'assets/index-[A-Za-z0-9_-]*\.js' | head -1 || echo "?")
LIVE_SW=$(curl -s --max-time 10 "$DOMAIN/sw.js" \
  | grep -o 'alburhan-v[0-9]*' | head -1 || echo "?")
echo ""
echo "  Live bundle: $LIVE_BUNDLE (expected: assets/index-${EXPECTED_HASH}.js)"
echo "  Live sw.js:  $LIVE_SW (expected: $EXPECTED_SW)"

[ "$LIVE_BUNDLE" = "assets/index-${EXPECTED_HASH}.js" ] && ok "Live bundle matches" || warn "Bundle mismatch — nginx may be caching; try: nginx -s reload"
[ "$LIVE_SW" = "$EXPECTED_SW" ] && ok "Live sw.js matches" || warn "sw.js mismatch"

echo ""
echo "  Grepping live JS for all 5 routes:"
for ROUTE in admin/login staff/login branch/login agent/login customer/login; do
  N=$(curl -s --max-time 30 "${DOMAIN}/${LIVE_BUNDLE}" 2>/dev/null | grep -co "$ROUTE" || echo "0")
  [ "$N" -gt 0 ] && echo "    [OK] $ROUTE in live JS ($N)" || echo "    [FAIL] $ROUTE NOT in live JS"
done

# ── 10. Summary ───────────────────────────────────────────────────
sep "10. Installation complete"
echo ""
echo "  Build:     alburhan-v9"
echo "  Bundle:    index-${EXPECTED_HASH}.js"
echo "  SW:        $LIVE_SW"
echo "  Frontend:  $FRONTEND_DEST"
echo "  Backend:   $BACKEND_DEST"
echo "  Backup:    $BACKUP_DIR"
echo ""
echo "  ROLLBACK INSTRUCTIONS:"
echo "  To restore previous version manually:"
echo "    cp ${BACKUP_DIR}/frontend.tar.gz /tmp/ && tar -xzf /tmp/frontend.tar.gz -C $(dirname "$FRONTEND_DEST")"
echo "    cp ${BACKUP_DIR}/index.cjs $BACKEND_DEST"
echo "    pm2 restart $PM2_API --update-env"
echo "    nginx -s reload"
echo ""
echo "  If any route shows 404 after install:"
echo "  1. Confirm nginx root: grep -E 'root' /etc/nginx/sites-enabled/alburhan"
echo "  2. Confirm try_files:  grep 'try_files' /etc/nginx/sites-enabled/alburhan"
echo "  3. Hard-refresh browser (Cmd+Shift+R on Mac / Ctrl+Shift+R on Windows)"
echo "  4. Clear service worker: DevTools > Application > Service Workers > Unregister"
echo ""
